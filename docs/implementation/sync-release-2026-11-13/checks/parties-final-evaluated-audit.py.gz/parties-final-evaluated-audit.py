"""Record final evaluated consumer selection separately from the initial audit."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import urllib.request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()

    def git(*values):
        return subprocess.check_output(['git', '-c', 'submodule.recurse=false', *values], cwd=root, text=True).strip()

    def get(url):
        with urllib.request.urlopen(url, timeout=30) as response:
            return json.load(response)

    command = ['dotnet', 'msbuild', 'src/Hexalith.Parties.Client/Hexalith.Parties.Client.csproj',
               '-nologo', '-p:Configuration=Release', '-p:UseHexalithProjectReferences=false',
               '-p:UseNuGetDeps=true', '-getItem:PackageVersion',
               '-getProperty:TargetFramework,HexalithEventStoreVersion,HexalithMemoriesVersion,HexalithFrontComposerVersion']
    environment = dict(os.environ, DOTNET_CLI_USE_MSBUILD_SERVER='false', MSBUILDUSESERVER='0')
    query = subprocess.run(command, cwd=root, env=environment, text=True,
                           capture_output=True, check=True, timeout=60)
    evaluated = json.loads(query.stdout)
    pins = {item['Identity'].casefold(): item['Version'] for item in evaluated['Items']['PackageVersion']}
    tools = json.loads((root / '.config/dotnet-tools.json').read_bytes())['tools']
    initial = json.loads((root / 'docs/implementation/sync-release-2026-11-13/registry-audit.json').read_bytes())

    def observe(row):
        versions = get(row['source'])['versions']
        stable = [value for value in versions if re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,3}', value)]
        latest = max(stable, key=lambda value: tuple((list(map(int, value.split('.'))) + [0] * 4)[:4])) if stable else None
        key = row['id'].casefold()
        selected = tools[key]['version'] if key in tools else pins[key]
        result = {'id': row['id'], 'selected': selected, 'latestStable': latest,
                  'latest': versions[-1], 'source': row['source']}
        if selected != (latest or versions[-1]):
            if key.startswith('hexalith.eventstore.'):
                result['retainedReason'] = 'Exact measured SDK4.2 consumer cohort; the global SDK5 default supplies no runtime admission.'
            elif key.startswith('hexalith.memories.'):
                result['retainedReason'] = 'Exact admitted3.0.27 package cohort; published4.0.0 source selection does not supply package qualification.'
            elif key in {'microsoft.aspnetcore.openapi', 'microsoft.openapi'}:
                result['retainedReason'] = 'Measured finite OpenAPI2 consumer ABI paired with SDK4.2.'
            elif key == 'communitytoolkit.aspire.hosting.dapr' and selected == '13.6.2-beta.959':
                assert latest == '13.0.0', (selected, latest)
                result['retainedReason'] = 'The authenticated Builds catalog selects the newer13.6.2 beta for the current Aspire13.6 toolchain; stable13.0.0 is older and the latest17.x beta is outside that toolchain.'
            else:
                raise ValueError('Unexpected noncurrent selected dependency: ' + row['id'])
        return result

    with ThreadPoolExecutor(max_workers=8) as pool:
        dependencies = list(pool.map(observe, initial['nuget']))
    metadata_url = 'https://builds.dotnet.microsoft.com/dotnet/release-metadata/releases-index.json'
    sdk_metadata = get(metadata_url)
    stable_channels = [row for row in sdk_metadata['releases-index']
                       if row['support-phase'] != 'preview' and re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', row['latest-sdk'])]
    latest_sdk = max((row['latest-sdk'] for row in stable_channels), key=lambda value: tuple(map(int, value.split('.'))))
    selected_sdk = json.loads((root / 'global.json').read_bytes())['sdk']['version']
    assert selected_sdk == latest_sdk, (selected_sdk, latest_sdk)
    paths = [line.split(None, 1)[1] for line in git('config', '--file', '.gitmodules', '--get-regexp', r'^submodule\..*\.path$').splitlines()]
    inputs = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
              for name in ['global.json', '.config/dotnet-tools.json', 'Directory.Packages.props', 'package.json', 'package-lock.json']}
    npm = json.loads((root / 'package-lock.json').read_bytes())['packages']
    result = {'schema': 'hexalith.parties.final-evaluated-consumer-audit.v1',
              'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Actual final selected worktree inputs and official registry observations; no inferred runtime, human or release acceptance',
              'rootHeadBeforeRecording': git('rev-parse', 'HEAD'), 'inputSha256': inputs,
              'directOwnerCheckouts': {path: git('-C', path, 'rev-parse', 'HEAD') for path in paths},
              'sdk': {'selected': selected_sdk, 'latestStable': latest_sdk, 'source': metadata_url},
              'evaluation': {'command': command, 'properties': evaluated['Properties'],
                             'stdoutSha256': hashlib.sha256(query.stdout.encode()).hexdigest()},
              'nuget': dependencies,
              'retainedOpenApiPins': {name: pins[name.casefold()] for name in ['Microsoft.AspNetCore.OpenApi', 'Microsoft.OpenApi']},
              'rootReleasePlugin': {'id': '@semantic-release/github', 'locked': npm['node_modules/@semantic-release/github']['version']},
              'initialAudit': {'path': 'registry-audit.json', 'observedAtUtc': initial['date'],
                               'sha256': hashlib.sha256((root / 'docs/implementation/sync-release-2026-11-13/registry-audit.json').read_bytes()).hexdigest()}}
    with args.output.open('x') as output:
        output.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'sdk': selected_sdk, 'dependencies': len(dependencies),
                      'retained': [row for row in dependencies if 'retainedReason' in row],
                      'output': str(args.output)}, indent=2))


if __name__ == '__main__':
    main()
