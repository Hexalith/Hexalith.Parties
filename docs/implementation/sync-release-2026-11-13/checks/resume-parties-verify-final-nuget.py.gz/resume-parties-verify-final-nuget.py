"""Independently verify the final public Parties release and every NuGet body."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--version', required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', args.version)
    assert re.fullmatch(r'[0-9a-f]{40}', args.source)
    root = args.root.resolve()
    args.output.mkdir(exist_ok=False)
    repository = 'repos/Hexalith/Hexalith.Parties/'

    def github(path, binary=False):
        command = ['gh', 'api', path]
        if binary:
            command += ['-H', 'Accept: application/octet-stream']
        result = subprocess.check_output(command)
        return result if binary else json.loads(result)

    def download(url):
        for attempt in range(20):
            try:
                with urllib.request.urlopen(url, timeout=45) as response:
                    data = response.read()
                return gzip.decompress(data) if data.startswith(b'\x1f\x8b') else data
            except urllib.error.HTTPError as error:
                if error.code not in (404, 429, 502, 503) or attempt == 19:
                    raise
                time.sleep(15)

    def entries(payload):
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            names = [entry.filename for entry in archive.infolist() if not entry.is_dir()]
            assert len(names) == len(set(names)), 'Duplicate archive member'
            return {name: archive.read(name) for name in names}

    tag = 'v' + args.version
    release = github(repository + 'releases/tags/' + tag)
    assert not release['draft'] and not release['prerelease'] and release['published_at']
    reference = github(repository + 'git/ref/tags/' + tag)['object']
    for _ in range(5):
        if reference['type'] == 'commit':
            break
        assert reference['type'] == 'tag'
        reference = github(repository + 'git/tags/' + reference['sha'])['object']
    assert reference['type'] == 'commit' and reference['sha'] == args.source
    manifest = json.loads(subprocess.check_output(
        ['git', 'show', args.source + ':tools/release-packages.json'], cwd=root))
    identities = [row['id'] for row in manifest['packages']]
    assert len(identities) == len(set(identities)) == 11
    (args.output / 'release.json').write_text(json.dumps(release, indent=2) + '\n')

    def verify(identity):
        filename = identity + '.' + args.version + '.nupkg'
        assets = [asset for asset in release['assets'] if asset['name'] == filename]
        assert len(assets) == 1 and assets[0]['state'] == 'uploaded', filename
        original_payload = github(repository + 'releases/assets/' + str(assets[0]['id']), binary=True)
        original = entries(original_payload)
        key = identity.lower()
        url = f'https://api.nuget.org/v3-flatcontainer/{key}/{args.version}/{key}.{args.version}.nupkg'
        payload = download(url)
        path = args.output / filename
        path.write_bytes(payload)
        signed = entries(payload)
        assert '.signature.p7s' not in original
        assert set(signed) == set(original) | {'.signature.p7s'}, identity
        assert all(signed[name] == data for name, data in original.items()), identity
        nuspecs = [name for name in signed if name.lower().endswith('.nuspec')]
        assert len(nuspecs) == 1
        metadata = next(node for node in ET.fromstring(signed[nuspecs[0]]) if node.tag.endswith('metadata'))
        fields = {node.tag.rsplit('}', 1)[-1]: node for node in metadata}
        assert fields['id'].text == identity and fields['version'].text == args.version
        assert fields['repository'].get('commit') == args.source
        assert fields['repository'].get('url').removesuffix('.git').rstrip('/') == 'https://github.com/Hexalith/Hexalith.Parties'
        assert any(name.startswith('lib/net11.0/') and name.endswith('.dll') for name in signed), identity
        registration = json.loads(download(f'https://api.nuget.org/v3/registration5-gz-semver2/{key}/{args.version}.json'))
        catalog = json.loads(download(registration['catalogEntry']))
        assert catalog['packageHashAlgorithm'].upper() == 'SHA512'
        digest = base64.b64encode(hashlib.sha512(payload).digest()).decode()
        assert catalog['packageHash'] == digest
        result = subprocess.run(['dotnet', 'nuget', 'verify', str(path), '--all'], cwd=root,
                                text=True, capture_output=True, timeout=180)
        (args.output / (identity + '.signature.txt')).write_text(result.stdout + result.stderr)
        assert result.returncode == 0, identity
        return {'id': identity, 'version': args.version, 'source': args.source, 'url': url,
                'sha256': hashlib.sha256(payload).hexdigest(), 'sha512': digest,
                'repositorySignatureVerified': True, 'nuspecSourceVerified': True,
                'net11AssemblyPresent': True, 'originalPayloadFiles': len(original),
                'originalPublisherPayloadMatches': True, 'signedOnlyAddition': '.signature.p7s',
                'githubAssetId': assets[0]['id'],
                'originalPublisherArchiveSha256': hashlib.sha256(original_payload).hexdigest()}

    with ThreadPoolExecutor(max_workers=3) as pool:
        packages = list(pool.map(verify, identities))
    result = {'schema': 'hexalith.parties.independent-public-nuget-verification.v1',
              'release': release['html_url'], 'releaseId': release['id'], 'version': args.version,
              'source': args.source, 'packages': packages, 'verifiedCount': len(packages),
              'scope': 'Public tag/source, eleven official NuGet downloads, repository signatures, catalog SHA512 and exact publisher payload equality; OCI results belong to the normal hosted verifier'}
    (args.output / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'release': result['release'], 'source': args.source,
                      'verifiedPackages': len(packages), 'receipt': str(args.output / 'verification.json')}, indent=2))


if __name__ == '__main__':
    main()
