import hashlib
import importlib.metadata
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml
from markdown_it import MarkdownIt

root = Path.cwd()
packet = root / '_bmad-output/specs/spec-ext-parties-1-contract-amendment'
run = Path(__file__).parent
baseline = json.loads((run / 'baseline.json').read_text())
report_path = packet / 'validation-build.json'
parser = MarkdownIt('commonmark').enable('table')
checks = []

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

def check(name, passed, detail):
    checks.append({'name': name, 'passed': bool(passed), 'detail': detail})

manifest = json.loads((packet / 'source-manifest.json').read_text())
sources = {s['id']: s for s in manifest['sources']}
source_observations = [{'id': s['id'], 'sha256': digest(packet / s['path'])} for s in sources.values()]
check('sixteen_governing_source_hashes', len(sources) == 16 and all(sources[s['id']]['sha256'] == s['sha256'] for s in source_observations), source_observations)
source_repositories = []
for repository in ('agents', 'platform'):
    repository_root = root.parent / repository
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository_root, text=True).strip()
    observations = []
    for source in sources.values():
        source_path = (packet / source['path']).resolve()
        if source_path.is_relative_to(repository_root):
            relative = source_path.relative_to(repository_root).as_posix()
            committed = subprocess.run(['git', 'show', revision + ':' + relative], cwd=repository_root, capture_output=True)
            committed_hash = hashlib.sha256(committed.stdout).hexdigest() if committed.returncode == 0 else None
            observations.append({'id': source['id'], 'path': relative, 'matches_committed_bytes': committed_hash == source['sha256']})
    source_repositories.append({'repository': '../' + repository, 'revision': revision, 'sources': observations, 'scope': 'Named governing files only; unrelated worktree changes are excluded.'})
check('sibling_source_revision_provenance', sum(len(r['sources']) for r in source_repositories) == 14 and all(s['matches_committed_bytes'] for r in source_repositories for s in r['sources']), source_repositories)


clause_text = (packet / 'clause-diff.md').read_text(encoding='utf-8')
clauses = re.findall(r'^## (A-\d{2}) —[^\n]*\n(.*?)(?=^## |\Z)', clause_text, re.M | re.S)
check('six_before_after_clause_pairs', [c[0] for c in clauses] == [f'A-{i:02}' for i in range(1, 7)] and all(c[1].count('**Before (verbatim)**') == c[1].count('**After (proposed, unapproved)**') == 1 for c in clauses), [c[0] for c in clauses])
quotes = []
for clause_id, section in clauses:
    before = section.split('**After (proposed, unapproved)**')[0]
    for source_id, path, quote in re.findall(r'\[([a-z_]+)\]\(([^)]+)\)[^\n]*\n\n```text\n(.*?)\n```', before, re.S):
        source = sources.get(source_id)
        exact = source is not None and path == source['path'] and quote in (packet / path).read_text(encoding='utf-8')
        quotes.append({'clause': clause_id, 'source': source_id, 'matched': exact, 'normalized_excerpt_sha256': hashlib.sha256(quote.encode()).hexdigest()})
check('ten_exact_before_excerpts', len(quotes) == 10 and all(q['matched'] for q in quotes), quotes)

tables = []
in_table = False
for token in parser.parse((packet / 'owner-decisions.md').read_text(encoding='utf-8')):
    if token.type == 'table_open':
        in_table = True
        tables.append([])
    elif token.type == 'table_close':
        in_table = False
    elif in_table and token.type == 'tr_open':
        tables[-1].append([])
    elif in_table and token.type == 'inline':
        tables[-1][-1].append(token.content)
check('five_rendered_owner_decisions', len(tables) == 2 and [r[0] for r in tables[0]] == ['No.', '1', '2', '3', '4', '5'] and all(len(r) == 5 and all(cell.strip() for cell in r) for r in tables[0]), {'rows_including_header': len(tables[0]), 'body_ids': [r[0] for r in tables[0][1:]]})
ledger = json.loads((packet / sources['ledger']['path']).read_text())
required_ids = [d['id'] for d in ledger['decisions'] + ledger['commandBindings']]
mapped_ids = [r[0] for r in tables[1][1:]]
check('twenty_eight_rendered_crosswalk_ids', len(required_ids) == len(set(required_ids)) == len(mapped_ids) == len(set(mapped_ids)) == 28 and set(required_ids) == set(mapped_ids) and all(len(r) == 3 and all(cell.strip() for cell in r) for r in tables[1]), mapped_ids)
ledger_state = {k: ledger[k] for k in ('ownerAccepted', 'available', 'liveQualified', 'acceptedReplacementIntegrationDate')}
ledger_state.update(decision_null_paths=len(ledger['decisionNullPaths']), binding_null_paths=len(ledger['bindingNullPaths']))
check('unresolved_ledger_preserved', ledger_state == {'ownerAccepted': False, 'available': False, 'liveQualified': False, 'acceptedReplacementIntegrationDate': None, 'decision_null_paths': 661, 'binding_null_paths': 165}, ledger_state)

spec_text = (packet / 'SPEC.md').read_text(encoding='utf-8')
frontmatter = yaml.safe_load(spec_text.split('---', 2)[1])
capabilities = re.findall(r'- \*\*(CAP-\d+)\*\*\n  - \*\*intent:\*\* ([^\n]+)\n  - \*\*success:\*\* ([^\n]+)', spec_text)
check('proposal_status_and_capabilities', frontmatter['status'] == 'proposed-unapproved' and [c[0] for c in capabilities] == ['CAP-1', 'CAP-2', 'CAP-3'], {'status': frontmatter['status'], 'capabilities': [c[0] for c in capabilities]})
missing_companions = [p for p in frontmatter['companions'] if not (packet / p).is_file()]
check('sixteen_declared_companions', len(frontmatter['companions']) == 16 and not missing_companions, {'count': len(frontmatter['companions']), 'missing': missing_companions})
bad_links = []
local_links = 0
for name in ('SPEC.md', 'clause-diff.md', 'owner-decisions.md', 'verification-plan.md'):
    for token in parser.parse((packet / name).read_text(encoding='utf-8')):
        for child in token.children or []:
            if child.type == 'link_open':
                href = child.attrGet('href')
                if href and not re.match(r'^[a-z]+:', href) and not href.startswith('#'):
                    local_links += 1
                    target = packet / href.split('#')[0]
                    if not target.is_file():
                        bad_links.append({'file': name, 'href': href})
check('local_links', not bad_links, {'checked': local_links, 'missing': bad_links})

history_names = ['SPEC.md', '.memlog.md', 'clause-diff.md', 'source-manifest.json', 'validation.json', 'validation-final.json']
changed_history = [name for name in history_names if digest(packet / name) != baseline['packet_sha256'][name]]
check('historical_packet_bytes_preserved', not changed_history, {'checked': history_names, 'changed': changed_history})
original_table = subprocess.check_output(['git', 'show', baseline['head'] + ':_bmad-output/specs/spec-ext-parties-1-contract-amendment/owner-decisions.md'], cwd=root).decode()
current_table = (packet / 'owner-decisions.md').read_bytes().decode()
expected_table = original_table.replace('| --- | --- | --- | --- | --- |\r\n\r\n| 1 |', '| --- | --- | --- | --- | --- |\r\n| 1 |', 1)
check('owner_decision_text_unchanged', current_table == expected_table and current_table != original_table, 'Only the blank line between the header delimiter and row 1 was removed.')

allowed_changes = {str((packet / name).relative_to(root)) for name in ('owner-decisions.md', 'verification-plan.md')}
protected_changed = [name for name, sha in baseline['tracked_file_sha256'].items() if name not in allowed_changes and digest(root / name) != sha]
check('tracked_preservation_since_build_baseline', not protected_changed, {'captured_files': len(baseline['tracked_file_sha256']), 'authorized_edits': sorted(allowed_changes), 'unexpected_changes': protected_changed, 'scope': 'Previously tracked non-reference files readable as files; excludes submodules, untracked/ignored files, unlisted sibling files and remote installations.'})
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
index = root / subprocess.check_output(['git', 'rev-parse', '--git-path', 'index'], cwd=root, text=True).strip()
check('git_revision_and_index_preserved_since_build_baseline', head == baseline['head'] and digest(index) == baseline['index_sha256'], {'head': head, 'index_sha256': digest(index)})
command = ['git', '-c', 'core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol', 'diff', '--check', '--', str(packet.relative_to(root))]
whitespace = subprocess.run(command, cwd=root, text=True, capture_output=True)
check('scoped_git_whitespace', whitespace.returncode == 0, {'command': ' '.join(command), 'exit': whitespace.returncode, 'output': whitespace.stdout + whitespace.stderr})

passed = all(c['passed'] for c in checks)
report = {
    'status': 'passed' if passed else 'failed',
    'purpose': 'Static review-artifact build validation only; no amendment approval, backend feasibility or runtime/installed qualification.',
    'checked_at_utc': datetime.now(timezone.utc).isoformat(),
    'baseline_revision': baseline['head'],
    'validation_command': 'python3 ' + str(Path(__file__).resolve()),
    'archived_support': 'validation-build-support.zip (validate.py and baseline.json)',
    'command_scope': 'Run the archived checker from the Parties repository root; it reads sources and emits JSON to stdout without writing files. Historical revision/index preservation checks deliberately fail after that baseline changes. This is an archived document check, not runtime tooling.',
    'parser': {'package': 'markdown-it-py', 'version': importlib.metadata.version('markdown-it-py'), 'preset': 'commonmark', 'enabled_rule': 'table'},
    'packet_sha256': {f.name: digest(f) for f in packet.iterdir() if f.is_file() and f != report_path},
    'checks': checks,
    'semantic_review': 'Independent investigator checked A-01–A-06 against cited local sources and found the table rendering defect; no concrete clause contradiction was identified. Workflow review is recorded separately in the build spec.',
    'limits': ['Checks preserve the named historical reports; they do not turn earlier workspace drift into a pass.', 'No funding, resources, operators, accepted replacement target/date or availability is supplied.', 'Static structure, source quotation and hash checks do not prove completeness or backend physical guarantees.'],
}
print(json.dumps(report, indent=2))
raise SystemExit(0 if passed else 1)
