param([string]$Script, [string]$EvidenceDirectory, [string]$EventStoreRoot, [string]$PartiesRoot)
$ErrorActionPreference = 'Stop'
$callerDirectory = (Get-Location).ProviderPath
$selectionFlags = @("-p:HexalithEventStoreRoot=$EventStoreRoot", "-p:HexalithCommonsRoot=$PartiesRoot/references/Hexalith.Commons", '-p:NuGetAudit=false')
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($Script, [ref]$null, [ref]$errors)
if ($errors.Count) { throw 'Verifier syntax is invalid.' }
$function = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-LocalSourceGraph' }, $true)
if ($null -eq $function) { throw 'Source graph preflight is missing.' }
Invoke-Expression $function.Extent.Text
[IO.Directory]::CreateDirectory($EvidenceDirectory) | Out-Null
Get-LocalSourceGraph (Join-Path $PartiesRoot 'src/Hexalith.Parties/Hexalith.Parties.csproj') 'selected-Parties' -RequireDomainService | ConvertTo-Json
