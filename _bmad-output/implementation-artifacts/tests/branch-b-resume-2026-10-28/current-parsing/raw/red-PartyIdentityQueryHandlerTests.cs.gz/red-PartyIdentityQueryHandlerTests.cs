using System.Text.Json;
using System.Text.Json.Nodes;
using Hexalith.EventStore.Client.Streams;
using Hexalith.EventStore.Contracts.Events;
using Hexalith.EventStore.Contracts.Queries;
using Hexalith.EventStore.Contracts.Security;
using Hexalith.EventStore.Contracts.Streams;
using Hexalith.Parties.Authorization;
using Hexalith.Parties.Client;
using Hexalith.Parties.Contracts;
using Hexalith.Parties.Contracts.Events;
using Hexalith.Parties.Contracts.Models;
using Hexalith.Parties.Contracts.Queries;
using Hexalith.Parties.Contracts.State;
using Hexalith.Parties.Contracts.ValueObjects;
using Hexalith.Parties.Queries;
using Microsoft.Extensions.Options;
using NSubstitute;
using Shouldly;

namespace Hexalith.Parties.Tests.Gateway;

public sealed class PartyIdentityQueryHandlerTests
{
    private static readonly DateTimeOffset Start = DateTimeOffset.UtcNow.AddDays(-1);
    private const string Actor = "01HX0000000000000000000001";
    private static HumanActorBindingEvidence Binding() => new("tenant-a", "party-1", Actor, 1, 1, Start, Start.AddDays(10), "writer", Actor,
        new("synthetic", "party-actor-history-v1", Start.AddDays(10), 1, "custody", true, true, true));
    private static IEventPayload[] Events() => [new PartyCreated { Type = PartyType.Person, CreatedAt = Start, PersonDetails = new PersonDetails { FirstName = "Private", LastName = "Name" } },
        new HumanActorBindingEstablished(new(Binding(), "logical", "digest"), Start, 0)];
    private static QueryEnvelope Envelope<T>(T query) => new("tenant-a", "party", "party-1", typeof(T).FullName!, JsonSerializer.SerializeToUtf8Bytes(query, PartiesJsonOptions.Default), "correlation", "reader", "party-1");
    private static (PartyIdentityQueryService Service, IPartyIdentityAuthority Authority, IAuthoritativeEventStreamReader Reader, IIdentityHistoryCustody Custody, IRetainedIdentityHistoryReader HistoryReader, IOptionsMonitor<PartyIdentityOptions> Options) Service(params IEventPayload[] events)
    {
        IPartyIdentityAuthority authority = Substitute.For<IPartyIdentityAuthority>();
        authority.Admit(Arg.Any<QueryEnvelope>()).Returns(call => new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "correlation", "correlation", "digest"),
            "reader", null, Actor, 1, true, DateTimeOffset.UtcNow, DateTimeOffset.UtcNow.AddMinutes(1), 1), null));
        IAuthoritativeEventStreamReader reader = Substitute.For<IAuthoritativeEventStreamReader>();
        StreamReadEvent[] source = [.. events.Select((item, index) => new StreamReadEvent(index + 1, item.GetType().FullName!, JsonSerializer.SerializeToUtf8Bytes(item, item.GetType(), PartiesJsonOptions.Default), "json", 1, "message", null, null, Start, "writer"))];
        reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>()).Returns(new AuthoritativeStreamReadResult(new(new("tenant-a", "party", "party-1"), source.Length, DateTimeOffset.UtcNow, source, "observation"), null));
        IIdentityHistoryCustody custody = Substitute.For<IIdentityHistoryCustody>();
        custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>()).Returns(true);
        IRetainedIdentityHistoryReader historyReader = Substitute.For<IRetainedIdentityHistoryReader>();
        StreamReadEvent[] retained = [.. source.Where((item, index) => events[index] is IIdentityHistoryEvent)
            .Select(item => item with { MessageId = string.Empty, UserId = null, CorrelationId = null, CausationId = null,
                ProtectionMetadata = EventStorePayloadProtectionMetadata.Unprotected() })];
        long[] excluded = [.. source.Where((item, index) => events[index] is not IIdentityHistoryEvent).Select(item => item.SequenceNumber)];
        historyReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(new(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose,
                source.Length, DateTimeOffset.UtcNow, retained, excluded, "history-observation")
                { AuthorityRevision = "fixture-source-r1", ValidUntil = DateTimeOffset.UtcNow.AddMinutes(1) }, null));
        IOptionsMonitor<PartyIdentityOptions> options = Substitute.For<IOptionsMonitor<PartyIdentityOptions>>();
        options.CurrentValue.Returns(PolicyOptions());
        return (new(authority, TimeProvider.System, reader, custody, historyReader, options), authority, reader, custody, historyReader, options);
    }

    /// <summary>Unsupported current-source observations and unreadable attribution fail before custody lookup.</summary>
    [Theory]
    [InlineData("missing-observation")]
    [InlineData("blank-observation")]
    [InlineData("default-observation-time")]
    [InlineData("ciphertext-format")]
    [InlineData("opaque-payload")]
    [InlineData("unsupported-protection-state")]
    [InlineData("unsupported-format")]
    [InlineData("unsupported-protection-version")]
    [InlineData("event-metadata-zero")]
    [InlineData("event-metadata-negative")]
    [InlineData("event-metadata-future")]
    [InlineData("binding-after-observation")]
    [InlineData("rebind-after-observation")]
    [InlineData("revoke-after-observation")]
    public async Task InvalidCurrentSourceEvidence_DeniesBeforeCustody(string corruption)
    {
        DateTimeOffset boundary = Start.AddHours(1);
        IEventPayload[] events = [new PartyCreated { Type = PartyType.Person, CreatedAt = Start.AddDays(-1) }, Events()[1]];
        if (corruption == "rebind-after-observation")
        {
            HumanActorBindingEvidence successor = Binding() with { BindingVersion = 2, ValidFrom = boundary,
                ValidUntil = boundary.AddDays(10), Custody = Binding().Custody with { ExpiresAt = boundary.AddDays(10) } };
            events = [.. events, new HumanActorBindingRebound(new(successor, "rebind", "rebind-digest"), boundary, 1)];
        }
        else if (corruption == "revoke-after-observation")
        {
            events = [.. events, new HumanActorBindingRevoked("revoke", "revoke-digest", 1, boundary, Binding().Custody)];
        }

        var fixture = Service(events);
        AuthoritativeStreamReadResult original = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
        AuthoritativeEventStream stream = original.Stream!;
        stream = corruption switch
        {
            "missing-observation" => stream with { ObservationId = null! },
            "blank-observation" => stream with { ObservationId = " " },
            "default-observation-time" => stream with { ObservedAt = default },
            "binding-after-observation" => stream with { ObservedAt = Start.AddTicks(-1) },
            "rebind-after-observation" or "revoke-after-observation" => stream with { ObservedAt = boundary.AddTicks(-1) },
            _ => stream with { Events = [stream.Events[0], stream.Events[1] with
                {
                    MetadataVersion = corruption switch { "event-metadata-zero" => 0, "event-metadata-negative" => -1, "event-metadata-future" => 2, _ => 1 },
                    SerializationFormat = corruption switch
                    {
                        "ciphertext-format" => "json+identity-history-v1",
                        "unsupported-format" => "unsupported",
                        _ => "json",
                    },
                    ProtectionMetadata = corruption switch
                    {
                        "ciphertext-format" => EventStorePayloadProtectionMetadata.Unprotected(PayloadProtectionState.Protected)
                            with { Scheme = "party-actor-history-v1" },
                        "opaque-payload" => EventStorePayloadProtectionMetadata.ProviderOpaque(),
                        "unsupported-protection-state" => EventStorePayloadProtectionMetadata.Unprotected((PayloadProtectionState)99),
                        "unsupported-protection-version" => EventStorePayloadProtectionMetadata.Unprotected() with { MetadataVersion = 2 },
                        _ => EventStorePayloadProtectionMetadata.Unprotected(),
                    },
                }] },
        };
        fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
            .Returns(new AuthoritativeStreamReadResult(stream, null));

        PartyIdentityResult result = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Incomplete immutable attribution cannot authorize the current binding, including through a valid successor.</summary>
    /// <param name="corruption">The missing or unsupported recorded attribution.</param>
    /// <param name="hasSuccessor">Whether a complete later binding follows the malformed predecessor.</param>
    [Theory]
    [InlineData("actor-revision", false)]
    [InlineData("actor-revision", true)]
    [InlineData("source", false)]
    [InlineData("source", true)]
    [InlineData("provenance", false)]
    [InlineData("provenance", true)]
    [InlineData("logical-id", false)]
    [InlineData("logical-id", true)]
    [InlineData("intent-digest", false)]
    [InlineData("intent-digest", true)]
    [InlineData("custody-evidence", true)]
    [InlineData("custody-revision", true)]
    [InlineData("custody-purpose", true)]
    [InlineData("custody-policy", true)]
    [InlineData("custody-source-expiry", true)]
    [InlineData("custody-restore", true)]
    [InlineData("custody-derived", true)]
    [InlineData("actor-id", true)]
    [InlineData("duplicate-logical-id", true)]
    public async Task IncompleteCurrentAttributionHistory_DeniesBeforeCustody(string corruption, bool hasSuccessor)
    {
        HumanActorBindingEvidence binding = corruption switch
        {
            "actor-revision" => Binding() with { ActorRevision = 0 },
            "actor-id" => Binding() with { ActorId = "unsupported-actor" },
            "source" => Binding() with { SourceId = " " },
            "provenance" => Binding() with { ProvenanceId = " " },
            "custody-evidence" => Binding() with { Custody = Binding().Custody with { EvidenceId = " " } },
            "custody-revision" => Binding() with { Custody = Binding().Custody with { LifecycleRevision = 0 } },
            "custody-purpose" => Binding() with { Custody = Binding().Custody with { Purpose = "profile" } },
            "custody-policy" => Binding() with { Custody = Binding().Custody with { PolicyId = " " } },
            "custody-source-expiry" => Binding() with { Custody = Binding().Custody with { SourceExpiryEnforced = false } },
            "custody-restore" => Binding() with { Custody = Binding().Custody with { RestoreSafe = false } },
            "custody-derived" => Binding() with { Custody = Binding().Custody with { DerivedCopiesCovered = false } },
            _ => Binding(),
        };
        string logicalId = corruption == "logical-id" ? " " : "logical";
        string digest = corruption == "intent-digest" ? " " : "digest";
        IEventPayload[] events = [Events()[0], new HumanActorBindingEstablished(new(binding, logicalId, digest), Start, 0)];
        if (hasSuccessor)
        {
            DateTimeOffset boundary = Start.AddHours(1);
            HumanActorBindingEvidence successor = Binding() with { BindingVersion = 2, ValidFrom = boundary,
                ValidUntil = boundary.AddDays(10), Custody = Binding().Custody with { ExpiresAt = boundary.AddDays(10) } };
            events = [.. events, new HumanActorBindingRebound(new(successor,
                corruption == "duplicate-logical-id" ? logicalId : "rebind", "rebind-digest"), boundary, 1)];
        }

        var fixture = Service(events);
        PartyIdentityResult result = await fixture.Service.ResolveAsync(
            Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>A later complete rebind cannot hide unsupported custody recorded on a revocation.</summary>
    /// <param name="corruption">The missing or unsupported revocation custody evidence.</param>
    [Theory]
    [InlineData("evidence")]
    [InlineData("revision")]
    [InlineData("purpose")]
    [InlineData("policy")]
    [InlineData("source-expiry")]
    [InlineData("restore")]
    [InlineData("derived")]
    public async Task IncompleteCurrentRevocationHistory_DeniesBeforeCustody(string corruption)
    {
        DateTimeOffset revokedAt = Start.AddHours(1);
        DateTimeOffset reboundAt = Start.AddHours(2);
        IdentityHistoryCustodyEvidence custody = corruption switch
        {
            "evidence" => Binding().Custody with { EvidenceId = " " },
            "revision" => Binding().Custody with { LifecycleRevision = 0 },
            "purpose" => Binding().Custody with { Purpose = "profile" },
            "policy" => Binding().Custody with { PolicyId = " " },
            "source-expiry" => Binding().Custody with { SourceExpiryEnforced = false },
            "restore" => Binding().Custody with { RestoreSafe = false },
            _ => Binding().Custody with { DerivedCopiesCovered = false },
        };
        HumanActorBindingEvidence successor = Binding() with { BindingVersion = 3, ValidFrom = reboundAt,
            ValidUntil = reboundAt.AddDays(10), Custody = Binding().Custody with { ExpiresAt = reboundAt.AddDays(10) } };
        var fixture = Service([.. Events(), new HumanActorBindingRevoked("revoke", "revoke-digest", 1, revokedAt, custody),
            new HumanActorBindingRebound(new(successor, "rebind", "rebind-digest"), reboundAt, 2)]);

        PartyIdentityResult result = await fixture.Service.ResolveAsync(
            Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Complete predecessor and revocation history preserve the recorded current successor.</summary>
    /// <param name="revoked">Whether an explicit revocation precedes the rebind.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task CompleteCurrentRebindHistory_PreservesSuccessor(bool revoked)
    {
        DateTimeOffset boundary = Start.AddHours(2);
        long version = revoked ? 3 : 2;
        HumanActorBindingEvidence successor = Binding() with { BindingVersion = version, ValidFrom = boundary,
            ValidUntil = boundary.AddDays(10), Custody = Binding().Custody with { ExpiresAt = boundary.AddDays(10) } };
        IEventPayload[] events = Events();
        if (revoked)
        {
            events = [.. events, new HumanActorBindingRevoked("revoke", "revoke-digest", 1, Start.AddHours(1), Binding().Custody)];
        }

        var fixture = Service([.. events, new HumanActorBindingRebound(new(successor, "rebind", "rebind-digest"), boundary, version - 1)]);
        PartyIdentityResult result = await fixture.Service.ResolveAsync(
            Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
        result.Evidence!.HumanBinding.ShouldBe(successor);
    }

    /// <summary>Readable JSON preserves eligibility with legacy, plaintext or successfully decrypted protection provenance.</summary>
    [Theory]
    [InlineData("legacy")]
    [InlineData("unprotected")]
    [InlineData("protected-provenance")]
    public async Task SupportedCurrentSourceProtectionMetadata_PreservesEvidence(string metadata)
    {
        var fixture = Service(Events());
        AuthoritativeStreamReadResult original = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
        AuthoritativeEventStream stream = original.Stream! with
        {
            Events = [.. original.Stream!.Events.Select(item => item with
                {
                    ProtectionMetadata = metadata switch
                    {
                        "legacy" => null,
                        "protected-provenance" => EventStorePayloadProtectionMetadata.Unprotected(PayloadProtectionState.Protected)
                            with { Scheme = item.EventTypeName == typeof(HumanActorBindingEstablished).FullName
                                ? "party-actor-history-v1" : "parties-aes-gcm-json-fields" },
                        _ => EventStorePayloadProtectionMetadata.Unprotected(),
                    },
                })],
        };
        fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
            .Returns(new AuthoritativeStreamReadResult(stream, null));

        PartyIdentityResult result = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
        result.Evidence!.HumanBinding!.ActorId.ShouldBe(Actor);
    }

    /// <summary>Suspended current reads cannot release a binding outside its completion interval or source observation.</summary>
    [Theory]
    [InlineData("interval-expiry")]
    [InlineData("custody-expiry")]
    [InlineData("source-rollback")]
    [InlineData("binding-rollback")]
    public async Task CurrentCompletionTimeChangesDuringCustody_DenyEvidence(string change)
    {
        HumanActorBindingEvidence binding = Binding() with { ValidUntil = Start.AddDays(5) };
        if (change == "custody-expiry")
        {
            binding = binding with { ValidUntil = binding.Custody.ExpiresAt };
        }

        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(binding, "logical", "digest"), Start, 0));
        DateTimeOffset now = Start.AddDays(2);
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(_ => now);
        var grant = new IdentityAdmissionEvidence(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"),
            "reader", null, Actor, 1, true, Start.AddDays(-1), Start.AddDays(20), 1);
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(grant, null));
        AuthoritativeStreamReadResult source = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
        // The source is coherent before custody suspends; the rollback occurs during that await.
        DateTimeOffset observedAt = Start.AddDays(1);
        fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
            .Returns(source with { Stream = source.Stream! with { ObservedAt = observedAt } });
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { entered.SetResult(); return pending.Task; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, identityOptions: fixture.Options);
        Task<PartyIdentityResult> result = service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        now = change switch
        {
            "interval-expiry" => binding.ValidUntil!.Value,
            "custody-expiry" => binding.Custody.ExpiresAt,
            "source-rollback" => observedAt.AddTicks(-1),
            _ => binding.ValidFrom.AddTicks(-1),
        };
        pending.SetResult(true);
        PartyIdentityResult completed = await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        completed.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        completed.Evidence.ShouldBeNull();
    }

    /// <summary>Authority withdrawn while either current dependency is suspended cannot release evidence.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task CurrentAuthorityChangesDuringAwait_DenyEvidence(bool inCustody)
    {
        var fixture = Service(Events());
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        Action complete;
        if (inCustody)
        {
            var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.SetResult(); return pending.Task; });
            complete = () => pending.SetResult(true);
        }
        else
        {
            AuthoritativeStreamReadResult source = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
            var pending = new TaskCompletionSource<AuthoritativeStreamReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.SetResult(); return pending.Task; });
            complete = () => pending.SetResult(source);
        }

        Task result = AssertUnavailableAsync(fixture.Service, historical: false);
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(null, "authority-withdrawn"));
        complete();
        await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
    }

    [Fact]
    public async Task CustodyExpiryCrossingAwait_DeniesHistoricalEvidence()
    {
        var fixture = Service(Events());
        DateTimeOffset now = Start.AddDays(9);
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(_ => now);
        var admitted = new IdentityAdmissionEvidence(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"),
            "reader", null, Actor, 1, false, Start, Start.AddDays(20), 1);
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(admitted, null));
        RetainedIdentityHistoryReadResult source = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(source with { Stream = source.Stream! with { ValidUntil = Binding().Custody.ExpiresAt } });
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { now = Binding().Custody.ExpiresAt; return true; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);
        HumanActorBindingResult result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(HumanActorBindingOutcome.Expired);
        result.Evidence.ShouldBeNull();
        result.BindingSourcePosition.ShouldBe(0);
    }

    [Theory]
    [InlineData("revoked")]
    [InlineData("different-actor")]
    [InlineData("different-revision")]
    [InlineData("different-source")]
    public async Task ReadAuthorityChangesDuringCustody_DenyWithoutSubstitutingActor(string change)
    {
        var fixture = Service(Events());
        IdentityAdmissionEvidence original = fixture.Authority.Admit(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1))).Evidence!;
        IdentityAdmissionEvidence? changed = change switch
        {
            "revoked" => null,
            "different-actor" => original with { TargetActorId = "01HX0000000000000000000002" },
            "different-revision" => original with { AuthorityRevision = original.AuthorityRevision + 1 },
            _ => original with { SourceId = "different-reader" },
        };
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(original, null),
            new PartyIdentityAdmissionResult(original, null), new PartyIdentityAdmissionResult(changed, changed is null ? "authority-revoked" : null));
        HumanActorBindingResult result = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        result.BindingSourcePosition.ShouldBe(0);
    }

    [Fact]
    public async Task RetainedCertificateExpiryCrossingCustodyAwait_DeniesWithoutRenewingObservation()
    {
        var fixture = Service(Events());
        RetainedIdentityHistoryReadResult source = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        DateTimeOffset now = DateTimeOffset.UtcNow.AddSeconds(1);
        DateTimeOffset deadline = now.AddSeconds(1);
        source = source with { Stream = source.Stream! with { ValidUntil = deadline } };
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(source);
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(_ => now);
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { now = deadline; return true; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);
        HumanActorBindingResult result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        source.Stream!.ValidUntil.ShouldBe(deadline);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
    }

    [Fact]
    public async Task ErasedProfile_CurrentReadFailsWhileIndependentHistoryKeepsOriginalPosition()
    {
        var fixture = Service([.. Events(), new PartyErased { TenantId = "tenant-a", PartyId = "party-1", ErasedAt = Start.AddHours(1) }]);
        fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
            .Returns(new AuthoritativeStreamReadResult(null, "profile-key-destroyed"));
        PartyIdentityResult current = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
        current.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        HumanActorBindingResult historical = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        historical.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        historical.SourcePosition.ShouldBe(3);
        historical.BindingSourcePosition.ShouldBe(2);
        historical.Evidence!.ActorId.ShouldBe(Actor);
        JsonSerializer.Serialize(historical, PartiesJsonOptions.Default).ShouldNotContain("Private");
        await fixture.Reader.Received(1).ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task SerializedRetainedSource_ReconstructsBothIntervalsWithoutProfileOrCurrentBinding()
    {
        DateTimeOffset boundary = Start.AddHours(1);
        string successor = "01HX0000000000000000000002";
        HumanActorBindingEvidence next = Binding() with { ActorId = successor, BindingVersion = 2, ValidFrom = boundary, ValidUntil = boundary.AddDays(10),
            Custody = Binding().Custody with { ExpiresAt = boundary.AddDays(10) } };
        var fixture = Service([.. Events(), new HumanActorBindingRebound(new(next, "rebind", "digest-two"), boundary, 1),
            new PartyErased { TenantId = "tenant-a", PartyId = "party-1", ErasedAt = boundary }]);
        RetainedIdentityHistoryReadResult source = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        // This exercises the stored wire representation and a fresh domain service, not live storage/restore qualification.
        byte[] stored = JsonSerializer.SerializeToUtf8Bytes(source, PartiesJsonOptions.Default);
        stored.Length.ShouldBeGreaterThan(0);
        string serialized = System.Text.Encoding.UTF8.GetString(stored);
        serialized.ShouldNotContain("Private");
        serialized.ShouldNotContain(nameof(PartyCreated));
        RetainedIdentityHistoryReadResult restored = JsonSerializer.Deserialize<RetainedIdentityHistoryReadResult>(stored, PartiesJsonOptions.Default)!;
        IRetainedIdentityHistoryReader restoredReader = Substitute.For<IRetainedIdentityHistoryReader>();
        restoredReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(restored);
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(call =>
        {
            string actor = JsonSerializer.Deserialize<ResolveHumanActorBindingAt>(call.Arg<QueryEnvelope>().Payload, PartiesJsonOptions.Default)!.ExpectedActorId;
            return new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null, actor,
                3, false, DateTimeOffset.UtcNow, DateTimeOffset.UtcNow.AddMinutes(1), 1), null);
        });
        var restarted = new PartyIdentityQueryService(fixture.Authority, TimeProvider.System, custody: fixture.Custody, historyReader: restoredReader, identityOptions: fixture.Options);
        HumanActorBindingResult before = await restarted.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary.AddTicks(-1), Actor, 1)), TestContext.Current.CancellationToken);
        HumanActorBindingResult at = await restarted.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary, successor, 2)), TestContext.Current.CancellationToken);
        before.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        at.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        before.Evidence!.ValidUntil.ShouldBe(boundary);
        before.BindingSourcePosition.ShouldBe(2);
        at.BindingSourcePosition.ShouldBe(3);
        at.SourcePosition.ShouldBe(4);
    }

    [Theory]
    [InlineData("gap")]
    [InlineData("overlap")]
    [InlineData("profile-substitution")]
    [InlineData("wrong-purpose")]
    [InlineData("foreign-binding")]
    [InlineData("transit-expiry")]
    [InlineData("missing-authority")]
    [InlineData("future-observation")]
    [InlineData("short-name-substitution")]
    [InlineData("assembly-qualified-substitution")]
    [InlineData("namespace-alias-substitution")]
    public async Task RetainedCertificateOrEventSubstitution_DeniesWithoutProfileFallback(string corruption)
    {
        var fixture = Service(Events());
        RetainedIdentityHistoryReadResult original = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        RetainedIdentityHistoryStream stream = original.Stream!;
        stream = corruption switch
        {
            "gap" => stream with { ExcludedSequences = [] },
            "overlap" => stream with { ExcludedSequences = [2] },
            "wrong-purpose" => stream with { Purpose = "party-profile" },
            "transit-expiry" => stream with { ValidUntil = DateTimeOffset.UtcNow.AddTicks(-1) },
            "missing-authority" => stream with { AuthorityRevision = null },
            "future-observation" => stream with { ObservedAt = DateTimeOffset.UtcNow.AddMinutes(1) },
            "short-name-substitution" => stream with { Events = [stream.Events[0] with { EventTypeName = nameof(HumanActorBindingEstablished) }] },
            "assembly-qualified-substitution" => stream with { Events = [stream.Events[0] with { EventTypeName = typeof(HumanActorBindingEstablished).AssemblyQualifiedName! }] },
            "namespace-alias-substitution" => stream with { Events = [stream.Events[0] with { EventTypeName = "Legacy.Parties.Contracts.Events.HumanActorBindingEstablished" }] },
            "profile-substitution" => stream with { Events = [stream.Events[0] with
                { EventTypeName = typeof(PartyCreated).FullName!, Payload = JsonSerializer.SerializeToUtf8Bytes(Events()[0], PartiesJsonOptions.Default) }] },
            _ => stream with { Events = [stream.Events[0] with { Payload = JsonSerializer.SerializeToUtf8Bytes(
                new HumanActorBindingEstablished(new(Binding() with { TenantId = "tenant-b" }, "logical", "digest"), Start, 0), PartiesJsonOptions.Default) }] },
        };
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(stream, null));
        HumanActorBindingResult result = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        result.BindingSourcePosition.ShouldBe(0);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>An expired transition after a retained binding cannot be accepted as an expired prefix.</summary>
    [Theory]
    [InlineData(nameof(HumanActorBindingEstablished))]
    [InlineData(nameof(HumanActorBindingRebound))]
    [InlineData(nameof(HumanActorBindingRevoked))]
    public async Task ExpiredTransitionAfterRetainedBinding_DeniesBeforeCustody(string eventName)
    {
        var fixture = Service(Events());
        RetainedIdentityHistoryReadResult original = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        RetainedIdentityHistoryStream stream = original.Stream!;
        JsonNode serialized = JsonSerializer.SerializeToNode(stream, PartiesJsonOptions.Default)!;
        serialized["head"] = stream.Head + 1;
        // Keep the fixture compatible with older packages that have no expired-transition API.
        // An expired prefix may support successor continuity; an expired suffix must still be denied.
        serialized["expiredEvents"] = JsonSerializer.SerializeToNode(new[]
        {
            new
            {
                stream.Identity,
                stream.Purpose,
                PolicyId = fixture.Options.CurrentValue.PolicyId,
                SourceSequence = stream.Head + 1,
                EventTypeName = $"Hexalith.Parties.Contracts.Events.{eventName}",
                SealedPayloadDigest = new string('a', 64),
                DestructionReceiptId = "fixture-destruction-receipt",
                LifecycleRevision = 1L,
                AuthorityRevision = "fixture-terminal-r1",
                stream.ObservedAt,
                stream.ValidUntil,
                ContractVersion = 1,
            },
        }, PartiesJsonOptions.Default);
        RetainedIdentityHistoryStream extended = serialized.Deserialize<RetainedIdentityHistoryStream>(PartiesJsonOptions.Default)!;
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(extended, null));

        HumanActorBindingResult result = await fixture.Service.ResolveAtAsync(
            Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        result.BindingSourcePosition.ShouldBe(0);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
    }

    [Fact]
    public async Task MissingRetainedReaderOrExpiredCustody_CannotFallBackToAvailableFullProfile()
    {
        var fixture = Service(Events());
        var missing = new PartyIdentityQueryService(fixture.Authority, TimeProvider.System, fixture.Reader, fixture.Custody, identityOptions: fixture.Options);
        var query = new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1);
        (await missing.ResolveAtAsync(Envelope(query), TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>()).Returns(false);
        HumanActorBindingResult expired = await fixture.Service.ResolveAtAsync(Envelope(query), TestContext.Current.CancellationToken);
        expired.Outcome.ShouldBe(HumanActorBindingOutcome.Expired);
        expired.Evidence.ShouldBeNull();
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
    }

    [Fact]
    public async Task ProvisionedOrganization_KeepsBranchBClassificationAndNeverCarriesHumanBinding()
    {
        var intent = new AgentPartyIdentity("tenant-a", Actor, "party-1", 1, "provision", new string('a', 64), Start);
        var fixture = Service(new PartyCreated { Type = PartyType.Organization, CreatedAt = Start,
                OrganizationDetails = new OrganizationDetails { LegalName = "Agent" } },
            new AgentPartyProvisioned(new(intent, 2, "provisioner")));
        fixture.Options.CurrentValue.Returns(new PartyIdentityOptions());
        PartyIdentityResult result = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1")), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
        result.Evidence!.Classification.ShouldBe(PartyIdentityClassification.Organization);
        result.Evidence.HumanBinding.ShouldBeNull();
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task InactiveOrRestrictedHuman_ReturnsIneligibleWithoutUsableBinding(bool inactive)
    {
        IEventPayload transition = inactive ? new PartyDeactivated()
            : new ProcessingRestricted { TenantId = "tenant-a", PartyId = "party-1", RestrictedAt = Start };
        var fixture = Service([.. Events(), transition]);
        PartyIdentityResult result = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(PartyIdentityOutcome.Ineligible);
        result.Evidence!.HumanBinding.ShouldBeNull();
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    [Theory]
    [InlineData(PartyType.Person, "active")]
    [InlineData(PartyType.Person, "unbound")]
    [InlineData(PartyType.Person, "inactive")]
    [InlineData(PartyType.Person, "restricted")]
    [InlineData(PartyType.Person, "erasing")]
    [InlineData(PartyType.Person, "erased")]
    [InlineData(PartyType.Organization, "active")]
    [InlineData(PartyType.Organization, "inactive")]
    [InlineData(PartyType.Organization, "restricted")]
    [InlineData(PartyType.Organization, "erasing")]
    [InlineData(PartyType.Organization, "erased")]
    [InlineData(PartyType.Unknown, "active")]
    [InlineData(PartyType.Unknown, "inactive")]
    [InlineData(PartyType.Unknown, "restricted")]
    [InlineData(PartyType.Unknown, "erasing")]
    [InlineData(PartyType.Unknown, "erased")]
    public async Task CurrentIdentity_ProducerAndHttpClientAgreeOnEligibility(PartyType type, string lifecycle)
    {
        IEventPayload[] events = type == PartyType.Person && lifecycle != "unbound"
            ? Events() : [new PartyCreated { Type = type, CreatedAt = Start }];
        IEventPayload? transition = lifecycle switch
        {
            "inactive" => new PartyDeactivated(),
            "restricted" => new ProcessingRestricted { TenantId = "tenant-a", PartyId = "party-1", RestrictedAt = Start },
            "erasing" => new ErasePartyRequested { TenantId = "tenant-a", PartyId = "party-1", RequestedAt = Start, RequestedBy = "operator" },
            "erased" => new PartyErased { TenantId = "tenant-a", PartyId = "party-1", ErasedAt = Start },
            _ => null,
        };
        if (transition is not null)
        {
            events = [.. events, transition];
        }

        var fixture = Service(events);
        using var http = new HttpClient(new PartyIdentityRoundTripHandler(new(fixture.Service)))
        {
            BaseAddress = new Uri("https://gateway.test/"),
        };
        var client = new HttpPartiesIdentityClient(http);
        PartyIdentityResult result = await client.ResolvePartyIdentityAsync("tenant-a", new("tenant-a", "party-1", Actor), TestContext.Current.CancellationToken);

        bool resolved = type != PartyType.Unknown && lifecycle == "active";
        result.Outcome.ShouldBe(resolved ? PartyIdentityOutcome.Resolved : PartyIdentityOutcome.Ineligible);
        PartyIdentityEvidence evidence = result.Evidence.ShouldNotBeNull();
        evidence.ContractVersion.ShouldBe(1);
        evidence.TenantId.ShouldBe("tenant-a");
        evidence.PartyId.ShouldBe("party-1");
        evidence.Classification.ShouldBe(type switch
        {
            PartyType.Person => PartyIdentityClassification.Human,
            PartyType.Organization => PartyIdentityClassification.Organization,
            _ => PartyIdentityClassification.Unknown,
        });
        evidence.SourcePosition.ShouldBe(events.Length);
        evidence.ObservationId.ShouldBe("observation");
        AuthoritativeStreamReadResult source = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
        evidence.ObservedAt.ShouldBe(source.Stream!.ObservedAt);
        evidence.IsActive.ShouldBe(lifecycle != "inactive");
        evidence.IsRestricted.ShouldBe(lifecycle == "restricted");
        evidence.IsErasingOrErased.ShouldBe(lifecycle is "erasing" or "erased");
        if (resolved && type == PartyType.Person)
        {
            evidence.HumanBinding.ShouldBe(Binding());
        }
        else
        {
            evidence.HumanBinding.ShouldBeNull();
            await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
        }
    }

    [Fact]
    public async Task CurrentHuman_RequiresCompleteSourceAndCurrentExactActor()
    {
        var fixture = Service(Events());
        PartyIdentityResult result = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
        result.Evidence!.Classification.ShouldBe(PartyIdentityClassification.Human);
        result.Evidence.HumanBinding!.ActorId.ShouldBe(Actor);
        JsonSerializer.Serialize(result, PartiesJsonOptions.Default).ShouldNotContain("Private");
        IdentityAdmissionEvidence original = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor))).Evidence!;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(original with { TargetActorId = "01HX0000000000000000000002" }, null));
        (await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", "01HX0000000000000000000002")), TestContext.Current.CancellationToken)).Outcome.ShouldBe(PartyIdentityOutcome.Ineligible);
    }

    /// <summary>Actor-target admission must match before any protected current source is read.</summary>
    /// <param name="type">The classification of the otherwise available source.</param>
    /// <param name="admittedActor">The missing or differently admitted actor.</param>
    [Theory]
    [InlineData(PartyType.Person, null)]
    [InlineData(PartyType.Person, "01HX0000000000000000000002")]
    [InlineData(PartyType.Organization, null)]
    [InlineData(PartyType.Organization, "01HX0000000000000000000002")]
    public async Task CurrentWrongAuthorizedActor_DeniesBeforeSourceRead(PartyType type, string? admittedActor)
    {
        var fixture = Service(new PartyCreated { Type = type, CreatedAt = Start });
        IdentityAdmissionEvidence original = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor))).Evidence!;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(original with { TargetActorId = admittedActor }, null));

        PartyIdentityResult result = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
        await fixture.HistoryReader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default!, default);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    [Fact]
    public async Task HistoricalRead_DoesNotRequireCurrentActorActivityAndHonorsHalfOpenBoundary()
    {
        var fixture = Service(Events());
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null, Actor, 2, false, DateTimeOffset.UtcNow, DateTimeOffset.UtcNow.AddMinutes(1), 1), null));
        var query = new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1);
        (await fixture.Service.ResolveAtAsync(Envelope(query), TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        (await fixture.Service.ResolveAtAsync(Envelope(query with { ActionAt = Start.AddTicks(-1) }), TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Gap);
        (await fixture.Service.ResolveAtAsync(Envelope(query with { ExpectedBindingVersion = 2 }), TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Mismatch);
    }

    /// <summary>Gap and mismatch remain only when admission is still current after the post-fold policy await.</summary>
    /// <param name="mismatch">The historical query expects a binding version that is not current.</param>
    /// <param name="expireDuringPolicy">The post-fold policy read stalls until admission has expired.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task HistoricalOutcomes_RecheckAuthorityAfterPostFoldPolicy(bool mismatch, bool expireDuringPolicy)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        DateTimeOffset issued = clock.GetUtcNow();
        var admitted = new IdentityAdmissionEvidence(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"),
            "reader", null, Actor, 2, false, issued, issued.AddSeconds(5), 1);
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(admitted, null));
        PartyIdentityOptions configured = PolicyOptions();
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        int reads = 0;
        fixture.Options.CurrentValue.Returns(_ =>
        {
            if (expireDuringPolicy && Interlocked.Increment(ref reads) == 4)
            {
                entered.TrySetResult();
                release.Wait(TestContext.Current.CancellationToken);
            }

            return configured;
        });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        var query = new ResolveHumanActorBindingAt("tenant-a", "party-1", mismatch ? Start : Start.AddTicks(-1), Actor, mismatch ? 2 : 1);
        Task<HumanActorBindingResult> result = service.ResolveAtAsync(Envelope(query), TestContext.Current.CancellationToken);
        if (expireDuringPolicy)
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            advance(TimeSpan.FromSeconds(6), false);
            release.Set();
        }

        HumanActorBindingResult outcome = await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        outcome.Evidence.ShouldBeNull();
        outcome.Outcome.ShouldBe(expireDuringPolicy
            ? HumanActorBindingOutcome.Unavailable
            : mismatch ? HumanActorBindingOutcome.Mismatch : HumanActorBindingOutcome.Gap);
    }

    [Fact]
    public async Task HistoricalReplay_BeforeBoundaryReturnsOriginalAndAtBoundaryReturnsSuccessor()
    {
        DateTimeOffset boundary = Start.AddHours(1);
        string successor = "01HX0000000000000000000002";
        HumanActorBindingEvidence second = Binding() with { ActorId = successor, BindingVersion = 2, ValidFrom = boundary, ValidUntil = boundary.AddDays(10),
            Custody = Binding().Custody with { ExpiresAt = boundary.AddDays(10) } };
        var fixture = Service(Events().Append(new HumanActorBindingRebound(new(second, "rebind", "digest-two"), boundary, 1)).ToArray());
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(call =>
        {
            string target = JsonSerializer.Deserialize<ResolveHumanActorBindingAt>(call.Arg<QueryEnvelope>().Payload, PartiesJsonOptions.Default)!.ExpectedActorId;
            return new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null, target, 3, false, DateTimeOffset.UtcNow, DateTimeOffset.UtcNow.AddMinutes(1), 1), null);
        });
        HumanActorBindingResult before = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary.AddTicks(-1), Actor, 1)), TestContext.Current.CancellationToken);
        HumanActorBindingResult at = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary, successor, 2)), TestContext.Current.CancellationToken);
        before.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        at.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        before.Evidence!.ActorId.ShouldBe(Actor);
        at.Evidence!.ActorId.ShouldBe(successor);
        before.Evidence.ValidUntil.ShouldBe(boundary);
    }

    [Fact]
    public async Task ForeignAuthoritativeSourceAndFutureAction_DenyWithNoEvidence()
    {
        var fixture = Service(new PartyCreated { Type = PartyType.Organization, OrganizationDetails = new OrganizationDetails { LegalName = "Foreign" } });
        fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
            .Returns(new AuthoritativeStreamReadResult(new(new("tenant-b", "party", "foreign-party"), 1, DateTimeOffset.UtcNow,
                [new(1, typeof(PartyCreated).FullName!, JsonSerializer.SerializeToUtf8Bytes(new PartyCreated { Type = PartyType.Organization }, PartiesJsonOptions.Default), "json", 1, "m", null, null, Start, "writer")], "observation"), null));
        PartyIdentityResult current = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1")), TestContext.Current.CancellationToken);
        current.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        current.Evidence.ShouldBeNull();
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(new(new("tenant-b", "party", "foreign-party"), RetainedIdentityHistoryReadRequest.AttributionPurpose,
                0, DateTimeOffset.UtcNow, [], [], "history-observation"), null));
        HumanActorBindingResult history = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        history.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        history.Evidence.ShouldBeNull();
        var futureFixture = Service(Events());
        HumanActorBindingResult future = await futureFixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", DateTimeOffset.UtcNow.AddDays(1), Actor, 1)), TestContext.Current.CancellationToken);
        future.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        future.Evidence.ShouldBeNull();
    }

    [Fact]
    public async Task ValidRevocationReplay_PreservesBeforeBoundaryAndReturnsGapAtBoundary()
    {
        DateTimeOffset boundary = Start.AddHours(1);
        var fixture = Service([.. Events(), new HumanActorBindingRevoked("revoke", "digest-two", 1, boundary, Binding().Custody)]);
        HumanActorBindingResult before = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary.AddTicks(-1), Actor, 1)), TestContext.Current.CancellationToken);
        before.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        before.Evidence!.ActorId.ShouldBe(Actor);
        before.Evidence.BindingVersion.ShouldBe(1);
        before.Evidence.ValidUntil.ShouldBe(boundary);
        HumanActorBindingResult at = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary, Actor, 1)), TestContext.Current.CancellationToken);
        at.Outcome.ShouldBe(HumanActorBindingOutcome.Gap);
        at.Evidence.ShouldBeNull();
    }

    [Fact]
    public async Task WrongAuthorizedActor_DeniesBeforeSourceRead()
    {
        var fixture = Service(Events());
        var query = new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, "01HX0000000000000000000002", 1);
        (await fixture.Service.ResolveAtAsync(Envelope(query), TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
        await fixture.HistoryReader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default!, default);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task RevocationWithoutLivePredecessor_DeniesWithNoEvidence(bool missingPredecessor)
    {
        IEventPayload[] events = missingPredecessor ? [Events()[0]] : Events();
        var fixture = Service([.. events, new HumanActorBindingRevoked("revoke", "digest-two", missingPredecessor ? 0 : 1, Start, Binding().Custody)]);
        PartyIdentityResult current = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
        current.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        current.Evidence.ShouldBeNull();
        HumanActorBindingResult history = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        history.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        history.Evidence.ShouldBeNull();
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task NonFiniteOrBeyondCustodyHistory_DeniesWithNoEvidence(bool missingEnd)
    {
        HumanActorBindingEvidence malformed = Binding() with
        {
            ValidUntil = missingEnd ? null : Binding().Custody.ExpiresAt.AddTicks(1),
        };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(malformed, "logical", "digest"), Start, 0));
        PartyIdentityResult current = await fixture.Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
        current.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
        current.Evidence.ShouldBeNull();
        HumanActorBindingResult history = await fixture.Service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
        history.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        history.Evidence.ShouldBeNull();
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    [Fact]
    public async Task CustodyFailureOrNetworkFailure_IsUnavailableAndCancellationPropagates()
    {
        var fixture = Service(Events());
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromException<bool>(new HttpRequestException("unavailable")));
        var query = new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1);
        (await fixture.Service.ResolveAtAsync(Envelope(query), TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        using var canceled = new CancellationTokenSource();
        await canceled.CancelAsync();
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(call => Task.FromCanceled<RetainedIdentityHistoryReadResult>(call.Arg<CancellationToken>()));
        await Should.ThrowAsync<OperationCanceledException>(() => fixture.Service.ResolveAtAsync(Envelope(query), canceled.Token));
    }

    [Fact]
    public async Task UncreatedInactiveRestrictedUnknownAndErased_AreNeverResolved()
    {
        foreach (IEventPayload[] events in new[] { Array.Empty<IEventPayload>(), [new PartyCreated { Type = PartyType.Unknown }],
            Events().Append(new PartyDeactivated()).ToArray(), Events().Append(new ProcessingRestricted { TenantId = "tenant-a", PartyId = "party-1", RestrictedAt = Start }).ToArray(),
            Events().Append(new PartyErased { TenantId = "tenant-a", PartyId = "party-1", ErasedAt = Start }).ToArray() })
        {
            (await Service(events).Service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken)).Outcome.ShouldNotBe(PartyIdentityOutcome.Resolved);
        }
    }

    /// <summary>Verifies pre cancelled query  does not consult authority or readers.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task PreCancelledQuery_DoesNotConsultAuthorityOrReaders(bool historical)
    {
        var fixture = Service(Events());
        using var caller = new CancellationTokenSource();
        await caller.CancelAsync();
        OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() => InvokeIdentityAsync(fixture.Service, historical, caller.Token));
        exception.CancellationToken.ShouldBe(caller.Token);
        fixture.Authority.DidNotReceiveWithAnyArgs().Admit(default(QueryEnvelope)!);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
        await fixture.HistoryReader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default!, default);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Verifies reader cancels then returns valid source  does not release identity.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ReaderCancelsThenReturnsValidSource_DoesNotReleaseIdentity(bool historical)
    {
        var fixture = Service(Events());
        using var caller = new CancellationTokenSource();
        if (historical)
        {
            RetainedIdentityHistoryReadResult valid = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
            fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
                .Returns(_ => { caller.Cancel(); return Task.FromResult(valid); });
        }
        else
        {
            AuthoritativeStreamReadResult valid = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(_ => { caller.Cancel(); return Task.FromResult(valid); });
        }

        await Should.ThrowAsync<OperationCanceledException>(() => InvokeIdentityAsync(fixture.Service, historical, caller.Token));
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Verifies non cooperative reader or custody  caller can cancel outstanding read.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task NonCooperativeReaderOrCustody_CallerCanCancelOutstandingRead(bool historical, bool inCustody)
    {
        var fixture = Service(Events());
        using var caller = new CancellationTokenSource();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        if (inCustody)
        {
            var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.TrySetResult(); return pending.Task; });
        }
        else if (historical)
        {
            var pending = new TaskCompletionSource<RetainedIdentityHistoryReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.TrySetResult(); return pending.Task; });
        }
        else
        {
            var pending = new TaskCompletionSource<AuthoritativeStreamReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.TrySetResult(); return pending.Task; });
        }

        Task result = InvokeIdentityAsync(fixture.Service, historical, caller.Token);
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        await caller.CancelAsync();
        OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() => result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken));
        exception.CancellationToken.ShouldBe(caller.Token);
    }

    /// <summary>Verifies custody cancels then returns  does not consult final authority or release identity.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task CustodyCancelsThenReturns_DoesNotConsultFinalAuthorityOrReleaseIdentity(bool historical, bool canRead)
    {
        var fixture = Service(Events());
        using var caller = new CancellationTokenSource();
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { caller.Cancel(); return Task.FromResult(canRead); });
        await Should.ThrowAsync<OperationCanceledException>(() => InvokeIdentityAsync(fixture.Service, historical, caller.Token));
        fixture.Authority.Received(historical ? 2 : 1).Admit(Arg.Any<QueryEnvelope>());
    }

    /// <summary>Verifies final authority cancels then returns valid grant  does not release identity.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task FinalAuthorityCancelsThenReturnsValidGrant_DoesNotReleaseIdentity(bool historical)
    {
        var fixture = Service(Events());
        using var caller = new CancellationTokenSource();
        PartyIdentityAdmissionResult grant = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)));
        int calls = 0;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(_ =>
        {
            if (++calls == (historical ? 3 : 2))
            {
                caller.Cancel();
            }

            return grant;
        });
        await Should.ThrowAsync<OperationCanceledException>(() => InvokeIdentityAsync(fixture.Service, historical, caller.Token));
    }

    /// <summary>Missing or unsupported policy cannot release identity even when custody reports readable.</summary>
    [Theory]
    [InlineData("unregistered")]
    [InlineData("missing-id")]
    [InlineData("blank-id")]
    [InlineData("missing-duration")]
    [InlineData("zero-duration")]
    [InlineData("missing-trigger")]
    [InlineData("unsupported-trigger")]
    public async Task UnconfiguredPolicy_DeniesBothBindingReads(string missing)
    {
        var fixture = Service(Events());
        PartyIdentityOptions policy = PolicyOptions();
        switch (missing)
        {
            case "missing-id": policy.PolicyId = null; break;
            case "blank-id": policy.PolicyId = " "; break;
            case "missing-duration": policy.Retention = null; break;
            case "zero-duration": policy.Retention = TimeSpan.Zero; break;
            case "missing-trigger": policy.ExpiryTrigger = null; break;
            case "unsupported-trigger": policy.ExpiryTrigger = "party-erased-at"; break;
        }

        fixture.Options.CurrentValue.Returns(policy);
        var service = new PartyIdentityQueryService(fixture.Authority, TimeProvider.System, fixture.Reader,
            fixture.Custody, fixture.HistoryReader, missing == "unregistered" ? null : fixture.Options);
        await AssertUnavailableAsync(service, historical: true);
        await fixture.HistoryReader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default!, default);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
        await AssertUnavailableAsync(service, historical: false);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>An accepted custody response does not substitute for exact policy and expiry matching.</summary>
    [Theory]
    [InlineData("policy-version")]
    [InlineData("duration")]
    [InlineData("recorded-expiry")]
    [InlineData("purpose")]
    [InlineData("source-expiry")]
    [InlineData("restore")]
    [InlineData("derived-copies")]
    public async Task MismatchedPolicy_DeniesBothBindingReadsWithoutCustody(string mismatch)
    {
        IdentityHistoryCustodyEvidence custody = Binding().Custody;
        custody = mismatch switch
        {
            "recorded-expiry" => custody with { ExpiresAt = custody.ExpiresAt.AddSeconds(1) },
            "purpose" => custody with { Purpose = "party-profile" },
            "source-expiry" => custody with { SourceExpiryEnforced = false },
            "restore" => custody with { RestoreSafe = false },
            "derived-copies" => custody with { DerivedCopiesCovered = false },
            _ => custody,
        };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(
            new(Binding() with { Custody = custody }, "logical", "digest"), Start, 0));
        PartyIdentityOptions policy = PolicyOptions();
        if (mismatch == "policy-version")
        {
            policy.PolicyId = "synthetic-v2";
        }
        else if (mismatch == "duration")
        {
            policy.Retention = TimeSpan.FromDays(11);
        }

        fixture.Options.CurrentValue.Returns(policy);
        await AssertUnavailableAsync(fixture.Service, historical: true);
        await AssertUnavailableAsync(fixture.Service, historical: false);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Actual suspended reads cannot release identity after policy withdrawal or a changed duration.</summary>
    [Theory]
    [InlineData(false, false, false)]
    [InlineData(true, false, false)]
    [InlineData(false, true, false)]
    [InlineData(true, true, false)]
    [InlineData(false, false, true)]
    [InlineData(true, false, true)]
    [InlineData(false, true, true)]
    [InlineData(true, true, true)]
    public async Task PolicyChangesDuringAwait_DenyWithoutRelabelingExpiry(bool historical, bool inCustody, bool remove)
    {
        var fixture = Service(Events());
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        Action complete;
        if (inCustody)
        {
            var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.TrySetResult(); return pending.Task; });
            complete = () => pending.SetResult(true);
        }
        else if (historical)
        {
            RetainedIdentityHistoryReadResult valid = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
                RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
            var pending = new TaskCompletionSource<RetainedIdentityHistoryReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.TrySetResult(); return pending.Task; });
            complete = () => pending.SetResult(valid);
        }
        else
        {
            AuthoritativeStreamReadResult valid = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
            var pending = new TaskCompletionSource<AuthoritativeStreamReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(_ => { entered.TrySetResult(); return pending.Task; });
            complete = () => pending.SetResult(valid);
        }

        Task result = AssertUnavailableAsync(fixture.Service, historical);
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        WithdrawOrChangePolicy(fixture.Options, remove);
        complete();
        await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        Binding().Custody.ExpiresAt.ShouldBe(Start.AddDays(10));
        if (!inCustody)
        {
            await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
        }
    }

    /// <summary>The final authority check cannot withdraw policy and still release an otherwise valid binding.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task PolicyChangesAtFinalAuthority_DenyBothReads(bool historical, bool remove)
    {
        var fixture = Service(Events());
        PartyIdentityAdmissionResult grant = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)));
        int calls = 0;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(_ =>
        {
            if (++calls == (historical ? 3 : 2))
            {
                WithdrawOrChangePolicy(fixture.Options, remove);
            }

            return grant;
        });
        await AssertUnavailableAsync(fixture.Service, historical);
    }

    private static void WithdrawOrChangePolicy(IOptionsMonitor<PartyIdentityOptions> options, bool remove)
    {
        PartyIdentityOptions replacement = remove ? new PartyIdentityOptions() : PolicyOptions();
        if (!remove)
        {
            replacement.Retention = TimeSpan.FromDays(11);
        }

        options.CurrentValue.Returns(replacement);
    }

    private static async Task AssertUnavailableAsync(PartyIdentityQueryService service, bool historical, bool queryParsed = true)
    {
        if (historical)
        {
            HumanActorBindingResult result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken).ConfigureAwait(false);
            result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
            result.Evidence.ShouldBeNull();
            result.BindingSourcePosition.ShouldBe(0);
            result.SourcePosition.ShouldBe(0);
            result.ObservationId.ShouldBeNull();
            result.TenantId.ShouldBe(queryParsed ? "tenant-a" : string.Empty);
            result.PartyId.ShouldBe(queryParsed ? "party-1" : string.Empty);
            result.ActionAt.ShouldBe(queryParsed ? Start : default);
        }
        else
        {
            PartyIdentityResult result = await service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken).ConfigureAwait(false);
            result.Outcome.ShouldBe(PartyIdentityOutcome.Unavailable);
            result.Evidence.ShouldBeNull();
        }
    }

    /// <summary>Accepted 365-day intervals retain their exact boundary and source positions through serialized restore.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Accepted365DayPolicy_RebindAndRestoredHistoryPreserveOriginalBoundary(bool restored)
    {
        const string successorActor = "01HX0000000000000000000002";
        DateTimeOffset boundary = Start.AddDays(180);
        HumanActorBindingEvidence first = Binding() with
        {
            ValidUntil = Start.AddDays(365),
            Custody = Binding().Custody with { PolicyId = "party-actor-retention-v1", ExpiresAt = Start.AddDays(365) },
        };
        HumanActorBindingEvidence second = first with
        {
            ActorId = successorActor, BindingVersion = 2, ValidFrom = boundary, ValidUntil = boundary.AddDays(365),
            Custody = first.Custody with { ExpiresAt = boundary.AddDays(365), LifecycleRevision = 2, EvidenceId = "successor-custody" },
        };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(first, "first", "first-digest"), Start, 0),
            new HumanActorBindingRebound(new(second, "second", "second-digest"), boundary, 1));
        DateTimeOffset now = Start.AddDays(200);
        var policy = new PartyIdentityOptions { PolicyId = "party-actor-retention-v1", Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" };
        fixture.Options.CurrentValue.Returns(policy);
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(now);
        RetainedIdentityHistoryReadResult captured = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        RetainedIdentityHistoryStream source = captured.Stream! with { ObservedAt = now, ValidUntil = now.AddMinutes(1) };
        if (restored)
        {
            source = JsonSerializer.Deserialize<RetainedIdentityHistoryStream>(JsonSerializer.SerializeToUtf8Bytes(source, PartiesJsonOptions.Default), PartiesJsonOptions.Default)!;
        }
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(source, null));
        string requestedActor = Actor;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(_ => new PartyIdentityAdmissionResult(
            new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null, requestedActor, 1, true,
                Start, Start.AddDays(600), 1), null));
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);
        HumanActorBindingResult before = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary.AddTicks(-1), Actor, 1)), TestContext.Current.CancellationToken);
        before.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        before.BindingSourcePosition.ShouldBe(2);
        before.Evidence!.ActorId.ShouldBe(Actor);
        before.Evidence.ValidUntil.ShouldBe(boundary);
        before.Evidence.Custody.ExpiresAt.ShouldBe(Start.AddDays(365));
        requestedActor = successorActor;
        HumanActorBindingResult at = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary, successorActor, 2)), TestContext.Current.CancellationToken);
        at.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        at.BindingSourcePosition.ShouldBe(3);
        at.Evidence.ShouldBe(second);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
    }

    /// <summary>Restored readable bytes and optimistic custody cannot restart the accepted immutable expiry clock.</summary>
    [Theory]
    [InlineData(-1, HumanActorBindingOutcome.Resolved)]
    [InlineData(0, HumanActorBindingOutcome.Expired)]
    [InlineData(1, HumanActorBindingOutcome.Expired)]
    public async Task Accepted365DayPolicy_RestoredBytesRespectExclusiveExpiry(int ticks, HumanActorBindingOutcome expected)
    {
        HumanActorBindingEvidence binding = Binding() with
        {
            ValidUntil = Start.AddDays(365),
            Custody = Binding().Custody with { PolicyId = "party-actor-retention-v1", ExpiresAt = Start.AddDays(365) },
        };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(binding, "logical", "digest"), Start, 0));
        fixture.Options.CurrentValue.Returns(new PartyIdentityOptions { PolicyId = "party-actor-retention-v1", Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" });
        DateTimeOffset now = binding.Custody.ExpiresAt.AddTicks(ticks);
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(now);
        RetainedIdentityHistoryReadResult captured = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        RetainedIdentityHistoryStream restored = JsonSerializer.Deserialize<RetainedIdentityHistoryStream>(
            JsonSerializer.SerializeToUtf8Bytes(captured.Stream! with { ObservedAt = now, ValidUntil = now.AddMinutes(1) }, PartiesJsonOptions.Default), PartiesJsonOptions.Default)!;
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(new RetainedIdentityHistoryReadResult(restored, null));
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null, Actor, 1, true, Start, Start.AddDays(600), 1), null));
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);

        HumanActorBindingResult result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(expected);
        if (expected == HumanActorBindingOutcome.Expired)
        {
            result.Evidence.ShouldBeNull();
            result.BindingSourcePosition.ShouldBe(0);
            await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
        }
        restored.Events[0].Payload.ShouldBe(captured.Stream!.Events[0].Payload);
    }

    /// <summary>A profile exclusion cannot supply missing version evidence for a successor after predecessor destruction.</summary>
    [Fact]
    public async Task ExpiredPredecessorOmitted_SuccessorReadRemainsUnavailable()
    {
        const string successorActor = "01HX0000000000000000000002";
        DateTimeOffset boundary = Start.AddDays(180);
        HumanActorBindingEvidence successor = Binding() with
        {
            ActorId = successorActor, BindingVersion = 2, ValidFrom = boundary, ValidUntil = boundary.AddDays(365),
            Custody = Binding().Custody with { PolicyId = "party-actor-retention-v1", ExpiresAt = boundary.AddDays(365), LifecycleRevision = 2 },
        };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(Binding(), "first", "digest"), Start, 0),
            new HumanActorBindingRebound(new(successor, "second", "digest-2"), boundary, 1));
        fixture.Options.CurrentValue.Returns(new PartyIdentityOptions { PolicyId = "party-actor-retention-v1", Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" });
        DateTimeOffset now = Start.AddDays(366);
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(now);
        RetainedIdentityHistoryReadResult captured = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        RetainedIdentityHistoryStream missing = captured.Stream! with { ObservedAt = now, ValidUntil = now.AddMinutes(1), Events = [captured.Stream!.Events[1]], ExcludedSequences = [1, 2] };
        RetainedIdentityHistoryValidator.IsComplete(new(missing.Identity, missing.Purpose), missing, now).ShouldBeTrue();
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(new RetainedIdentityHistoryReadResult(missing, null));
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null, successorActor, 1, true, Start, Start.AddDays(600), 1), null));
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);

        HumanActorBindingResult result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary, successorActor, 2)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        result.BindingSourcePosition.ShouldBe(0);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Actor-free exact-source terminal proof permits only the retained successor; malformed proof never supplies continuity.</summary>
    [Theory]
    [InlineData("valid", HumanActorBindingOutcome.Resolved)]
    [InlineData("foreign", HumanActorBindingOutcome.Unavailable)]
    [InlineData("wrong-policy", HumanActorBindingOutcome.Unavailable)]
    [InlineData("expired", HumanActorBindingOutcome.Unavailable)]
    [InlineData("unknown-contract", HumanActorBindingOutcome.Unavailable)]
    [InlineData("wrong-transition", HumanActorBindingOutcome.Unavailable)]
    [InlineData("overlap", HumanActorBindingOutcome.Unavailable)]
    public async Task ExpiredPredecessorCertifiedWithoutActor_ResolvesOnlyRetainedSuccessor(string vector, HumanActorBindingOutcome expected)
    {
        const string successorActor = "01HX0000000000000000000002";
        DateTimeOffset boundary = Start.AddDays(180);
        HumanActorBindingEvidence successor = Binding() with
        {
            ActorId = successorActor, BindingVersion = 2, ValidFrom = boundary, ValidUntil = boundary.AddDays(365),
            Custody = Binding().Custody with { PolicyId = "party-actor-retention-v1", ExpiresAt = boundary.AddDays(365), LifecycleRevision = 2 },
        };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(Binding(), "first", "digest"), Start, 0),
            new HumanActorBindingRebound(new(successor, "second", "digest-2"), boundary, 1));
        fixture.Options.CurrentValue.Returns(new PartyIdentityOptions { PolicyId = "party-actor-retention-v1", Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" });
        DateTimeOffset now = Start.AddDays(366);
        TimeProvider clock = Substitute.For<TimeProvider>(); ConfigureSystemTimer(clock); clock.GetUtcNow().Returns(now);
        RetainedIdentityHistoryReadResult captured = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        var certificate = new ExpiredIdentityHistoryCertificate(captured.Stream!.Identity, captured.Stream.Purpose, "party-actor-retention-v1", 2,
            typeof(HumanActorBindingEstablished).FullName!, new string('A', 64), "opaque-terminal-receipt", 4, "current-lifecycle", now, now.AddMinutes(1));
        certificate = vector switch
        {
            "foreign" => certificate with { Identity = new("tenant-foreign", "party", "party-1") },
            "wrong-policy" => certificate with { PolicyId = "unaccepted-policy" },
            "expired" => certificate with { ValidUntil = now },
            "unknown-contract" => certificate with { ContractVersion = 2 },
            "wrong-transition" => certificate with { EventTypeName = typeof(HumanActorBindingRebound).FullName! },
            "overlap" => certificate with { SourceSequence = 3 },
            _ => certificate,
        };
        var retained = captured.Stream with { ObservedAt = now, ValidUntil = now.AddMinutes(1), Events = [captured.Stream.Events[1]],
            ExcludedSequences = [1], ExpiredEvents = [certificate] };
        // Round-trip the actual additive certificate transport; it contains neither predecessor payload nor actor.
        byte[] transport = JsonSerializer.SerializeToUtf8Bytes(retained, PartiesJsonOptions.Default);
        System.Text.Encoding.UTF8.GetString(transport).ShouldNotContain(Actor);
        var restored = JsonSerializer.Deserialize<RetainedIdentityHistoryStream>(transport, PartiesJsonOptions.Default)!;
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(restored, null));
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"),
            "reader", null, successorActor, 1, true, Start, Start.AddDays(600), 1), null));
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);
        var result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", boundary, successorActor, 2)),
            TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(expected);
        if (expected == HumanActorBindingOutcome.Resolved)
        { result.Evidence!.ActorId.ShouldBe(successorActor); result.BindingSourcePosition.ShouldBe(3); result.Evidence.ValidUntil.ShouldBe(boundary.AddDays(365)); }
        else { result.Evidence.ShouldBeNull(); result.BindingSourcePosition.ShouldBe(0); }
        // No retained actor-free prefix can recreate the expired predecessor's relationship.
        (await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)),
            TestContext.Current.CancellationToken)).Evidence.ShouldBeNull();
    }

    /// <summary>A retained revocation closes only the certified expired version; it never recreates actor bytes and a retained rebound stays queryable.</summary>
    [Theory]
    [InlineData("valid")][InlineData("unproved")][InlineData("gap")][InlineData("wrong-rebound")][InlineData("expired-after-readable")]
    public async Task CertifiedExpiredEstablishmentRetainedRevocationAndReboundResolveThroughQuery(string vector)
    {
        const string successorActor = "01HX0000000000000000000002";
        var revokedAt = Start.AddDays(180); var reboundAt = Start.AddDays(200);
        var now = Start.AddDays(vector == "expired-after-readable" ? 500 : 366);
        var policy = "party-actor-retention-v1";
        var original = Binding() with { ValidUntil = Start.AddDays(365), Custody = Binding().Custody with { PolicyId = policy, ExpiresAt = Start.AddDays(365) } };
        var revokedCustody = original.Custody with { ExpiresAt = revokedAt.AddDays(365), LifecycleRevision = 2 };
        var successor = original with { ActorId = successorActor, BindingVersion = vector == "wrong-rebound" ? 4 : 3, ValidFrom = reboundAt,
            ValidUntil = reboundAt.AddDays(365), Custody = original.Custody with { ExpiresAt = reboundAt.AddDays(365), LifecycleRevision = 3 } };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(original, "first", "first-digest"), Start, 0),
            new HumanActorBindingRevoked("revoked", "revoked-digest", vector == "gap" ? 2 : 1, revokedAt, revokedCustody),
            new HumanActorBindingRebound(new(successor, "third", "third-digest"), reboundAt, 2));
        fixture.Options.CurrentValue.Returns(new PartyIdentityOptions { PolicyId = policy, Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" });
        var captured = (await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken)).Stream!;
        var certificate = new ExpiredIdentityHistoryCertificate(captured.Identity, captured.Purpose, policy, 2,
            typeof(HumanActorBindingEstablished).FullName!, new string('A', 64), "terminal-destruction", 4, "current-lifecycle", now, now.AddMinutes(1));
        var lateProof = certificate with { SourceSequence = 4, EventTypeName = typeof(HumanActorBindingRebound).FullName!,
            SealedPayloadDigest = new string('B', 64), DestructionReceiptId = "late-original-destruction" };
        var retained = captured with { ObservedAt = now, ValidUntil = now.AddMinutes(1),
            Events = vector == "expired-after-readable" ? [captured.Events.Single(item => item.SequenceNumber == 3)] : captured.Events.Skip(1).ToArray(),
            ExcludedSequences = vector == "unproved" ? [1, 2] : [1],
            ExpiredEvents = vector == "unproved" ? [] : vector == "expired-after-readable" ? [certificate, lateProof] : [certificate] };
        var bytes = JsonSerializer.SerializeToUtf8Bytes(retained, PartiesJsonOptions.Default); System.Text.Encoding.UTF8.GetString(bytes).ShouldNotContain(Actor);
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(
            new RetainedIdentityHistoryReadResult(JsonSerializer.Deserialize<RetainedIdentityHistoryStream>(bytes, PartiesJsonOptions.Default)!, null));
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null,
            successorActor, 1, true, Start, Start.AddDays(600), 1), null));
        TimeProvider clock = Substitute.For<TimeProvider>(); ConfigureSystemTimer(clock); clock.GetUtcNow().Returns(now);
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);
        var result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", reboundAt, successorActor, 3)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(vector == "valid" ? HumanActorBindingOutcome.Resolved : HumanActorBindingOutcome.Unavailable);
        if (vector == "valid") { result.Evidence!.ActorId.ShouldBe(successorActor); result.Evidence.BindingVersion.ShouldBe(3); result.BindingSourcePosition.ShouldBe(4); }
        else { result.Evidence.ShouldBeNull(); }
        (await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken)).Evidence.ShouldBeNull();
    }

    /// <summary>Two actor-free independently certified expired transitions preserve exact version continuity and return only the retained version-three source original.</summary>
    [Theory]
    [InlineData("rebound")][InlineData("revocation")]
    public async Task MultipleExpiredTransitionsResolveOnlyRetainedVersionThreeThroughSerializedQuery(string expiredTransition)
    {
        ArgumentNullException.ThrowIfNull(expiredTransition);
        const string intermediateActor = "01HX0000000000000000000002"; const string retainedActor = "01HX0000000000000000000003";
        const string policy = "party-actor-retention-v1";
        var secondAt = Start.AddDays(10); var successorAt = Start.AddDays(200); var now = Start.AddDays(376);
        var original = Binding() with { ValidUntil = Start.AddDays(365), Custody = Binding().Custody with { PolicyId = policy, ExpiresAt = Start.AddDays(365) } };
        var secondCustody = original.Custody with { ExpiresAt = secondAt.AddDays(365), LifecycleRevision = 2 };
        IEventPayload second = expiredTransition == "rebound" ? new HumanActorBindingRebound(new(original with { ActorId = intermediateActor, BindingVersion = 2,
            ValidFrom = secondAt, ValidUntil = secondAt.AddDays(365), Custody = secondCustody }, "second", "second-digest"), secondAt, 1)
            : new HumanActorBindingRevoked("revoked", "revoked-digest", 1, secondAt, secondCustody);
        var successor = original with { ActorId = retainedActor, BindingVersion = 3, ValidFrom = successorAt, ValidUntil = successorAt.AddDays(365),
            Custody = original.Custody with { ExpiresAt = successorAt.AddDays(365), LifecycleRevision = 3 } };
        var fixture = Service(Events()[0], new HumanActorBindingEstablished(new(original, "first", "first-digest"), Start, 0), second,
            new HumanActorBindingRebound(new(successor, "third", "third-digest"), successorAt, 2));
        fixture.Options.CurrentValue.Returns(new PartyIdentityOptions { PolicyId = policy, Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" });
        var captured = (await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken)).Stream!;
        var firstProof = new ExpiredIdentityHistoryCertificate(captured.Identity, captured.Purpose, policy, 2, typeof(HumanActorBindingEstablished).FullName!,
            new string('A', 64), "original-first-destruction", 4, "current-lifecycle", now, now.AddMinutes(1));
        var secondProof = firstProof with { SourceSequence = 3, EventTypeName = second.GetType().FullName!, SealedPayloadDigest = new string('B', 64), DestructionReceiptId = "original-second-destruction" };
        var retained = captured with { ObservedAt = now, ValidUntil = now.AddMinutes(1), Events = [captured.Events.Single(item => item.SequenceNumber == 4)],
            ExcludedSequences = [1], ExpiredEvents = [firstProof, secondProof] };
        byte[] transport = JsonSerializer.SerializeToUtf8Bytes(retained, PartiesJsonOptions.Default);
        System.Text.Encoding.UTF8.GetString(transport).ShouldNotContain(Actor); System.Text.Encoding.UTF8.GetString(transport).ShouldNotContain(intermediateActor);
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(
            new RetainedIdentityHistoryReadResult(JsonSerializer.Deserialize<RetainedIdentityHistoryStream>(transport, PartiesJsonOptions.Default)!, null));
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"), "reader", null,
            retainedActor, 1, true, Start, Start.AddDays(600), 1), null));
        TimeProvider clock = Substitute.For<TimeProvider>(); ConfigureSystemTimer(clock); clock.GetUtcNow().Returns(now);
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);
        var result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", successorAt, retainedActor, 3)), TestContext.Current.CancellationToken);
        result.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved); result.Evidence!.ShouldBe(successor); result.Evidence!.ActorId.ShouldBe(retainedActor);
        result.Evidence.BindingVersion.ShouldBe(3); result.Evidence.ValidFrom.ShouldBe(successorAt); result.Evidence.ValidUntil.ShouldBe(successorAt.AddDays(365));
        result.BindingSourcePosition.ShouldBe(4); result.SourcePosition.ShouldBe(4);
        (await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start.AddDays(5), Actor, 1)), TestContext.Current.CancellationToken)).Evidence.ShouldBeNull();
        (await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start.AddDays(20), intermediateActor, 2)), TestContext.Current.CancellationToken)).Evidence.ShouldBeNull();
    }

    /// <summary>Readable retained evidence uses only the supported event and protection representations.</summary>
    /// <param name="corruption">The unsupported wire representation.</param>
    /// <param name="suffix">Whether valid queried evidence precedes the malformed transition.</param>
    [Theory]
    [InlineData("event-zero", false)]
    [InlineData("event-negative", false)]
    [InlineData("event-future", false)]
    [InlineData("protection-zero", false)]
    [InlineData("protection-future", false)]
    [InlineData("format", false)]
    [InlineData("event-zero", true)]
    [InlineData("event-negative", true)]
    [InlineData("event-future", true)]
    [InlineData("protection-zero", true)]
    [InlineData("protection-future", true)]
    [InlineData("format", true)]
    public async Task UnsupportedRetainedRepresentation_DeniesBeforeCustody(string corruption, bool suffix)
    {
        DateTimeOffset boundary = Start.AddHours(1);
        HumanActorBindingEvidence successor = Binding() with
        {
            BindingVersion = 2, ValidFrom = boundary, ValidUntil = boundary.AddDays(10),
            Custody = Binding().Custody with { ExpiresAt = boundary.AddDays(10) },
        };
        var fixture = Service([.. Events(), new HumanActorBindingRebound(new(successor, "second", "digest-2"), boundary, 1)]);
        RetainedIdentityHistoryStream original = (await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken)).Stream!;
        StreamReadEvent malformed = original.Events[suffix ? 1 : 0] with
        {
            MetadataVersion = corruption switch { "event-zero" => 0, "event-negative" => -1, "event-future" => 2, _ => 1 },
            SerializationFormat = corruption == "format" ? "json-v2" : "json",
            ProtectionMetadata = EventStorePayloadProtectionMetadata.Unprotected() with
            {
                MetadataVersion = corruption switch { "protection-zero" => 0, "protection-future" => 2, _ => 1 },
            },
        };
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(original with
            {
                Events = suffix ? [original.Events[0], malformed] : [malformed, original.Events[1]],
            }, null));

        HumanActorBindingResult result = await fixture.Service.ResolveAtAsync(
            Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        result.BindingSourcePosition.ShouldBe(0);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Long histories preserve early, middle and final evidence and reject late invalid ordering.</summary>
    /// <param name="corruption">An optional malformed transition near the end of the history.</param>
    [Theory]
    [InlineData("valid")]
    [InlineData("backdated")]
    [InlineData("empty-interval")]
    public async Task LongRetainedHistory_PreservesIntervalsAndOriginalSourcePositions(string corruption)
    {
        const int count = 4096;
        var events = new List<IEventPayload> { Events()[0] };
        for (int index = 0; index < count; index++)
        {
            DateTimeOffset at = Start.AddSeconds(index);
            if (index == count - 1 && corruption == "backdated")
            {
                at = Start.AddSeconds(index - 2);
            }
            HumanActorBindingEvidence evidence = Binding() with
            {
                BindingVersion = index + 1,
                ValidFrom = at,
                ValidUntil = index == count - 2 && corruption == "empty-interval" ? at : at.AddDays(10),
                Custody = Binding().Custody with { ExpiresAt = at.AddDays(10) },
            };
            var binding = new HumanActorBinding(evidence, "logical-" + index, "digest-" + index);
            events.Add(index == 0 ? new HumanActorBindingEstablished(binding, at, 0)
                : new HumanActorBindingRebound(binding, at, index));
        }
        var fixture = Service([.. events]);
        foreach (int index in new[] { 0, count / 2, count - 1 })
        {
            DateTimeOffset actionAt = Start.AddSeconds(index);
            HumanActorBindingResult result = await fixture.Service.ResolveAtAsync(
                Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", actionAt, Actor, index + 1)), TestContext.Current.CancellationToken);
            if (corruption != "valid")
            {
                result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
                result.Evidence.ShouldBeNull();
                result.BindingSourcePosition.ShouldBe(0);
                continue;
            }

            result.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
            result.Evidence!.BindingVersion.ShouldBe(index + 1);
            result.Evidence.ValidFrom.ShouldBe(actionAt);
            result.Evidence.ValidUntil.ShouldBe(index < count - 1 ? actionAt.AddSeconds(1) : actionAt.AddDays(10));
            result.SourcePosition.ShouldBe(count + 1);
            result.BindingSourcePosition.ShouldBe(index + 2);
        }
        if (corruption != "valid")
        {
            await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
        }
    }

    /// <summary>Actor-free certified prefixes obey the same live/revoked transition lifecycle as readable history.</summary>
    /// <param name="middle">The three prefix transitions before the readable successor.</param>
    /// <param name="valid">Whether the prefix contains a supported lifecycle.</param>
    [Theory]
    [InlineData("revoke-revoke", false)]
    [InlineData("revoke-rebind", true)]
    [InlineData("rebind-revoke", true)]
    public async Task CertifiedExpiredPrefix_RejectsConsecutiveRevocations(string middle, bool valid)
    {
        ArgumentNullException.ThrowIfNull(middle);
        const string policy = "party-actor-retention-v1";
        DateTimeOffset now = Start.AddDays(376);
        DateTimeOffset successorAt = Start.AddDays(200);
        HumanActorBindingEvidence successor = Binding() with
        {
            BindingVersion = 4, ValidFrom = successorAt, ValidUntil = successorAt.AddDays(365),
            Custody = Binding().Custody with { PolicyId = policy, ExpiresAt = successorAt.AddDays(365), LifecycleRevision = 4 },
        };
        var fixture = Service(Events()[0], new HumanActorBindingRebound(new(successor, "fourth", "digest-4"), successorAt, 3));
        fixture.Options.CurrentValue.Returns(new PartyIdentityOptions { PolicyId = policy, Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" });
        RetainedIdentityHistoryStream original = (await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken)).Stream!;
        string revoked = typeof(HumanActorBindingRevoked).FullName!;
        string rebound = typeof(HumanActorBindingRebound).FullName!;
        var first = new ExpiredIdentityHistoryCertificate(original.Identity, original.Purpose, policy, 2,
            typeof(HumanActorBindingEstablished).FullName!, new string('A', 64), "destruction-first", 5, "authority", now, now.AddMinutes(1));
        var second = first with { SourceSequence = 3, EventTypeName = middle.StartsWith("revoke", StringComparison.Ordinal) ? revoked : rebound,
            SealedPayloadDigest = new string('B', 64), DestructionReceiptId = "destruction-second" };
        var third = first with { SourceSequence = 4, EventTypeName = middle.EndsWith("revoke", StringComparison.Ordinal) ? revoked : rebound,
            SealedPayloadDigest = new string('C', 64), DestructionReceiptId = "destruction-third" };
        RetainedIdentityHistoryStream source = original with
        {
            Head = 5, ObservedAt = now, ValidUntil = now.AddMinutes(1),
            Events = [original.Events[0] with { SequenceNumber = 5 }], ExpiredEvents = [first, second, third],
        };
        byte[] transport = JsonSerializer.SerializeToUtf8Bytes(source, PartiesJsonOptions.Default);
        source = JsonSerializer.Deserialize<RetainedIdentityHistoryStream>(transport, PartiesJsonOptions.Default)!;
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(source, null));
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(new PartyIdentityAdmissionResult(new(new("tenant-a", "party", "party-1", "Read", "c", "c", "d"),
            "reader", null, Actor, 1, true, Start, Start.AddDays(600), 1), null));
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(now);
        var service = new PartyIdentityQueryService(fixture.Authority, clock, custody: fixture.Custody, historyReader: fixture.HistoryReader, identityOptions: fixture.Options);

        HumanActorBindingResult result = await service.ResolveAtAsync(
            Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", successorAt, Actor, 4)), TestContext.Current.CancellationToken);

        result.Outcome.ShouldBe(valid ? HumanActorBindingOutcome.Resolved : HumanActorBindingOutcome.Unavailable);
        if (valid)
        {
            result.Evidence.ShouldBe(successor);
            result.BindingSourcePosition.ShouldBe(5);
        }
        else
        {
            result.Evidence.ShouldBeNull();
            result.BindingSourcePosition.ShouldBe(0);
            await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
        }
    }

    /// <summary>One deadline cancels noncooperative source/custody and cannot admit a late success or fault.</summary>
    [Theory]
    [InlineData(false, false, false)]
    [InlineData(true, false, false)]
    [InlineData(false, true, false)]
    [InlineData(true, true, false)]
    [InlineData(false, false, true)]
    [InlineData(true, false, true)]
    [InlineData(false, true, true)]
    [InlineData(true, true, true)]
    public async Task WholeQueryDeadline_NonCooperativeDependencyDeniesLateEvidence(bool historical, bool inCustody, bool lateFault)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var providerReturned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        CancellationToken providerToken = default;
        Action complete;
        async Task<T> FinishProviderAsync<T>(Task<T> pending, CancellationToken token)
        {
            providerToken = token;
            entered.TrySetResult();
            try { return await pending.ConfigureAwait(false); }
            finally { providerReturned.TrySetResult(); }
        }

        if (inCustody)
        {
            var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
                .Returns(call => FinishProviderAsync(pending.Task, call.Arg<CancellationToken>()));
            complete = () => { if (lateFault) { pending.SetException(new HttpRequestException("late synthetic fault")); } else { pending.SetResult(true); } };
        }
        else if (historical)
        {
            RetainedIdentityHistoryReadResult valid = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
            var pending = new TaskCompletionSource<RetainedIdentityHistoryReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
                .Returns(call => FinishProviderAsync(pending.Task, call.Arg<CancellationToken>()));
            complete = () => { if (lateFault) { pending.SetException(new HttpRequestException("late synthetic fault")); } else { pending.SetResult(valid); } };
        }
        else
        {
            AuthoritativeStreamReadResult valid = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
            var pending = new TaskCompletionSource<AuthoritativeStreamReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(call => FinishProviderAsync(pending.Task, call.Arg<CancellationToken>()));
            complete = () => { if (lateFault) { pending.SetException(new HttpRequestException("late synthetic fault")); } else { pending.SetResult(valid); } };
        }

        Task result = AssertUnavailableAsync(service, historical);
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        result.IsCompleted.ShouldBeFalse();
        advance(TimeSpan.FromSeconds(30), true);
        await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        providerToken.IsCancellationRequested.ShouldBeTrue();
        int authorityCalls = fixture.Authority.ReceivedCalls().Count();
        providerReturned.Task.IsCompleted.ShouldBeFalse();
        complete();
        await providerReturned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        fixture.Authority.ReceivedCalls().Count().ShouldBe(authorityCalls);
        if (!inCustody)
        {
            await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
        }
    }

    /// <summary>The budget covers providers blocked synchronously before returning their task.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task WholeQueryDeadline_SynchronousProviderInvocationIsBounded(bool historical, bool inCustody)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var returned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        CancellationToken providerToken = default;
        void Block(CancellationToken token)
        {
            providerToken = token;
            entered.TrySetResult();
            release.Wait(TestContext.Current.CancellationToken);
            returned.TrySetResult();
        }

        if (inCustody)
        {
            fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
                .Returns(call => { Block(call.Arg<CancellationToken>()); return Task.FromResult(true); });
        }
        else if (historical)
        {
            RetainedIdentityHistoryReadResult valid = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
            fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
                .Returns(call => { Block(call.Arg<CancellationToken>()); return Task.FromResult(valid); });
        }
        else
        {
            AuthoritativeStreamReadResult valid = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(call => { Block(call.Arg<CancellationToken>()); return Task.FromResult(valid); });
        }

        Task result = Task.Run(() => AssertUnavailableAsync(service, historical), TestContext.Current.CancellationToken);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            advance(TimeSpan.FromSeconds(30), true);
            await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            providerToken.IsCancellationRequested.ShouldBeTrue();
        }
        finally
        {
            release.Set();
            await returned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        }
    }

    /// <summary>Source and custody consume one budget and receive the same cancellable operation token.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task WholeQueryDeadline_SourceAndCustodyShareCumulativeBudget(bool historical)
    {
        var fixture = Service(Events());
        ITimer? timer = null;
        var (clock, advance) = DeadlineClock(onTimer: value => timer = value);
        PartyIdentityOptions configured = PolicyOptions();
        configured.QueryTimeout = TimeSpan.FromSeconds(10);
        fixture.Options.CurrentValue.Returns(configured);
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        var sourceEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var custodyEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var custodyPending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        CancellationToken sourceToken = default;
        CancellationToken custodyToken = default;
        Action releaseSource;
        if (historical)
        {
            RetainedIdentityHistoryReadResult valid = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
            var source = new TaskCompletionSource<RetainedIdentityHistoryReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
                .Returns(call => { sourceToken = call.Arg<CancellationToken>(); sourceEntered.SetResult(); return source.Task; });
            releaseSource = () => source.SetResult(valid);
        }
        else
        {
            AuthoritativeStreamReadResult valid = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
            var source = new TaskCompletionSource<AuthoritativeStreamReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(call => { sourceToken = call.Arg<CancellationToken>(); sourceEntered.SetResult(); return source.Task; });
            releaseSource = () => source.SetResult(valid);
        }

        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(call => { custodyToken = call.Arg<CancellationToken>(); custodyEntered.SetResult(); return custodyPending.Task; });
        Task result = AssertUnavailableAsync(service, historical);
        await sourceEntered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        advance(TimeSpan.FromSeconds(7), true);
        result.IsCompleted.ShouldBeFalse();
        releaseSource();
        await custodyEntered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        sourceToken.ShouldBe(custodyToken);
        advance(TimeSpan.FromSeconds(3), true);
        await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        custodyToken.IsCancellationRequested.ShouldBeTrue();
        custodyPending.SetResult(true);
        clock.Received(1).CreateTimer(Arg.Any<TimerCallback>(), Arg.Any<object?>(), TimeSpan.FromSeconds(30), Timeout.InfiniteTimeSpan);
        timer!.Received(1).Change(TimeSpan.FromSeconds(10), Timeout.InfiniteTimeSpan);
    }

    /// <summary>Monotonic elapsed checks deny late evidence even if a timer callback is delayed.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task WholeQueryDeadline_ElapsedBeforeTimerCallbackDeniesEvidence(bool historical)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { advance(TimeSpan.FromSeconds(30), false); return true; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        await AssertUnavailableAsync(service, historical);
        fixture.Authority.Received(historical ? 2 : 1).Admit(Arg.Any<QueryEnvelope>());
    }

    /// <summary>Invalid operational bounds fail closed before authority, source or custody invocation.</summary>
    [Theory]
    [InlineData(false, 0L)]
    [InlineData(true, 0L)]
    [InlineData(false, -1L)]
    [InlineData(true, -1L)]
    [InlineData(false, 300_000_001L)]
    [InlineData(true, 300_000_001L)]
    [InlineData(false, long.MaxValue)]
    [InlineData(true, long.MaxValue)]
    public async Task InvalidQueryTimeout_DeniesBeforeAnyProvider(bool historical, long ticks)
    {
        var fixture = Service(Events());
        PartyIdentityOptions configured = PolicyOptions();
        configured.QueryTimeout = TimeSpan.FromTicks(ticks);
        fixture.Options.CurrentValue.Returns(configured);
        await AssertUnavailableAsync(fixture.Service, historical, queryParsed: false);
        fixture.Authority.DidNotReceiveWithAnyArgs().Admit(default(QueryEnvelope)!);
        await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
        await fixture.HistoryReader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default!, default);
        await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
    }

    /// <summary>Caller cancellation wins a concurrent deadline/fault and preserves the original token.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task CallerCancellationRacesDeadlineAndFault_PreservesOriginalToken(bool historical, bool expire)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        using var caller = new CancellationTokenSource();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { entered.SetResult(); return pending.Task; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = InvokeIdentityAsync(service, historical, caller.Token);
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        await caller.CancelAsync();
        if (expire) { advance(TimeSpan.FromSeconds(30), true); }
        pending.SetException(new HttpRequestException("synthetic racing fault"));
        OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() => result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken));
        exception.CancellationToken.ShouldBe(caller.Token);
    }

    /// <summary>Provider cancellation callbacks cannot hold deadline or caller result completion hostage.</summary>
    [Theory]
    [InlineData(false, false, "timer")]
    [InlineData(true, false, "timer")]
    [InlineData(false, true, "timer")]
    [InlineData(true, true, "timer")]
    [InlineData(false, false, "elapsed")]
    [InlineData(true, false, "elapsed")]
    [InlineData(false, true, "elapsed")]
    [InlineData(true, true, "elapsed")]
    [InlineData(false, false, "caller")]
    [InlineData(true, false, "caller")]
    [InlineData(false, true, "caller")]
    [InlineData(true, true, "caller")]
    public async Task BlockingProviderCancellationCallback_DoesNotDelayQueryCompletion(bool historical, bool inCustody, string trigger)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        using var caller = new CancellationTokenSource();
        using var release = new ManualResetEventSlim();
        var providerEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var cancellationEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var cancellationReturned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        CancellationToken providerToken = default;
        Action complete;
        if (inCustody)
        {
            var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
                .Returns(call => { providerToken = call.Arg<CancellationToken>(); providerEntered.TrySetResult(); return pending.Task; });
            complete = () => pending.TrySetResult(true);
        }
        else if (historical)
        {
            RetainedIdentityHistoryReadResult valid = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
            var pending = new TaskCompletionSource<RetainedIdentityHistoryReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
                .Returns(call => { providerToken = call.Arg<CancellationToken>(); providerEntered.TrySetResult(); return pending.Task; });
            complete = () => pending.TrySetResult(valid);
        }
        else
        {
            AuthoritativeStreamReadResult valid = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
            var pending = new TaskCompletionSource<AuthoritativeStreamReadResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
                .Returns(call => { providerToken = call.Arg<CancellationToken>(); providerEntered.TrySetResult(); return pending.Task; });
            complete = () => pending.TrySetResult(valid);
        }

        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = trigger == "caller" ? InvokeIdentityAsync(service, historical, caller.Token) : AssertUnavailableAsync(service, historical);
        await providerEntered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        // Register after the query suspended, making this provider callback the last callback
        // registered on its token. It remains blocked until the test's finally releases it.
        using CancellationTokenRegistration registration = providerToken.Register(() =>
        {
            cancellationEntered.TrySetResult();
            release.Wait(TestContext.Current.CancellationToken);
            cancellationReturned.TrySetResult();
        });
        Task cancellation = Task.CompletedTask;
        try
        {
            if (trigger == "elapsed")
            {
                advance(TimeSpan.FromSeconds(30), false);
                complete();
            }
            else
            {
                cancellation = Task.Run(() =>
                {
                    if (trigger == "caller") { caller.Cancel(); }
                    else { advance(TimeSpan.FromSeconds(30), true); }
                }, TestContext.Current.CancellationToken);
            }

            await cancellationEntered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            if (trigger == "caller")
            {
                OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() => result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken));
                exception.CancellationToken.ShouldBe(caller.Token);
            }
            else
            {
                await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            }

            cancellationReturned.Task.IsCompleted.ShouldBeFalse();
            providerToken.IsCancellationRequested.ShouldBeTrue();
            if (!inCustody)
            {
                await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
            }
        }
        finally
        {
            release.Set();
            complete();
            await cancellationReturned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            await cancellation.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            try { await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken); }
            catch (OperationCanceledException) when (caller.IsCancellationRequested) { }
        }
    }

    /// <summary>Initial options access consumes the same budget instead of resetting the source timer.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task WholeQueryDeadline_SetupTimeConsumesOperationBudget(bool historical, bool exhausted)
    {
        var fixture = Service(Events());
        ITimer? timer = null;
        var (clock, advance) = DeadlineClock(onTimer: value => timer = value);
        PartyIdentityOptions configured = PolicyOptions();
        configured.QueryTimeout = TimeSpan.FromSeconds(10);
        int optionsReads = 0;
        fixture.Options.CurrentValue.Returns(_ =>
        {
            if (++optionsReads == 1) { advance(TimeSpan.FromSeconds(exhausted ? 10 : 7), false); }
            return configured;
        });
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { entered.SetResult(); return pending.Task; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = AssertUnavailableAsync(service, historical, queryParsed: !exhausted);
        if (!exhausted)
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            advance(TimeSpan.FromSeconds(2), true);
            result.IsCompleted.ShouldBeFalse();
            advance(TimeSpan.FromSeconds(1), true);
        }

        await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        if (exhausted)
        {
            fixture.Authority.DidNotReceiveWithAnyArgs().Admit(default(QueryEnvelope)!);
            await fixture.Reader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default);
            await fixture.HistoryReader.DidNotReceiveWithAnyArgs().ReadAsync(default!, default!, default);
        }
        else
        {
            clock.Received(1).CreateTimer(Arg.Any<TimerCallback>(), Arg.Any<object?>(), TimeSpan.FromSeconds(30), Timeout.InfiniteTimeSpan);
            timer!.Received(1).Change(TimeSpan.FromSeconds(3), Timeout.InfiniteTimeSpan);
        }

        pending.TrySetResult(true);
    }

    /// <summary>Caller cancellation before verdict release wins an already-started deadline or dependency fault.</summary>
    [Theory]
    [InlineData(false, "deadline")]
    [InlineData(true, "deadline")]
    [InlineData(false, "fault")]
    [InlineData(true, "fault")]
    public async Task CallerCancellationAfterDeadlineOrFaultBeforeVerdict_PreservesOriginalToken(bool historical, string trigger)
    {
        var fixture = Service(Events());
        using var caller = new CancellationTokenSource();
        using var releaseVerdict = new ManualResetEventSlim();
        var disposing = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var (clock, advance) = DeadlineClock(() =>
        {
            disposing.TrySetResult();
            releaseVerdict.Wait(TestContext.Current.CancellationToken);
        });
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { entered.SetResult(); return pending.Task; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = InvokeIdentityAsync(service, historical, caller.Token);
        Task failure = Task.CompletedTask;
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            failure = Task.Run(() =>
            {
                if (trigger == "deadline") { advance(TimeSpan.FromSeconds(30), true); }
                else { pending.SetException(new HttpRequestException("synthetic fault before caller cancellation")); }
            }, TestContext.Current.CancellationToken);
            // Timer disposal holds either deadline cancellation or failed-await cleanup
            // after the failure starts and before the query can release a verdict.
            await disposing.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            result.IsCompleted.ShouldBeFalse();
            await caller.CancelAsync();
        }
        finally
        {
            releaseVerdict.Set();
            pending.TrySetResult(true);
        }

        OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() => result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken));
        exception.CancellationToken.ShouldBe(caller.Token);
        await failure.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
    }

    /// <summary>A shortened budget accepts valid evidence immediately before its exclusive deadline.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShortQueryDeadline_ImmediatelyBeforeExpiryStillResolves(bool historical)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        PartyIdentityOptions configured = PolicyOptions();
        configured.QueryTimeout = TimeSpan.FromSeconds(5);
        fixture.Options.CurrentValue.Returns(configured);
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(_ => { advance(TimeSpan.FromSeconds(5) - TimeSpan.FromTicks(1), false); return true; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        if (historical)
        {
            HumanActorBindingResult result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
            result.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
            result.Evidence!.ActorId.ShouldBe(Actor);
            result.SourcePosition.ShouldBe(2);
            result.BindingSourcePosition.ShouldBe(2);
            result.ObservationId.ShouldBe("history-observation");
        }
        else
        {
            PartyIdentityResult result = await service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
            result.Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
            result.Evidence!.HumanBinding!.ActorId.ShouldBe(Actor);
            result.Evidence.SourcePosition.ShouldBe(2);
        }
    }

    /// <summary>A delayed timer cannot release evidence after final authority consumes the last budget instant.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task WholeQueryDeadline_FinalAuthorityExpiryDeniesTerminalEvidence(bool historical)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        PartyIdentityAdmissionResult admitted = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)));
        int authorityCalls = 0;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(_ =>
        {
            if (++authorityCalls == (historical ? 3 : 2)) { advance(TimeSpan.FromSeconds(30), false); }
            return admitted;
        });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        await AssertUnavailableAsync(service, historical);
        authorityCalls.ShouldBe(historical ? 3 : 2);
        TestContext.Current.CancellationToken.IsCancellationRequested.ShouldBeFalse();
    }

    /// <summary>A late failing provider callback remains independent of the completed safe verdict.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ProviderCancellationCallbackFaultAfterDeadline_DoesNotAffectVerdict(bool historical)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var cancelEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var cancelReturned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        CancellationToken providerToken = default;
        fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>())
            .Returns(call => { providerToken = call.Arg<CancellationToken>(); entered.SetResult(); return pending.Task; });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = AssertUnavailableAsync(service, historical);
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        using CancellationTokenRegistration registration = providerToken.Register(() =>
        {
            cancelEntered.TrySetResult();
            release.Wait(TestContext.Current.CancellationToken);
            cancelReturned.TrySetResult();
            throw new InvalidOperationException("synthetic late provider cancellation fault");
        });
        try
        {
            advance(TimeSpan.FromSeconds(30), true);
            await cancelEntered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            cancelReturned.Task.IsCompleted.ShouldBeFalse();
            providerToken.IsCancellationRequested.ShouldBeTrue();
        }
        finally
        {
            release.Set();
            pending.TrySetResult(true);
            await cancelReturned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        }

        result.IsCompletedSuccessfully.ShouldBeTrue();
    }

    /// <summary>Every synchronous authority call is bounded, including both historical rechecks.</summary>
    [Theory]
    [InlineData(false, 1, false)]
    [InlineData(false, 2, false)]
    [InlineData(true, 1, false)]
    [InlineData(true, 2, false)]
    [InlineData(true, 3, false)]
    [InlineData(false, 1, true)]
    [InlineData(false, 2, true)]
    [InlineData(true, 1, true)]
    [InlineData(true, 2, true)]
    [InlineData(true, 3, true)]
    public async Task WholeQueryDeadline_SynchronousAdmissionIsBounded(bool historical, int stalledCall, bool cancelCaller)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        using var caller = new CancellationTokenSource();
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var returned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        PartyIdentityAdmissionResult admitted = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)));
        int calls = 0;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(_ =>
        {
            if (Interlocked.Increment(ref calls) == stalledCall)
            {
                entered.TrySetResult();
                release.Wait(TestContext.Current.CancellationToken);
                returned.TrySetResult();
                throw new InvalidOperationException("synthetic abandoned admission fault");
            }
            return admitted;
        });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = cancelCaller ? InvokeIdentityAsync(service, historical, caller.Token) : AssertUnavailableAsync(service, historical);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            if (cancelCaller) { await caller.CancelAsync(); }
            advance(TimeSpan.FromSeconds(30), true);
            if (cancelCaller)
            {
                OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() => result);
                exception.CancellationToken.ShouldBe(caller.Token);
            }
            else
            {
                await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            }
            returned.Task.IsCompleted.ShouldBeFalse();
        }
        finally
        {
            release.Set();
            await returned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        }
        calls.ShouldBe(stalledCall);
    }

    /// <summary>Slow replay/validation cannot hold either query beyond the caller's operational deadline.</summary>
    [Theory]
    [InlineData(false, 1)]
    [InlineData(true, 1)]
    [InlineData(true, 2)]
    [InlineData(true, 3)]
    [InlineData(true, 4)]
    public async Task WholeQueryDeadline_SynchronousReplayIsBounded(bool historical, int gatedEnumeration)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var returned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        IReadOnlyList<StreamReadEvent> original;
        AuthoritativeStreamReadResult current = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
        RetainedIdentityHistoryReadResult history = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        original = historical ? history.Stream!.Events : current.Stream!.Events;
        IReadOnlyList<StreamReadEvent> gated = Substitute.For<IReadOnlyList<StreamReadEvent>>();
        gated.Count.Returns(original.Count);
        gated[Arg.Any<int>()].Returns(call => original[call.Arg<int>()]);
        int enumerations = 0;
        gated.GetEnumerator().Returns(_ => Replay().GetEnumerator());
        IEnumerable<StreamReadEvent> Replay()
        {
            // Historical passes are initial validation, fold validation, fold replay,
            // and terminal validation. Gate each independently of the earlier passes.
            bool blocked = Interlocked.Increment(ref enumerations) == gatedEnumeration;
            if (blocked)
            {
                entered.TrySetResult();
                release.Wait(TestContext.Current.CancellationToken);
            }
            try
            {
                foreach (StreamReadEvent item in original) { yield return item; }
            }
            finally { if (blocked) { returned.TrySetResult(); } }
        }
        fixture.Reader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<CancellationToken>())
            .Returns(current with { Stream = current.Stream! with { Events = gated } });
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(history with { Stream = history.Stream! with { Events = gated } });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = AssertUnavailableAsync(service, historical);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            advance(TimeSpan.FromSeconds(30), true);
            await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            returned.Task.IsCompleted.ShouldBeFalse("The unavailable verdict must arrive before the replay gate opens.");
            if (gatedEnumeration < 4)
            {
                await fixture.Custody.DidNotReceiveWithAnyArgs().CanReadAsync(default!, default!, default);
            }
        }
        finally
        {
            release.Set();
            await returned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        }
    }

    /// <summary>Both folds cooperatively stop between transitions rather than replaying abandoned history.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task SourceFolds_CancelBetweenTransitions(bool historical)
    {
        var fixture = Service(Events());
        using var caller = new CancellationTokenSource();
        AuthoritativeStreamReadResult current = await fixture.Reader.ReadAsync(new("tenant-a", "party", "party-1"), TestContext.Current.CancellationToken);
        RetainedIdentityHistoryReadResult history = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"), RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        IReadOnlyList<StreamReadEvent> original = historical ? history.Stream!.Events : current.Stream!.Events;
        IReadOnlyList<StreamReadEvent> interrupted = Substitute.For<IReadOnlyList<StreamReadEvent>>();
        interrupted.Count.Returns(original.Count);
        interrupted[Arg.Any<int>()].Returns(call => original[call.Arg<int>()]);
        int enumerations = 0;
        interrupted.GetEnumerator().Returns(_ => Replay().GetEnumerator());
        IEnumerable<StreamReadEvent> Replay()
        {
            // Retained validation enumerates the source before its replay loop.
            bool replay = !historical || ++enumerations == 2;
            foreach (StreamReadEvent item in original)
            {
                if (replay) { caller.Cancel(); }
                yield return item;
            }
            if (replay) { throw new InvalidOperationException("Replay continued after cancellation."); }
        }
        OperationCanceledException exception = Should.Throw<OperationCanceledException>(() =>
        {
            if (historical) { RetainedHumanActorHistoryFold.Fold(history.Stream! with { Events = interrupted }, "synthetic", caller.Token); }
            else { PartyIdentitySourceFold.Fold(current.Stream! with { Events = interrupted }, caller.Token); }
        });
        exception.CancellationToken.ShouldBe(caller.Token);
    }

    /// <summary>Abandoned work and callbacks retain a shared lease; late faults restore capacity only after both finish.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task SharedWorkCapacity_RejectsSaturationAndRecoversAfterWorkAndCallbacks(bool historical, bool callbackFinishesFirst)
    {
        var limiter = new PartyIdentityQueryWorkLimiter(1);
        var (clock, advance) = DeadlineClock();
        var pending = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var cancellationEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        using var releaseCallback = new ManualResetEventSlim();
        var deadline = new PartyIdentityQueryDeadline(TimeSpan.FromSeconds(30), clock,
            TestContext.Current.CancellationToken, clock.GetTimestamp(), limiter);
        Task<bool> read = deadline.ReadAsync(token =>
        {
            token.Register(() =>
            {
                cancellationEntered.TrySetResult();
                releaseCallback.Wait(TestContext.Current.CancellationToken);
                throw new InvalidOperationException("synthetic abandoned callback fault");
            });
            entered.TrySetResult();
            return pending.Task;
        });
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        advance(TimeSpan.FromSeconds(30), true);
        await Should.ThrowAsync<OperationCanceledException>(() => read);
        deadline.Dispose();
        await cancellationEntered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        var fixture = Service(Events());
        var service = new PartyIdentityQueryService(fixture.Authority, TimeProvider.System, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options)
        { WorkLimiter = limiter };
        try
        {
            for (int i = 0; i < 20; i++) { await AssertUnavailableAsync(service, historical, queryParsed: false); }
            fixture.Authority.DidNotReceiveWithAnyArgs().Admit(default(QueryEnvelope)!);
            if (callbackFinishesFirst) { releaseCallback.Set(); }
            else { pending.SetException(new InvalidOperationException("synthetic abandoned provider fault")); }
            await AssertUnavailableAsync(service, historical, queryParsed: false);
            fixture.Authority.DidNotReceiveWithAnyArgs().Admit(default(QueryEnvelope)!);
        }
        finally
        {
            releaseCallback.Set();
            pending.TrySetException(new InvalidOperationException("synthetic abandoned provider fault"));
            await deadline.WorkCompleted.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        }
        if (historical)
        {
            (await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        }
        else
        {
            (await service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken)).Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
        }
        fixture.Service.WorkLimiter.ShouldBeSameAs(PartyIdentityQueryWorkLimiter.Shared);
    }

    /// <summary>Admission does not reset the remaining budget or start a worker after that budget expires.</summary>
    [Fact]
    public async Task SharedWorkCapacity_AcquisitionConsumesTheQueryBudget()
    {
        TimeProvider clock = Substitute.For<TimeProvider>();
        clock.TimestampFrequency.Returns(TimeSpan.TicksPerSecond);
        clock.GetTimestamp().Returns(0L, 0L, TimeSpan.FromSeconds(30).Ticks);
        clock.CreateTimer(Arg.Any<TimerCallback>(), Arg.Any<object?>(), Arg.Any<TimeSpan>(), Arg.Any<TimeSpan>())
            .Returns(Substitute.For<ITimer>());
        var limiter = new PartyIdentityQueryWorkLimiter(1);
        var deadline = new PartyIdentityQueryDeadline(TimeSpan.FromSeconds(30), clock,
            TestContext.Current.CancellationToken, 0L, limiter);
        bool invoked = false;
        await Should.ThrowAsync<OperationCanceledException>(() => deadline.ReadAsync(_ =>
        {
            invoked = true;
            return Task.FromResult(true);
        }));
        deadline.Dispose();
        await deadline.WorkCompleted.WaitAsync(TestContext.Current.CancellationToken);
        invoked.ShouldBeFalse();
        limiter.TryAcquire().ShouldBeTrue();
        limiter.Release();
    }

    /// <summary>Final replay validation cannot leave a stale authority or source-expiry observation at release.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task FinalHistoryValidation_RechecksAuthorityAndSourceExpiryAfterReplay(bool revokeAuthority)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        RetainedIdentityHistoryReadResult original = await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken);
        PartyIdentityAdmissionResult admitted = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)));
        bool revoked = false;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(_ => revoked ? new PartyIdentityAdmissionResult(null, null) : admitted);
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        int enumerations = 0;
        IReadOnlyList<StreamReadEvent> events = original.Stream!.Events;
        IReadOnlyList<StreamReadEvent> gated = Substitute.For<IReadOnlyList<StreamReadEvent>>();
        gated.Count.Returns(events.Count);
        gated[Arg.Any<int>()].Returns(call => events[call.Arg<int>()]);
        gated.GetEnumerator().Returns(_ => Replay().GetEnumerator());
        IEnumerable<StreamReadEvent> Replay()
        {
            // Initial validation, fold validation and fold replay precede terminal validation.
            if (Interlocked.Increment(ref enumerations) == 4)
            {
                entered.TrySetResult();
                release.Wait(TestContext.Current.CancellationToken);
            }
            foreach (StreamReadEvent item in events) { yield return item; }
        }
        DateTimeOffset validUntil = clock.GetUtcNow().AddSeconds(revokeAuthority ? 20 : 5);
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(original with { Stream = original.Stream! with { Events = gated, ValidUntil = validUntil } });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);
        Task result = AssertUnavailableAsync(service, historical: true);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            revoked = revokeAuthority;
            advance(TimeSpan.FromSeconds(5), false);
        }
        finally { release.Set(); }
        await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
    }

    /// <summary>Backward UTC movement during terminal admission cannot release future source or destruction observations.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task FinalHistoryAdmission_BackwardUtcRejectsValidatedObservations(bool destructionObservation)
    {
        const string policy = "party-actor-retention-v1";
        DateTimeOffset successorAt = Start.AddDays(200);
        HumanActorBindingEvidence successor = Binding() with
        {
            BindingVersion = 2, ValidFrom = successorAt, ValidUntil = successorAt.AddDays(365),
            Custody = Binding().Custody with { PolicyId = policy, ExpiresAt = successorAt.AddDays(365) },
        };
        var fixture = destructionObservation
            ? Service(Events()[0], new HumanActorBindingRebound(new(successor, "successor", "digest-2"), successorAt, 1))
            : Service(Events());
        RetainedIdentityHistoryStream source = (await fixture.HistoryReader.ReadAsync(new("tenant-a", "party", "party-1"),
            RetainedIdentityHistoryReadRequest.AttributionPurpose, TestContext.Current.CancellationToken)).Stream!;
        DateTimeOffset observedAt = destructionObservation ? Start.AddDays(376) : source.ObservedAt.AddSeconds(1);
        DateTimeOffset now = observedAt;
        source = source with { ObservedAt = observedAt, ValidUntil = observedAt.AddMinutes(1) };
        if (destructionObservation)
        {
            fixture.Options.CurrentValue.Returns(new PartyIdentityOptions
            { PolicyId = policy, Retention = TimeSpan.FromDays(365), ExpiryTrigger = "binding-effective-at" });
            var expired = new ExpiredIdentityHistoryCertificate(source.Identity, source.Purpose, policy, 2,
                typeof(HumanActorBindingEstablished).FullName!, new string('A', 64), "destruction", 2, "authority",
                observedAt.AddSeconds(-10), observedAt.AddMinutes(1));
            var certificates = new List<ExpiredIdentityHistoryCertificate> { expired };
            source = source with { Head = 3, ObservedAt = observedAt.AddSeconds(-10),
                Events = [source.Events[0] with { SequenceNumber = 3 }], ExpiredEvents = certificates };
            fixture.Custody.CanReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(),
                Arg.Any<IdentityHistoryCustodyEvidence>(), Arg.Any<CancellationToken>()).Returns(_ =>
                {
                    // Refresh destruction observation only after the fold's earlier
                    // stream-time validation. Terminal validation accepts this newer bound.
                    certificates[0] = expired with { ObservedAt = observedAt };
                    return true;
                });
        }
        RetainedIdentityHistoryValidator.IsComplete(new(source.Identity, source.Purpose), source, observedAt).ShouldBeTrue();
        RetainedHumanActorHistoryFold.Fold(source, destructionObservation ? policy : "synthetic", TestContext.Current.CancellationToken).ShouldHaveSingleItem();
        fixture.HistoryReader.ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(new RetainedIdentityHistoryReadResult(source, null));
        PartyIdentityAdmissionResult original = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)));
        PartyIdentityAdmissionResult admitted = original with { Evidence = original.Evidence! with
            { IssuedAt = Start, ExpiresAt = observedAt.AddDays(1) } };
        int calls = 0;
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(_ =>
        {
            if (Interlocked.Increment(ref calls) == 3) { now = observedAt.AddTicks(-1); }
            return admitted;
        });
        TimeProvider clock = Substitute.For<TimeProvider>();
        ConfigureSystemTimer(clock);
        clock.GetUtcNow().Returns(_ => now);
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader, fixture.Custody, fixture.HistoryReader, fixture.Options);

        HumanActorBindingResult result = await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1",
            destructionObservation ? successorAt : Start, Actor, destructionObservation ? 2 : 1)), TestContext.Current.CancellationToken);

        calls.ShouldBe(3, "The regression must reach final admission after successful source validation and custody.");
        result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
        result.Evidence.ShouldBeNull();
        result.SourcePosition.ShouldBe(0);
        result.BindingSourcePosition.ShouldBe(0);
    }

    /// <summary>Options setup and every policy revalidation share bounded capacity, even after late faults.</summary>
    [Theory]
    [InlineData(false, 1, false)]
    [InlineData(false, 1, true)]
    [InlineData(false, 2, false)]
    [InlineData(false, 2, true)]
    [InlineData(false, 3, false)]
    [InlineData(false, 3, true)]
    [InlineData(false, 4, false)]
    [InlineData(false, 4, true)]
    [InlineData(true, 1, false)]
    [InlineData(true, 1, true)]
    [InlineData(true, 2, false)]
    [InlineData(true, 2, true)]
    [InlineData(true, 3, false)]
    [InlineData(true, 3, true)]
    [InlineData(true, 4, false)]
    [InlineData(true, 4, true)]
    [InlineData(true, 5, false)]
    [InlineData(true, 5, true)]
    [InlineData(true, 6, false)]
    [InlineData(true, 6, true)]
    public async Task OptionsAndPolicyProviders_AreBoundedAndRetainCapacity(bool historical, int stalledCall, bool cancelCaller)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        PartyIdentityOptions configured = PolicyOptions();
        var limiter = new PartyIdentityQueryWorkLimiter(1);
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var returned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        int calls = 0;
        fixture.Options.CurrentValue.Returns(_ =>
        {
            if (Interlocked.Increment(ref calls) == stalledCall)
            {
                entered.TrySetResult();
                release.Wait(TestContext.Current.CancellationToken);
                returned.TrySetResult();
                throw new InvalidOperationException("synthetic late options fault");
            }
            return configured;
        });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader,
            fixture.Custody, fixture.HistoryReader, fixture.Options) { WorkLimiter = limiter };
        Task result = cancelCaller ? InvokeIdentityAsync(service, historical, caller.Token) : AssertUnavailableAsync(service, historical, queryParsed: stalledCall != 1);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            if (cancelCaller) { caller.Cancel(); }
            else { advance(TimeSpan.FromSeconds(30), true); }
            if (cancelCaller)
            {
                OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() => result);
                exception.CancellationToken.ShouldBe(caller.Token);
            }
            else { await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken); }
            returned.Task.IsCompleted.ShouldBeFalse();
            for (int i = 0; i < 10; i++) { await AssertUnavailableAsync(service, historical, queryParsed: false); }
            Volatile.Read(ref calls).ShouldBe(stalledCall, "Saturated queries must not invoke another options provider.");
        }
        finally
        {
            release.Set();
            await returned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        }

        async Task AwaitCapacityAsync()
        {
            while (!limiter.TryAcquire()) { await Task.Yield(); }
            limiter.Release();
        }
        await AwaitCapacityAsync().WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        if (historical)
        {
            (await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)),
                TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        }
        else
        {
            (await service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)),
                TestContext.Current.CancellationToken)).Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
        }
    }

    /// <summary>Terminal policy awaits cannot leave expiry observations stamped before the await.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task TerminalPolicyRevalidation_RechecksExpiryAfterTheAwait(bool historical)
    {
        var fixture = Service(Events());
        var (clock, _) = DeadlineClock();
        PartyIdentityOptions configured = PolicyOptions();
        PartyIdentityAdmissionResult admitted = fixture.Authority.Admit(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)));
        fixture.Authority.Admit(Arg.Any<QueryEnvelope>()).Returns(admitted);
        int reads = 0;
        fixture.Options.CurrentValue.Returns(_ =>
        {
            if (Interlocked.Increment(ref reads) == (historical ? 6 : 4))
            {
                clock.GetUtcNow().Returns(admitted.Evidence!.ExpiresAt);
            }
            return configured;
        });
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader,
            fixture.Custody, fixture.HistoryReader, fixture.Options);
        await AssertUnavailableAsync(service, historical);
        reads.ShouldBe(historical ? 6 : 4);
    }

    /// <summary>Both actual service callers bound stalled selection and retain their shared lease through cleanup.</summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task ServiceIntervalSelection_IsBoundedAndRecovers(bool historical, bool cancelCaller)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        var limiter = new PartyIdentityQueryWorkLimiter(1);
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var returned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        int selections = 0;
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader,
            fixture.Custody, fixture.HistoryReader, fixture.Options)
        {
            WorkLimiter = limiter,
            BeforeBindingSelection = () =>
            {
                if (Interlocked.Increment(ref selections) == 1)
                {
                    entered.TrySetResult();
                    release.Wait(TestContext.Current.CancellationToken);
                    returned.TrySetResult();
                }
            },
        };
        Task result = Task.Run(() => cancelCaller ? InvokeIdentityAsync(service, historical, caller.Token)
            : AssertUnavailableAsync(service, historical), TestContext.Current.CancellationToken);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            if (cancelCaller) { caller.Cancel(); }
            else { advance(TimeSpan.FromSeconds(30), true); }
            if (cancelCaller)
            {
                OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() =>
                    result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken));
                exception.CancellationToken.ShouldBe(caller.Token);
            }
            else { await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken); }
            returned.Task.IsCompleted.ShouldBeFalse();
            limiter.TryAcquire().ShouldBeFalse();
            await AssertUnavailableAsync(service, historical, queryParsed: false);
            Volatile.Read(ref selections).ShouldBe(1);
        }
        finally { release.Set(); }
        await returned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        async Task AwaitCapacityAsync()
        {
            while (!limiter.TryAcquire()) { await Task.Yield(); }
            limiter.Release();
        }
        await AwaitCapacityAsync().WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        if (historical)
        {
            (await service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)),
                TestContext.Current.CancellationToken)).Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
        }
        else
        {
            (await service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)),
                TestContext.Current.CancellationToken)).Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
        }
        Volatile.Read(ref selections).ShouldBe(2);
    }

    /// <summary>The actual interval scanner is bounded even when its input refuses cooperative cancellation.</summary>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task IntervalSelection_AbandonedScanRetainsLeaseAndRejectsLateMatches(bool cancelCaller)
    {
        var (clock, advance) = DeadlineClock();
        var limiter = new PartyIdentityQueryWorkLimiter(1);
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        IEnumerable<HumanActorBindingEvidence> Intervals()
        {
            entered.TrySetResult();
            release.Wait(TestContext.Current.CancellationToken);
            yield return Binding();
        }
        var deadline = new PartyIdentityQueryDeadline(TimeSpan.FromSeconds(30), clock, caller.Token, clock.GetTimestamp(), limiter);
        Task<HumanActorBindingEvidence[]> selection = deadline.RunAsync(token =>
            PartyIdentityBindingSelection.SelectAt(Intervals(), item => item, Start, token));
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            if (cancelCaller) { caller.Cancel(); }
            else { advance(TimeSpan.FromSeconds(30), true); }
            await Should.ThrowAsync<OperationCanceledException>(() => selection);
            deadline.Dispose();
            deadline.WorkCompleted.IsCompleted.ShouldBeFalse();
            limiter.TryAcquire().ShouldBeFalse();
        }
        finally
        {
            release.Set();
            deadline.Dispose();
            await deadline.WorkCompleted.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        }
        limiter.TryAcquire().ShouldBeTrue();
        limiter.Release();
    }

    /// <summary>Selection preserves ambiguity, gaps, exclusive ends and original source positions.</summary>
    [Fact]
    public void IntervalSelection_PreservesOriginalItemsAndExclusiveEnd()
    {
        HumanActorBindingEvidence first = Binding() with { ValidUntil = Start.AddMinutes(1) };
        HumanActorBindingEvidence second = Binding() with { ValidFrom = Start.AddMinutes(1), BindingVersion = 2 };
        var original = new[] { (Evidence: first, SourcePosition: 41L), (Evidence: second, SourcePosition: 73L) };
        PartyIdentityBindingSelection.SelectAt(original, item => item.Evidence, Start.AddTicks(-1), TestContext.Current.CancellationToken).ShouldBeEmpty();
        PartyIdentityBindingSelection.SelectAt(original, item => item.Evidence, Start.AddMinutes(1), TestContext.Current.CancellationToken)
            .Single().SourcePosition.ShouldBe(73L);
        PartyIdentityBindingSelection.SelectAt(new[] { original[0], original[0] }, item => item.Evidence, Start, TestContext.Current.CancellationToken).Length.ShouldBe(2);
    }

    /// <summary>Identity parsing shares the configured budget and retains capacity until abandoned work finishes.</summary>
    [Theory]
    [InlineData(false, false, false)]
    [InlineData(false, false, true)]
    [InlineData(false, true, false)]
    [InlineData(false, true, true)]
    [InlineData(true, false, false)]
    [InlineData(true, false, true)]
    [InlineData(true, true, false)]
    [InlineData(true, true, true)]
    public async Task IdentityEnvelopeParsing_IsBoundedAndRecovers(bool historical, bool cancelCaller, bool lateFault)
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        PartyIdentityOptions configured = PolicyOptions();
        configured.QueryTimeout = TimeSpan.FromSeconds(10);
        fixture.Options.CurrentValue.Returns(configured);
        fixture.Authority.ClearReceivedCalls();
        fixture.HistoryReader.ClearReceivedCalls();
        var limiter = new PartyIdentityQueryWorkLimiter(1);
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        using var release = new ManualResetEventSlim();
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var returned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        int parses = 0;
        Action beforeParsing = () =>
        {
            if (Interlocked.Increment(ref parses) == 1)
            {
                entered.TrySetResult();
                release.Wait(TestContext.Current.CancellationToken);
                returned.TrySetResult();
                if (lateFault) { throw new InvalidOperationException("synthetic late parse fault"); }
            }
        };
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader,
            fixture.Custody, fixture.HistoryReader, fixture.Options)
        {
            WorkLimiter = limiter,
            BeforeHistoricalParsing = historical ? beforeParsing : null,
            BeforeCurrentParsing = historical ? null : beforeParsing,
        };
        Task result = cancelCaller ? InvokeIdentityAsync(service, historical, caller.Token)
            : AssertUnavailableAsync(service, historical, queryParsed: false);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
            if (cancelCaller) { caller.Cancel(); }
            advance(TimeSpan.FromSeconds(10), true);
            if (cancelCaller)
            {
                OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() =>
                    result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken));
                exception.CancellationToken.ShouldBe(caller.Token);
            }
            else { await result.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken); }
            returned.Task.IsCompleted.ShouldBeFalse();
            limiter.TryAcquire().ShouldBeFalse();
            for (int i = 0; i < 10; i++) { await AssertUnavailableAsync(service, historical, queryParsed: false); }
            await AssertUnavailableAsync(service, !historical, queryParsed: !historical);
            Volatile.Read(ref parses).ShouldBe(1);
            fixture.Authority.DidNotReceive().Admit(Arg.Any<QueryEnvelope>());
            await fixture.Reader.DidNotReceive().ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(),
                Arg.Any<CancellationToken>());
            await fixture.HistoryReader.DidNotReceive().ReadAsync(Arg.Any<Hexalith.EventStore.Contracts.Identity.AggregateIdentity>(),
                Arg.Any<string>(), Arg.Any<CancellationToken>());
        }
        finally { release.Set(); }
        await returned.Task.WaitAsync(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);
        using var recovery = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        recovery.CancelAfter(TimeSpan.FromSeconds(3));
        while (true)
        {
            TestContext.Current.CancellationToken.ThrowIfCancellationRequested();
            recovery.Token.ThrowIfCancellationRequested();
            if (limiter.TryAcquire())
            {
                limiter.Release();
                break;
            }
            await Task.Yield();
        }
        if (historical)
        {
            HumanActorBindingResult recovered = await service.ResolveAtAsync(
                Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), TestContext.Current.CancellationToken);
            recovered.Outcome.ShouldBe(HumanActorBindingOutcome.Resolved);
            recovered.Evidence.ShouldNotBeNull();
            recovered.BindingSourcePosition.ShouldBe(2);
        }
        else
        {
            PartyIdentityResult recovered = await service.ResolveAsync(
                Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), TestContext.Current.CancellationToken);
            recovered.Outcome.ShouldBe(PartyIdentityOutcome.Resolved);
            recovered.Evidence.ShouldNotBeNull();
        }
        Volatile.Read(ref parses).ShouldBe(2);
    }

    /// <summary>Elapsed setup and parsing consume one total budget even before the timer callback runs.</summary>
    [Fact]
    public async Task HistoricalEnvelopeParsing_ConsumesTheRemainingConfiguredBudget()
    {
        var fixture = Service(Events());
        var (clock, advance) = DeadlineClock();
        PartyIdentityOptions configured = PolicyOptions();
        configured.QueryTimeout = TimeSpan.FromSeconds(10);
        fixture.Options.CurrentValue.Returns(_ =>
        {
            advance(TimeSpan.FromSeconds(7), false);
            return configured;
        });
        fixture.Authority.ClearReceivedCalls();
        var service = new PartyIdentityQueryService(fixture.Authority, clock, fixture.Reader,
            fixture.Custody, fixture.HistoryReader, fixture.Options)
        {
            BeforeHistoricalParsing = () => advance(TimeSpan.FromSeconds(3), false),
        };

        await AssertUnavailableAsync(service, historical: true, queryParsed: false);

        fixture.Authority.DidNotReceive().Admit(Arg.Any<QueryEnvelope>());
    }

    /// <summary>Malformed historical payloads fail closed before admission, with caller cancellation taking precedence.</summary>
    [Theory]
    [InlineData("null", false)]
    [InlineData("{", false)]
    [InlineData("[]", false)]
    [InlineData("{}", false)]
    [InlineData("{", true)]
    public async Task HistoricalEnvelopeParsing_RejectsMalformedPayloadBeforeAdmission(string payload, bool cancelCaller)
    {
        var fixture = Service(Events());
        fixture.Authority.ClearReceivedCalls();
        QueryEnvelope envelope = Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1))
            with { Payload = System.Text.Encoding.UTF8.GetBytes(payload) };
        using var caller = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        if (cancelCaller) { caller.Cancel(); }

        if (cancelCaller)
        {
            OperationCanceledException exception = await Should.ThrowAsync<OperationCanceledException>(() =>
                fixture.Service.ResolveAtAsync(envelope, caller.Token));
            exception.CancellationToken.ShouldBe(caller.Token);
        }
        else
        {
            HumanActorBindingResult result = await fixture.Service.ResolveAtAsync(envelope, caller.Token);
            result.Outcome.ShouldBe(HumanActorBindingOutcome.Unavailable);
            result.Evidence.ShouldBeNull();
            result.SourcePosition.ShouldBe(0);
            result.BindingSourcePosition.ShouldBe(0);
        }
        fixture.Authority.DidNotReceive().Admit(Arg.Any<QueryEnvelope>());
    }

    private static (TimeProvider Clock, Action<TimeSpan, bool> Advance) DeadlineClock(Action? onDispose = null, Action<ITimer>? onTimer = null)
    {
        TimeProvider clock = Substitute.For<TimeProvider>();
        DateTimeOffset now = DateTimeOffset.UtcNow.AddSeconds(1);
        long timestamp = 0;
        TimerCallback? callback = null;
        object? state = null;
        long dueAt = long.MaxValue;
        clock.TimestampFrequency.Returns(TimeSpan.TicksPerSecond);
        clock.GetTimestamp().Returns(_ => Interlocked.Read(ref timestamp));
        clock.GetUtcNow().Returns(_ => now + TimeSpan.FromTicks(Interlocked.Read(ref timestamp)));
        clock.CreateTimer(Arg.Any<TimerCallback>(), Arg.Any<object?>(), Arg.Any<TimeSpan>(), Arg.Any<TimeSpan>()).Returns(call =>
        {
            callback = call.Arg<TimerCallback>();
            state = call.ArgAt<object?>(1);
            dueAt = Interlocked.Read(ref timestamp) + call.ArgAt<TimeSpan>(2).Ticks;
            ITimer timer = Substitute.For<ITimer>();
            timer.Change(Arg.Any<TimeSpan>(), Arg.Any<TimeSpan>()).Returns(change =>
            {
                dueAt = Interlocked.Read(ref timestamp) + change.ArgAt<TimeSpan>(0).Ticks;
                return true;
            });
            if (onDispose is not null) { timer.When(item => item.Dispose()).Do(_ => onDispose()); }
            onTimer?.Invoke(timer);
            return timer;
        });
        return (clock, (elapsed, fire) =>
        {
            long current = Interlocked.Add(ref timestamp, elapsed.Ticks);
            if (fire && current >= dueAt) { callback!(state); }
        });
    }

    private static void ConfigureSystemTimer(TimeProvider clock)
    {
        clock.TimestampFrequency.Returns(TimeProvider.System.TimestampFrequency);
        clock.GetTimestamp().Returns(_ => TimeProvider.System.GetTimestamp());
        clock.CreateTimer(Arg.Any<TimerCallback>(), Arg.Any<object?>(), Arg.Any<TimeSpan>(), Arg.Any<TimeSpan>()).Returns(call =>
            TimeProvider.System.CreateTimer(call.Arg<TimerCallback>(), call.ArgAt<object?>(1), call.ArgAt<TimeSpan>(2), call.ArgAt<TimeSpan>(3)));
    }

    private static PartyIdentityOptions PolicyOptions() => new()
    {
        PolicyId = "synthetic",
        Retention = TimeSpan.FromDays(10),
        ExpiryTrigger = "binding-effective-at",
    };

    private static Task InvokeIdentityAsync(PartyIdentityQueryService service, bool historical, CancellationToken token)
        => historical
            ? service.ResolveAtAsync(Envelope(new ResolveHumanActorBindingAt("tenant-a", "party-1", Start, Actor, 1)), token)
            : service.ResolveAsync(Envelope(new ResolvePartyIdentity("tenant-a", "party-1", Actor)), token);
}
