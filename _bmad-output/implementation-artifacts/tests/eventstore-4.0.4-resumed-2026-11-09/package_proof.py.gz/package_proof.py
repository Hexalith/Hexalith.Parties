import base64
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile
from verify import ARTIFACTS, HERE

cache = Path('/home/administrator/.nuget/packages')
assets = json.loads((ARTIFACTS/'obj/Hexalith.Parties/project.assets.json').read_text())
selected = {name: info for name, info in assets['libraries'].items() if name.startswith('Hexalith.')}
proof = []
for key, info in selected.items():
    if info['type'] != 'package':
        continue
    name, version = key.split('/')
    directory = cache/name.lower()/version
    archive = directory/f'{name.lower()}.{version}.nupkg'
    data = archive.read_bytes()
    metadata = json.loads((directory/'.nupkg.metadata').read_text())
    archive_hash = base64.b64encode(hashlib.sha512(data).digest()).decode()
    assert archive_hash == (directory/f'{name.lower()}.{version}.nupkg.sha512').read_text(), key
    assert info['sha512'] == metadata['contentHash'], key
    fresh = HERE/f'public-{name.lower()}.{version}.nupkg'
    if name == 'Hexalith.EventStore.Contracts':
        fresh = HERE/'public-eventstore-contracts.nupkg'
    public_match = None
    if name.startswith(('Hexalith.EventStore.', 'Hexalith.Tenants.', 'Hexalith.Memories.')):
        assert fresh.read_bytes() == data, key
        public_match = True
    with zipfile.ZipFile(archive) as z:
        nuspec = ET.fromstring(z.read(next(n for n in z.namelist() if n.endswith('.nuspec'))))
        repository = next((node.attrib for node in nuspec.iter() if node.tag.endswith('repository')), None)
        bodies = []
        for filename in z.namelist():
            if filename.startswith('lib/net10.0/') and filename.endswith('.dll'):
                output = ARTIFACTS/'bin/Hexalith.Parties/release'/Path(filename).name
                if output.exists():
                    digest = hashlib.sha256(z.read(filename)).hexdigest()
                    assert hashlib.sha256(output.read_bytes()).hexdigest() == digest, filename
                    bodies.append(dict(file=filename, sha256=digest, matchesNativeOutput=True))
        if name.startswith('Hexalith.EventStore.'):
            assert version == '4.0.4', key
            assert repository['commit'] == '326bfef884543cdbcaf96de7f4c4ad378dbad6d7', key
        proof.append(dict(package=name, version=version, source=metadata['source'], repository=repository,
                          sha256=hashlib.sha256(data).hexdigest(), archiveSha512=archive_hash,
                          nugetContentHash=metadata['contentHash'], freshlyDownloadedPublicArchiveMatches=public_match,
                          publicUrl=f'https://api.nuget.org/v3-flatcontainer/{name.lower()}/{version}/{name.lower()}.{version}.nupkg',
                          nativeBodies=bodies))
assert 'Hexalith.Tenants.Client/5.11.2' in selected
assert 'Hexalith.Memories.Client.Rest/3.0.11' in selected
host_deps = json.loads((ARTIFACTS/'bin/Hexalith.Parties/release/Hexalith.Parties.deps.json').read_text())
assert not any(key.startswith('Hexalith.Parties.EventStoreExtensions/') for key in host_deps['libraries'])
assert all(info['type'] == 'package' or key.startswith('Hexalith.Parties') for key, info in selected.items())
props = json.loads((HERE/'evaluated-cohort.log').read_text())['Properties']
assert props['HexalithEventStoreFromSource'] == 'false'
assert props['HexalithEventStoreVersion'] == '4.0.4'
assert props['HexalithEventStoreCatalogApiSupported'] == 'true'
assert props['HexalithEventStoreCatalogHostsSupported'] == 'true'
assert 'HEXALITH_DEVELOPMENT_CATALOG_SOURCE' not in props['DefineConstants'].split(';')
(HERE/'package-proof.json').write_text(json.dumps(dict(packages=proof, adapterOutsideNativeClosure=True, actualProperties=props), indent=2)+'\n')
print(json.dumps(dict(packages=len(proof), sdkPackages=sum(p['package'].startswith('Hexalith.EventStore.') for p in proof),
                      nativeSdkBodies=sum(len(p['nativeBodies']) for p in proof if p['package'].startswith('Hexalith.EventStore.')),
                      freshPublicArchiveComparisons=sum(p['freshlyDownloadedPublicArchiveMatches'] is True for p in proof),
                      adapterOutsideNativeClosure=True)))
