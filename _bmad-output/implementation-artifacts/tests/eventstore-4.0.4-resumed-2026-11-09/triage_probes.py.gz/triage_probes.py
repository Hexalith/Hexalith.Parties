import importlib.util
import json
from pathlib import Path
import tempfile

ROOT = Path('/home/administrator/projects/hexalith/parties')
HERE = Path(__file__).parent

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

public = load('public_probes', ROOT/'scripts/test_public_package_integration.py')
private = load('private_probes', ROOT/'scripts/test_current_owner_integration.py')
results = []

def probe(label, role, change):
    fixture = (public.PublicPackageEvidenceTests('test_separate_public_roles_and_all_original28_names_pass_as_a_unit_fixture_only')
               if role == 'public' else private.CurrentOwnerEvidenceTests('test_current_same_run_evidence_passes_without_qualification_credit'))
    fixture.setUp()
    f = fixture.fixture if role == 'public' else fixture
    try:
        change(f)
        f.seal()
        try:
            fixture.check()
            results.append(dict(label=label, role=role, disposition='accepted'))
        except ValueError as error:
            results.append(dict(label=label, role=role, disposition='refused', message=str(error)))
    finally:
        fixture.doCleanups()

for role in ('public', 'private'):
    probe('boolean-and-floating-sequences', role, lambda f: f.functional.update(metadataSequence=True, eventCount=1.0))
    probe('false-selector-observation', role, lambda f: f.functional.update(selectorCompatibilityObserved=False))

def dates(f):
    f.functional['observedAtUtc']='1900-01-01T00:00:00Z'
    f.functional['publicRuntime']['measuredAtUtc']='2999-01-01T00:00:00Z'
probe('unbounded-observation-dates', 'public', dates)

def roles(f):
    for field in ('loaded', 'copied'):
        for item in f.loaded[field]: item['scope']='copied-static-image'
    f.write('loaded-assemblies-'+f.owner['runId']+'.json', f.loaded)
probe('private-assembly-role-substitution', 'private', roles)

def stale(f):
    import xml.etree.ElementTree as ET
    report=ET.fromstring(f.native)
    ET.SubElement(report,'Times', creation='1900-01-01T00:00:00Z', start='1900-01-01T00:00:00Z', finish='1900-01-01T00:00:01Z')
    f.native=ET.tostring(report)
probe('historical-native-report-times', 'public', stale)

import subprocess
platform=subprocess.check_output(['git','rev-parse','HEAD:references/Hexalith.Platform'],cwd=ROOT,text=True).strip()
builds=subprocess.check_output(['git','rev-parse','HEAD:references/Hexalith.Builds'],cwd=ROOT,text=True).strip()
try:
    public.public.validate(HERE/'absent-artifacts',repository='Hexalith/Hexalith.Parties',run='1',attempt=1,source='a'*40,platform=platform,builds=builds)
except ValueError as error:
    results.append(dict(label='current-gitlink-identity-gate', disposition='refused', platform=platform, builds=builds, message=str(error)))

controller=load('controller_probe',ROOT/'scripts/qualify-disposable-ci.py')
with tempfile.TemporaryDirectory() as temporary:
    root=Path(temporary)
    (root/'actual').mkdir()
    (root/'actual/metadata.json').write_text('{}')
    (root/'linked').symlink_to(root/'actual',target_is_directory=True)
    result=controller.read(root/'linked/metadata.json')
    results.append(dict(label='symlinked-metadata-parent', disposition='accepted', value=result,
                        limit='reader acceptance only; no hosted-path reachability established'))
(HERE/'triage-probes.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
