import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/administrator/projects/hexalith/parties')
HERE = Path(__file__).parent
ARTIFACTS = ROOT / 'artifacts/parties404-resumed-review'
PROPERTIES = [
    '-p:HexalithEventStoreVersion=4.0.4',
    '-p:HexalithTenantsVersion=5.11.2',
    '-p:HexalithMemoriesVersion=3.0.11',
    '-p:UseHexalithProjectReferences=false',
    '-p:UseNuGetDeps=true',
    '-p:EventStoreFromSource=false',
    '-p:HexalithEventStoreFromSource=false',
    '-p:HexalithTenantsFromSource=false',
    '-p:HexalithMemoriesFromSource=false',
    '-p:HexalithCommonsFromSource=false',
    '-p:HexalithCommonsHttpFromSource=false',
    '-p:HexalithMcpCliFromSource=false',
    '-p:RestoreSources=https://api.nuget.org/v3/index.json',
]
PROJECTS = [
    'src/Hexalith.Parties.Contracts/Hexalith.Parties.Contracts.csproj',
    'src/Hexalith.Parties.EventStoreExtensions/Hexalith.Parties.EventStoreExtensions.csproj',
    'src/Hexalith.Parties/Hexalith.Parties.csproj',
    'tests/Hexalith.Parties.Catalog.Tests/Hexalith.Parties.Catalog.Tests.csproj',
    'tests/Hexalith.Parties.Ci.Tests/Hexalith.Parties.Ci.Tests.csproj',
]

def run(label, command):
    started = time.monotonic()
    with (HERE / f'{label}.log').open('w') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    record = dict(label=label, command=command, exitCode=result.returncode,
                  seconds=round(time.monotonic()-started, 3), log=str(HERE / f'{label}.log'))
    with (HERE / 'commands.jsonl').open('a') as out:
        out.write(json.dumps(record) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        print((HERE / f'{label}.log').read_text()[-16000:], flush=True)
    return result.returncode

if __name__ == '__main__':
    for index, project in enumerate(PROJECTS):
        code = run(f'build-{index+1}', ['dotnet', 'build', project, '--configuration', 'Release',
                   '--disable-build-servers', '-m:1', '-warnaserror', '--artifacts-path', str(ARTIFACTS), *PROPERTIES])
        if code:
            sys.exit(code)
