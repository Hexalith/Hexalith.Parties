using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Hexalith.EventStore.Contracts.Routing;
using Hexalith.Parties.Contracts.Routing;
using Hexalith.Parties.EventStoreExtensions;

var routes = PartiesCatalogDeclarations.Routes;
var operations = PartiesCatalogDeclarations.Operations;
var adapters = PartiesCatalogAdapters.Create();
foreach (var route in routes)
{
    RouteCatalogValidator.ValidateDeclaration(route);
    _ = RouteCatalogCodec.ComputeDeclarationDigest(route);
}
foreach (var operation in operations)
{
    RouteCatalogValidator.ValidateOperationContract(operation);
    if (operation.Digest != RouteCatalogCodec.ComputeOperationContractDigest(operation))
    {
        throw new InvalidOperationException("Operation digest mismatch.");
    }
}
foreach (var command in PartiesCatalogDeclarations.Commands)
{
    RouteCatalogValidator.ValidateDescriptor(command.DescriptorSchema);
}
if (routes.Count != 41 || operations.Count != 41 || adapters.Count != 28)
{
    throw new InvalidOperationException("Catalog inventory mismatch.");
}
var contracts = typeof(PartiesCatalogDeclarations).Assembly;
var extensions = typeof(PartiesCatalogAdapters).Assembly;
if (!contracts.GetCustomAttributesData().Any(a => a.AttributeType.Name == "RouteCatalogDeclarationSourceAttribute")
    || !extensions.GetCustomAttributesData().Any(a => a.AttributeType.Name == "RouteCatalogAdapterSourceAttribute"))
{
    throw new InvalidOperationException("Catalog source marker missing.");
}
string digest(Assembly assembly) => Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(assembly.Location)));
Console.WriteLine(JsonSerializer.Serialize(new
{
    routes = routes.Count,
    operations = operations.Count,
    adapters = adapters.Count,
    descriptors = PartiesCatalogDeclarations.Commands.Count,
    validator = typeof(RouteCatalogValidator).Assembly.FullName,
    validatorSha256 = digest(typeof(RouteCatalogValidator).Assembly),
    contractsSha256 = digest(contracts),
    adaptersSha256 = digest(extensions),
    boundary = "offline validation of actual compiled artifacts; no topology acceptance",
}, new JsonSerializerOptions { WriteIndented = true }));
