import { expect, test, type Page } from '@playwright/test';

// Temporary probe (not committed): with circuit negotiation held, press Enter in First name or force-click Save on
// the prerendered admin form, then record the main-frame document requests and whether the typed value survives.
for (const path of ['/admin/parties/new', '/admin/parties/ada-lovelace/edit']) {
  for (const action of ['enter', 'save'] as const) {
    test(`${path} ${action}`, async ({ context, page }) => {
      await context.addCookies([{ name: 'parties-admin-e2e', value: 'enabled', url: 'http://127.0.0.1:5072', sameSite: 'Lax' }]);
      const documents: string[] = [];
      page.on('request', (r) => { if (r.isNavigationRequest() && r.frame() === page.mainFrame()) documents.push(`${r.method()} ${new URL(r.url()).pathname}`); });
      let release: () => void = () => undefined;
      const held = new Promise<void>((resolve) => { release = resolve; });
      await page.route((url) => url.pathname.endsWith('/_blazor/negotiate'), async (route) => { await held; await route.continue(); });
      await page.goto(path);
      await expect.poll(() => page.evaluate(() => customElements.get('fluent-button') !== undefined)).toBe(true);
      const input = page.locator('fluent-text-input[aria-describedby$="-PersonFirstName-error"]').locator('input');
      await input.fill('Typed');
      if (action === 'enter') await input.press('Enter');
      else await page.locator('fluent-button[type="submit"]').click({ force: true });
      await page.waitForTimeout(2000);
      const value = await page.locator('fluent-text-input[aria-describedby$="-PersonFirstName-error"]').locator('input').inputValue({ timeout: 2000 }).catch(() => '<absent>');
      const response = await page.evaluate(() => document.title + ' | ' + (document.body?.innerText ?? '').slice(0, 160).replace(/\s+/g, ' '));
      console.log(JSON.stringify({ path, action, documents, typedValueAfter: value, page: response }));
      release();
    });
  }
}
