extern alias apphost;

using System.Text.Json.Nodes;

using Aspire.Hosting.ApplicationModel;
using Aspire.Hosting.Testing;

using CommunityToolkit.Aspire.Hosting.Dapr;

using Hexalith.Parties.IntegrationTests.HealthChecks;

namespace Hexalith.Parties.IntegrationTests.Topology;

/// <summary>Temporary probe (not committed): lists receiver ACL callers with no modeled project in the ordinary model.</summary>
public sealed class ZzOrdinaryCatalogCallerProbe
{
    /// <summary>Builds the ordinary model only and prints each unresolved caller.</summary>
    /// <returns>A task.</returns>
    [Fact]
    public async Task ProbeAsync()
    {
        PartiesTopologySession session = PartiesTopologySession.Create();
        IDistributedApplicationTestingBuilder builder = await DistributedApplicationTestingBuilder
            .CreateAsync<apphost::Projects.Hexalith_Parties_AppHost>(session.Arguments(false, false), TestContext.Current.CancellationToken)
            .ConfigureAwait(true);
        await using var lifetime = builder.ConfigureAwait(true);
        ProjectResource[] withSidecar = [.. builder.Resources.OfType<ProjectResource>().Where(project => project.Annotations.OfType<DaprSidecarAnnotation>().Any())];
        Dictionary<string, string> selected = withSidecar.ToDictionary(project => project.Name, project => project.Annotations.OfType<DaprSidecarAnnotation>()
            .Single().Sidecar.Annotations.OfType<DaprSidecarOptionsAnnotation>().Single().Options.AppId!, StringComparer.Ordinal);
        Console.WriteLine("PROBE modeled: " + string.Join(", ", selected.Select(pair => pair.Key + "=" + pair.Value)));
        foreach (ProjectResource project in withSidecar)
        {
            string? config = project.Annotations.OfType<DaprSidecarAnnotation>().Single().Sidecar.Annotations
                .OfType<DaprSidecarOptionsAnnotation>().Single().Options.Config;
            if (config is null) { Console.WriteLine($"PROBE {project.Name}: no config"); continue; }
            JsonObject document = apphost::Hexalith.Parties.AppHost.PartiesDevelopmentCatalogConfiguration.Read(config);
            JsonArray policies = document["spec"]?["accessControl"]?["policies"]?.AsArray() ?? [];
            string[] callers = [.. policies.Select(policy => policy!["appId"]!.GetValue<string>())];
            string[] unresolved = [.. callers.Where(caller => !selected.ContainsValue(caller))];
            Console.WriteLine($"PROBE {project.Name} ({Path.GetFileName(config)}): callers [{string.Join(", ", callers)}]; unresolved [{string.Join(", ", unresolved)}]");
        }
    }
}
