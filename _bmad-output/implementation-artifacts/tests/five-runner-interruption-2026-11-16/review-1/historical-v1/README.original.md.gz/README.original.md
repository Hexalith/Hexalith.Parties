# Real runner interruption — 2026-11-16

All six final SIGINT qualification cases pass with zero skips and zero emergency
recoveries. Each actual runner remains an interrupted failure internally. The
external supervisor qualifies only its authenticated checkpoint, bounded exit,
independent resource closure and unaffected foreign sentinel.

| Persisted checkpoint | Final pass | Elapsed (s) |
| --- | --- | ---: |
| accepted-deletion | yes | 162.942 |
| admitted-empty-mappings | yes | 163.521 |
| bounded-legacy-discovery | yes | 183.222 |
| cross-source-authority | yes | 100.504 |
| output-known | yes | 157.361 |
| same-uri-refresh | yes | 103.851 |

The admitted case is in `pending-replacement-preflight/`; the other five are in
`final-matrix/`. The two XML commands use one unchanged wrapper and prepared
cohort. `final-six-cases.json` maps every row to its detailed receipt. The admitted
case independently proves original exit, a distinct owned replacement, explicit
pre-STOP connection refusal, subsequent frozen persisted admission and incomplete
replacement quiescence before backing removal. A stale Healthy snapshot is
retained as a diagnostic; it never supplies readiness proof.

| Separate verification lane | Passed | Failed / skipped |
| --- | ---: | ---: |
| Frozen consumer protocol / authority / inventory | 60 | 0 / 0 |
| Frozen signals / cleanup / fixture controls | 60 | 0 / 0 |
| LiveShutdown intended modes (three original + canceled retry) | 4 | 0 / 0 |
| Ordinary six-restart wrapper | 1 | 0 / 0 |
| Ordinary actual runtime child | 1 | 0 / 0 |
| Controlled coordination-cancellation wrapper | 1 | 0 / 0 |

The ordinary wrapper separately completes business recovery, physical-erasure,
survivor and authoritative stream/domain-replay assertions. It retains all six
actual replacements and both approximately 312-second replay-guard drains.
`replay-guard-events.json.gz` retains the unchanged guard observations. No
interrupted business execution is counted as terminal success.

The source host is current Memories commit `65bfb98dca7f65c005213507b15fbe4ab45f2e19`,
a nonpackable diagnostic host with deps version 1.0.0. Consumer packages are
explicit EventStore 5.1.0, Memories 4.0.0 and FrontComposer 6.0.0. Exact source,
executed file and prepared-manifest hashes remain separate from package claims.
No default version, dependency, public endpoint or replay guard changes.

The original baseline in `baseline-3/` reproduces real SIGINT stopping Aspire
observation under ConsoleLifetime. OwnedTopologyDisposed is false and pending
starts exhaust cleanup. Its failed result remains failed; exact-owned emergency
reconciliation is recorded separately. The fix gives the embedded fixture an
explicit lifetime so runner cancellation precedes awaited quiescence/disposal.
Pending-start and infrastructure-removal guards remain enabled. Authenticated
startup custody alone authorizes recovery; rejected phase receipts cannot choose
targets. Observation-only acknowledgements never claim skipped replacements.

Retained diagnostics also include archive/stale-asset preparation refusals, the
aborted pre-custody-fix run, and the safely failed stale-Healthy assertion. The
first broad canceled LiveShutdown row timed out before its controlled point and
then failed cleanup. Its original host birth custody was lost when the wrapper
removed scratch; session-text scans and 32 refused listener ports do not replace
that proof. Exact stopped control IDs/images/mounts, backing absence and an empty
owned network were reconciled separately. That attempt remains unqualified in
`live-shutdown-limited-reconciliation.json.gz`. The fresh canceled-only retry
passes; the original startup-timeout cause remains unestablished. A retry that
omitted cohort environment was refused before startup and is also retained.

Pinned source preparation succeeds, but both mapped Debug builds fail NU1109
(source OpenAPI 11.0.0 versus central 10.0.15). Pinned package preparation refuses
HXW011/HXW010. The documented serialized Release/package fallback and all compiler,
framework, cohort and archive-byte validators remain enabled.

Detailed receipts are deterministic `.json.gz`, `.xml.gz` or `.log.gz` files.
Gzip preserves their retained decoded bytes. For example:

```bash
gzip -dc final-matrix/output-known-checkpoint.json.gz
```

`artifact-index.json.gz` records transport and decoded-byte SHA-256 values;
`SHA256SUMS.gz` covers the final packet; verify it with
`gzip -dc SHA256SUMS.gz | sha256sum --check --quiet`. Paths normalize to documented
`${REPOSITORY}`, `${JOB}`, `${RUNTIME}`, `${PRIVATE}`, `${HOME}` and
`${DOTNET_ROOT}` placeholders. Credentials and content-bearing workflow
properties are excluded; complete private workflow states retain SHA-256
witnesses. Full parsed private workflow witnesses use compact UTF-8 JSON (original field
order, no ASCII forcing) before SHA-256. Raw runtime logs retain exact byte hashes. Useful receipts are
outside scratch, all children/helpers were awaited and both runtime/build scratch
were removed. The global captured-lifetime audit does not requalify failed runs.

Independent parent review and authorized terminal Git publication follow this
handoff. Publication/adoption, historical production inventory, older-writer
exclusion, deployment/workload/key/trust custody and owner acceptance remain open.
Unknown legacy discovery stays incomplete; disposable backing removal supplies
no physical business-erasure claim.
