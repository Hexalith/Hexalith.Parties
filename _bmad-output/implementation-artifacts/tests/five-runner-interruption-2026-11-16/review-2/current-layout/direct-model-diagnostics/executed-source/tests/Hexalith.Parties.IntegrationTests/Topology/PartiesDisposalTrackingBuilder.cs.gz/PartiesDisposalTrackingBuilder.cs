using System.Reflection;

using Aspire.Hosting;

using Microsoft.Extensions.DependencyInjection;

namespace Hexalith.Parties.IntegrationTests.Topology;

/// <summary>Tracks the actual fixture builder-disposal callback without constructing another application.</summary>
public class PartiesDisposalTrackingBuilder : DispatchProxy
{
    /// <summary>Gets or sets the real model services used by composition cleanup.</summary>
    public IServiceCollection Services { get; set; } = null!;

    /// <summary>Gets or sets an optional directly built model without an auto-running AppHost entrypoint.</summary>
    public IDistributedApplicationBuilder? Model { get; set; }

    /// <summary>Gets or sets the owned backing-removal operation invoked by actual builder disposal.</summary>
    public Func<Task> Dispose { get; set; } = null!;

    /// <inheritdoc/>
    protected override object? Invoke(MethodInfo? targetMethod, object?[]? args)
    {
        if (Model is not null && targetMethod is not null && targetMethod.Name is not ("get_Services" or "DisposeAsync"))
        {
            if (targetMethod.Name == "BuildAsync")
            {
                if (args?[0] is CancellationToken cancellation) { cancellation.ThrowIfCancellationRequested(); }
                return Task.FromResult(Model.Build());
            }
            if (targetMethod.Name == "Build") { return Model.Build(); }
            if (targetMethod.Name.StartsWith("get_", StringComparison.Ordinal))
            {
                return typeof(IDistributedApplicationBuilder).GetProperty(targetMethod.Name[4..])!.GetValue(Model);
            }
            MethodInfo method = typeof(IDistributedApplicationBuilder).GetMethods()
                .Single(candidate => candidate.Name == targetMethod.Name && candidate.GetParameters().Length == (args?.Length ?? 0));
            if (method.IsGenericMethodDefinition) { method = method.MakeGenericMethod(targetMethod.GetGenericArguments()); }
            return method.Invoke(Model, args);
        }
        return targetMethod?.Name switch
        {
            "get_Services" => Services,
            "DisposeAsync" => new ValueTask(Dispose()),
            _ => throw new InvalidOperationException("Unexpected testing-builder operation: " + targetMethod?.Name),
        };
    }
}
