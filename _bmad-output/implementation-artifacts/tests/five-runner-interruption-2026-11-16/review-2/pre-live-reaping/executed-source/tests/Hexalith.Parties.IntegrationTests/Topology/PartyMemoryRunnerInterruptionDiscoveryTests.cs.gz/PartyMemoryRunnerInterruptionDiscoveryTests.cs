using System.Diagnostics;
using System.Text.Json;

using Hexalith.Parties.IntegrationTests.HealthChecks;
using Shouldly;

namespace Hexalith.Parties.IntegrationTests.Topology;

/// <summary>Exercises durable partial custody, exact disappearance and aggregate scan cancellation.</summary>
[Collection("Non-parallel")]
public sealed class PartyMemoryRunnerInterruptionDiscoveryTests
{
    /// <summary>Failure to publish a captured birth must propagate before another discovery command can run.</summary>
    [Fact]
    public async Task DurablePublisherFailureCannotBeMistakenForATransientProcRace()
    {
        Assert.SkipUnless(OperatingSystem.IsLinux(), "Linux durable process custody control.");
        string marker = Guid.NewGuid().ToString("N");
        using Process worker = Launch(marker);
        JsonElement authority = PartyMemoryRunnerInterruptionAudit.Authorize("publisher", Path.Combine(Path.GetTempPath(), "unused-publisher-root"), marker, string.Empty);
        int commands = 0;
        try
        {
            IOException failure = await Should.ThrowAsync<IOException>(() => PartyMemoryRunnerInterruptionAudit.DiscoverAsync(authority,
                _ => throw new IOException("controlled durable publisher failure"), TestContext.Current.CancellationToken,
                (_, _) => { commands++; return Task.FromResult(string.Empty); })).ConfigureAwait(true);
            failure.Message.ShouldBe("controlled durable publisher failure");
            commands.ShouldBe(0);
        }
        finally { await ReapAsync(worker).ConfigureAwait(true); }
    }

    /// <summary>A late failed network scan cannot discard an earlier container, volume or process birth.</summary>
    [Fact]
    public async Task PartialDiscoverySurvivesLaterFailureAndContainerDisappearance()
    {
        Assert.SkipUnless(OperatingSystem.IsLinux(), "Linux process custody control.");
        Assert.SkipUnless(Environment.GetEnvironmentVariable("PARTIES_MEMORIES_OWNED_RUNTIME") == "1", "Enable owned Docker interruption controls.");
        string session = Guid.NewGuid().ToString("N")[..12], marker = Guid.NewGuid().ToString("N");
        string root = Path.Combine(Path.GetTempPath(), "hexalith-parties-topology-" + session);
        Directory.CreateDirectory(root);
        var custody = PartyMemoryRunnerInterruptionCustody.Authorize(session, root, marker, string.Empty);
        using Process worker = Launch(marker);
        using Process foreign = Launch(Guid.NewGuid().ToString("N"));
        string container = string.Empty;
        try
        {
            container = (await PartyMemoryRunnerInterruptionAudit.DockerAsync("run", "-d", "--label", "hexalith.parties.test.owner=" + marker,
                "--label", "hexalith.parties.test.session=" + session, "redis:7.4-alpine").ConfigureAwait(true)).Trim();
            await Should.ThrowAsync<IOException>(() => custody.RefreshAsync(TestContext.Current.CancellationToken, (token, args) =>
                args[0] == "network" ? throw new IOException("controlled later discovery failure") : PartyMemoryRunnerInterruptionAudit.DockerAsync(token, args))).ConfigureAwait(true);
            custody.Topology.GetProperty("Processes").EnumerateArray().ShouldContain(item => item.GetProperty("Pid").GetInt32() == worker.Id);
            custody.Topology.GetProperty("Containers").EnumerateArray().Single().GetProperty("Id").GetString().ShouldBe(container);
            string volume = custody.Topology.GetProperty("AnonymousVolumes").EnumerateArray().Single().GetProperty("Name").GetString()!;
            _ = await PartyMemoryRunnerInterruptionAudit.DockerAsync("rm", "-f", container).ConfigureAwait(true);
            await custody.RefreshAsync(TestContext.Current.CancellationToken).ConfigureAwait(true);
            custody.Topology.GetProperty("AnonymousVolumes").EnumerateArray().Single().GetProperty("Name").GetString().ShouldBe(volume);
            await custody.RecoverAsync().ConfigureAwait(true);
            JsonElement closed = await PartyMemoryRunnerInterruptionAudit.VerifyClosedAsync(custody.Topology).ConfigureAwait(true);
            closed.GetProperty("Closed").GetBoolean().ShouldBeTrue();
            foreign.HasExited.ShouldBeFalse();
        }
        finally
        {
            await custody.RecoverAsync().ConfigureAwait(true);
            await ReapAsync(worker).ConfigureAwait(true);
            await ReapAsync(foreign).ConfigureAwait(true);
        }
    }

    /// <summary>Only a fresh exact absence query may resolve a failed inspection.</summary>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ListedObjectDisappearanceIsDistinctFromInspectionFailure(bool disappear)
    {
        Assert.SkipUnless(OperatingSystem.IsLinux(), "Linux Docker custody control.");
        Assert.SkipUnless(Environment.GetEnvironmentVariable("PARTIES_MEMORIES_OWNED_RUNTIME") == "1", "Enable owned Docker interruption controls.");
        string session = Guid.NewGuid().ToString("N")[..12], marker = Guid.NewGuid().ToString("N");
        string root = Path.Combine(Path.GetTempPath(), "hexalith-parties-topology-" + session);
        var custody = PartyMemoryRunnerInterruptionCustody.Authorize(session, root, marker, string.Empty);
        string container = (await PartyMemoryRunnerInterruptionAudit.DockerAsync("run", "-d", "--label", "hexalith.parties.test.owner=" + marker,
            "--label", "hexalith.parties.test.session=" + session, "redis:7.4-alpine").ConfigureAwait(true)).Trim();
        try
        {
            async Task<string> CommandAsync(CancellationToken token, string[] args)
            {
                if (args[0] == "inspect" && args[1] == container)
                {
                    if (disappear) { _ = await PartyMemoryRunnerInterruptionAudit.DockerAsync(token, "rm", "-f", "-v", container).ConfigureAwait(false); }
                    throw new IOException("controlled inspection race");
                }
                return await PartyMemoryRunnerInterruptionAudit.DockerAsync(token, args).ConfigureAwait(false);
            }
            if (disappear) { await custody.RefreshAsync(TestContext.Current.CancellationToken, CommandAsync).ConfigureAwait(true); }
            else { await Should.ThrowAsync<InvalidDataException>(() => custody.RefreshAsync(TestContext.Current.CancellationToken, CommandAsync)).ConfigureAwait(true); }
        }
        finally
        {
            string present = await PartyMemoryRunnerInterruptionAudit.DockerAsync("ps", "-aq", "--no-trunc").ConfigureAwait(true);
            if (present.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Contains(container, StringComparer.Ordinal))
            { _ = await PartyMemoryRunnerInterruptionAudit.DockerAsync("rm", "-f", "-v", container).ConfigureAwait(true); }
        }
    }

    /// <summary>Cancellation reaches a slow command, reaps its supervisor and retains already captured process custody.</summary>
    [Fact]
    public async Task LinkedScanCancellationAwaitsSlowCommandAndKeepsPartialCustody()
    {
        Assert.SkipUnless(OperatingSystem.IsLinux(), "Linux bounded scan control.");
        string marker = Guid.NewGuid().ToString("N");
        using Process worker = Launch(marker);
        var custody = PartyMemoryRunnerInterruptionCustody.Authorize("scan", Path.Combine(Path.GetTempPath(), "unused-scan-root"), marker, string.Empty);
        using var cancellation = CancellationTokenSource.CreateLinkedTokenSource(TestContext.Current.CancellationToken);
        int helper = 0; long birth = 0;
        var elapsed = Stopwatch.StartNew();
        try
        {
            await Should.ThrowAsync<AggregateException>(() => custody.RefreshAsync(cancellation.Token, (token, _) =>
            {
                var command = new ProcessStartInfo("python3") { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
                command.ArgumentList.Add("-c"); command.ArgumentList.Add("import time; time.sleep(120)");
                return PartyMemoryRunnerInterruptionProcess.RunAsync(command, TimeSpan.FromSeconds(10), child =>
                {
                    helper = child.Id; birth = PartiesAspireTopologyFixture.ReadWorkerStartIdentity(helper)!.Value;
                    cancellation.CancelAfter(TimeSpan.FromMilliseconds(100));
                }, token: token);
            })).ConfigureAwait(true);
            elapsed.Elapsed.ShouldBeLessThan(TimeSpan.FromSeconds(3));
            PartiesAspireTopologyFixture.IsWorkerRunning(helper, birth).ShouldBeFalse();
            custody.Topology.GetProperty("Processes").EnumerateArray().ShouldContain(item => item.GetProperty("Pid").GetInt32() == worker.Id);
        }
        finally { await ReapAsync(worker).ConfigureAwait(true); }
    }

    /// <summary>A Docker discovery outage cannot bypass cleanup of an authenticated worker.</summary>
    [Fact]
    public async Task RecoveryQuiescesKnownWorkersWhenBothDiscoveryScansFail()
    {
        Assert.SkipUnless(OperatingSystem.IsLinux(), "Linux failed discovery recovery control.");
        string marker = Guid.NewGuid().ToString("N");
        using Process worker = Launch(marker);
        using Process foreign = Launch(Guid.NewGuid().ToString("N"));
        long birth = PartiesAspireTopologyFixture.ReadWorkerStartIdentity(worker.Id)!.Value;
        JsonElement authority = PartyMemoryRunnerInterruptionAudit.Authorize("outage", Path.Combine(Path.GetTempPath(), "unused-outage-root"), marker, string.Empty);
        try
        {
            await Should.ThrowAsync<AggregateException>(() => PartyMemoryRunnerInterruptionAudit.RecoverAsync(authority,
                command: (_, _) => throw new IOException("controlled Docker outage"))).ConfigureAwait(true);
            PartiesAspireTopologyFixture.IsWorkerRunning(worker.Id, birth).ShouldBeFalse();
            foreign.HasExited.ShouldBeFalse();
        }
        finally { await ReapAsync(worker).ConfigureAwait(true); await ReapAsync(foreign).ConfigureAwait(true); }
    }

    private static Process Launch(string marker)
    {
        var command = new ProcessStartInfo("python3") { UseShellExecute = false };
        command.ArgumentList.Add("-c"); command.ArgumentList.Add("import time; time.sleep(120)");
        command.Environment[PartiesAspireTopologyFixture.WorkerOwnershipVariable] = marker;
        return Process.Start(command) ?? throw new InvalidOperationException("Owned discovery worker did not start.");
    }

    private static async Task ReapAsync(Process process)
    {
        if (!process.HasExited) { process.Kill(); }
        using var reap = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        await process.WaitForExitAsync(reap.Token).ConfigureAwait(false);
    }
}
