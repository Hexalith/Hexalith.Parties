from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
work=Path(__file__).parent
root=Path('/home/administrator/projects/hexalith/parties')
prepare=json.loads((work/'prepare-source.stdout.json').read_text())
source=prepare['buildPreparation']['environment']
checks=json.loads((work/'checks.json').read_text())
base=os.environ.copy()
cleared=sorted(set(source)|{'UseHexalithProjectReferences','UseNuGetDeps','HexalithEventStoreFromSource','HexalithSourceMappingMode','HexalithSourceMappingHash'})
for key in cleared: base.pop(key,None)
build=['dotnet','build','tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj','--configuration','Debug','--disable-build-servers','-m:1']
assembly=['dotnet','tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll']
classes=['Hexalith.Parties.Tests.Gateway.PartySdkQueryHandlerTests','Hexalith.Parties.Tests.Gateway.EventStoreGatewayRoutingTests','Hexalith.Parties.Tests.Gateway.PartiesCatalogGatewaySelectorTests']
def run(name,cmd,overrides=None):
    environment=base.copy(); environment.update(overrides or {})
    log=work/(name+'.log'); start=time.monotonic()
    check={'name':name,'command':cmd,'cwd':str(root),'environment_overrides':overrides or {},'cleared_environment_keys':cleared,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with log.open('wb') as output: p=subprocess.run(cmd,cwd=root,env=environment,stdout=output,stderr=subprocess.STDOUT)
    check.update(exit_code=p.returncode,seconds=round(time.monotonic()-start,3),raw_log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    xml=work/(name+'.xml')
    if xml.exists():
        tree=ET.parse(xml); check['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest()
        check['assemblies']=[x.attrib for x in tree.findall('.//assembly')]
        check['failures']=[{'name':t.get('name'),'message':t.findtext('failure/message'),'stack':t.findtext('failure/stack-trace')} for t in tree.findall('.//test') if t.get('result')=='Fail']
        check['skips']=[{'name':t.get('name'),'reason':t.findtext('reason/message')} for t in tree.findall('.//test') if t.get('result')=='Skip']
    checks.append(check); (work/'checks.json').write_text(json.dumps(checks,indent=2))
    print(name,p.returncode,check.get('assemblies',''),flush=True)
    if p.returncode and not xml.exists(): print(log.read_text(errors='replace')[-5000:],flush=True)
    return p.returncode
for mode,environment in [('source',source),('package',{})]:
    if run(mode+'-build',build,environment): continue
    selection=['dotnet','msbuild','tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj','-nologo','-getProperty:HexalithEventStoreVersion,HexalithEventStoreFromSource,HexalithSourceMappingMode,HexalithSourceMappingHash,Configuration,TargetPath,TreatWarningsAsErrors']
    run(mode+'-selection',selection,environment)
    focus=assembly.copy()
    for name in classes: focus.extend(['-class',name])
    run(mode+'-focused',focus+['-failSkips','-result-xml',str(work/(mode+'-focused.xml'))],environment)
    run(mode+'-full',assembly+['-result-xml',str(work/(mode+'-full.xml'))],environment)
run('archival-normal',['python3','_bmad-output/implementation-artifacts/tests/dw-27-invalid-page-failure-2026-11-09/check-archival-receipt.py'])
run('archival-optimized',['python3','-O','_bmad-output/implementation-artifacts/tests/dw-27-invalid-page-failure-2026-11-09/check-archival-receipt.py'])
run('warning-guard',['bash','scripts/check-no-warning-override.sh'])
run('whitespace',['git','diff','--check'])
