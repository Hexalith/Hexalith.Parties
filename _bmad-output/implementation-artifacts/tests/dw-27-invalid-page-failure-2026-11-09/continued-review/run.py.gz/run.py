from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/parties')
work=Path(__file__).parent
checks=[]
base=os.environ.copy()
cleared=['CustomBeforeDirectoryBuildProps','CustomAfterMicrosoftCommonProps','CustomBeforeDirectoryBuildTargets','CustomAfterDirectoryBuildTargets','AfterMicrosoftNETSdkTargets','HEXALITH_SOURCE_MAPPING_HASH','Configuration','UseHexalithProjectReferences','UseNuGetDeps','HexalithEventStoreFromSource','HexalithSourceMappingMode','HexalithSourceMappingHash']
for key in cleared: base.pop(key,None)
def run(name,command,overrides=None):
    environment=base.copy();environment.update(overrides or {})
    log=work/(name+'.log');start=time.monotonic()
    check={'name':name,'command':command,'cwd':str(root),'environment_overrides':overrides or {},'cleared_environment_keys':cleared,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with log.open('wb') as output:
        p=subprocess.run(command,cwd=root,env=environment,stdout=output,stderr=subprocess.STDOUT)
    check.update(exit_code=p.returncode,seconds=round(time.monotonic()-start,3),log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    xml=work/(name+'.xml')
    if xml.exists():
        tree=ET.parse(xml);check['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest();check['assemblies']=[x.attrib for x in tree.findall('.//assembly')]
        check['failures']=[{'name':t.get('name'),'message':t.findtext('failure/message'),'stack':t.findtext('failure/stack-trace')} for t in tree.findall('.//test') if t.get('result')=='Fail']
        check['skips']=[{'name':t.get('name'),'reason':t.findtext('reason')} for t in tree.findall('.//test') if t.get('result')=='Skip']
    checks.append(check);(work/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(name,p.returncode,check.get('assemblies',''),flush=True)
    if p.returncode and not xml.exists():print(log.read_text(errors='replace')[-3500:],flush=True)
    return p.returncode
cmd=['dotnet','tool','run','hexalith-module','--','prepare-build','--manifest','module/hexalith.module-manifest.v2.json','--workspace',str(work/'mapping'),'--mode','source','--output','json']
if run('prepare-source',cmd):raise SystemExit(1)
prepare=json.loads((work/'prepare-source.log').read_text())
print('diagnostics',json.dumps(prepare.get('diagnostics')),flush=True)
source=prepare['buildPreparation']['environment']
if run('source-build',['dotnet','build','tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj','--configuration','Debug','--disable-build-servers','-m:1'],source):raise SystemExit(1)
run('source-selection',['dotnet','msbuild','tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj','-nologo','-getProperty:HexalithEventStoreVersion,HexalithEventStoreFromSource,HexalithSourceMappingMode,HexalithSourceMappingHash,Configuration,TargetPath,TreatWarningsAsErrors'],source)
assembly=['dotnet','tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll']
classes=['Hexalith.Parties.Tests.Gateway.PartySdkQueryHandlerTests','Hexalith.Parties.Tests.Gateway.EventStoreGatewayRoutingTests','Hexalith.Parties.Tests.Gateway.PartiesCatalogGatewaySelectorTests']
focus=assembly.copy()
for name in classes:focus.extend(['-class',name])
run('source-focused',focus+['-failSkips','-result-xml',str(work/'source-focused.xml')],source)
run('warning-guard',['bash','scripts/check-no-warning-override.sh'])
run('whitespace',['git','diff','--check'])
