from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/parties')
work=Path(__file__).parent
checks=[]
base=os.environ.copy()
cleared=['CustomBeforeDirectoryBuildProps','CustomAfterMicrosoftCommonProps','CustomBeforeDirectoryBuildTargets','CustomAfterDirectoryBuildTargets','AfterMicrosoftNETSdkTargets','HEXALITH_SOURCE_MAPPING_HASH','Configuration','UseHexalithProjectReferences','UseNuGetDeps','HexalithEventStoreFromSource','HexalithSourceMappingMode','HexalithSourceMappingHash']
for key in cleared: base.pop(key,None)
def run(name,command,overrides=None):
    environment=base.copy();environment.update(overrides or {})
    log=work/(name+'.log');start=time.monotonic()
    check={'name':name,'command':command,'cwd':str(root),'environment_overrides':overrides or {},'cleared_environment_keys':cleared,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with log.open('wb') as output:
        p=subprocess.run(command,cwd=root,env=environment,stdout=output,stderr=subprocess.STDOUT)
    check.update(exit_code=p.returncode,seconds=round(time.monotonic()-start,3),log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    xml=work/(name+'.xml')
    if xml.exists():
        tree=ET.parse(xml);check['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest();check['assemblies']=[x.attrib for x in tree.findall('.//assembly')]
        check['failures']=[{'name':t.get('name'),'message':t.findtext('failure/message'),'stack':t.findtext('failure/stack-trace')} for t in tree.findall('.//test') if t.get('result')=='Fail']
        check['skips']=[{'name':t.get('name'),'reason':t.findtext('reason')} for t in tree.findall('.//test') if t.get('result')=='Skip']
    checks.append(check);(work/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(name,p.returncode,check.get('assemblies',''),flush=True)
    if p.returncode and not xml.exists():print(log.read_text(errors='replace')[-3500:],flush=True)
    return p.returncode
checks=json.loads((work/'checks.json').read_text())
source=json.loads((work/'prepare-source.log').read_text())['buildPreparation']['environment']
run('source-prerequisites',['dotnet','tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll','-class','Hexalith.Parties.Tests.FitnessTests.PlatformApiPrerequisitesTests','-result-xml',str(work/'source-prerequisites.xml')],source)
run('archival-normal',['python3','_bmad-output/implementation-artifacts/tests/dw-27-invalid-page-failure-2026-11-09/check-archival-receipt.py'])
run('archival-optimized',['python3','-O','_bmad-output/implementation-artifacts/tests/dw-27-invalid-page-failure-2026-11-09/check-archival-receipt.py'])
