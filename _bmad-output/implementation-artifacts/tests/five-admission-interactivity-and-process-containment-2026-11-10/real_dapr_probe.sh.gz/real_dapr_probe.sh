#!/usr/bin/env bash
# Runs the real Dapr CLI under the launcher body extracted from PartiesDaprCliSubreaper.cs, then stops it as DCP would.
set -u
L="$1"
echo "launcher=$L"; head -3 "$L"
"$L" run --app-id subreaper-probe --dapr-http-port 3999 --dapr-grpc-port 50999 --metrics-port 9999 > real/out.log 2>&1 & P=$!
for i in $(seq 60); do curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3999/v1.0/healthz/outbound 2>/dev/null | grep -q 204 && break; sleep 0.5; done
echo "healthz 204 after ${i} polls"
CLI=$(cat /proc/$P/task/*/children | tr ' ' '\n' | grep -v '^$' | head -1)
D=$(cat /proc/$CLI/task/*/children | tr ' ' '\n' | grep -v '^$' | head -1)
echo "launcher pid=$P comm=$(cat /proc/$P/comm) cmdline=$(tr '\0' ' ' < /proc/$P/cmdline)"
echo "cli pid=$CLI comm=$(cat /proc/$CLI/comm) ppid=$(awk '{print $4}' /proc/$CLI/stat)"
echo "daprd pid=$D comm=$(cat /proc/$D/comm) ppid=$(awk '{print $4}' /proc/$D/stat)"
start=$(date +%s%N); kill -TERM $P; wait $P; code=$?
echo "launcher exit=$code after $(( ($(date +%s%N)-start)/1000000 ))ms"
[ -e /proc/$CLI ] && echo "cli alive" || echo "cli gone"
[ -e /proc/$D ] && echo "daprd alive" || echo "daprd gone"
ss -ltn | grep -E ":3999 |:50999 " || echo "ports released"
echo "--- CLI output"; cat real/out.log
