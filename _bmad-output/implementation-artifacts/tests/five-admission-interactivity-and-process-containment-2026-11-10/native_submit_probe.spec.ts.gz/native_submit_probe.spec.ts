import { expect, test, type Page } from '@playwright/test';

const BASE_URL = process.env.BASE_URL ?? 'http://127.0.0.1:5072';

for (const action of ['enter', 'save'] as const) {
  test(`probe ${action}`, async ({ context, page }) => {
    await context.addCookies([{ name: 'parties-consumer-e2e', value: 'bound', url: BASE_URL, sameSite: 'Lax' }]);
    const documents: string[] = [];
    page.on('request', (r) => { if (r.isNavigationRequest() && r.frame() === page.mainFrame()) documents.push(`${r.method()} ${new URL(r.url()).pathname}`); });
    let negotiations = 0;
    await page.route((url) => url.pathname.endsWith('/_blazor/negotiate'), async () => { negotiations++; await new Promise(() => undefined); });
    await page.goto('/me/edit');
    await expect(page.getByRole('heading', { name: 'Edit profile' })).toBeVisible();
    await expect.poll(() => negotiations).toBe(1);
    await expect.poll(() => page.evaluate(() => customElements.get('fluent-button') !== undefined)).toBe(true);
    if (action === 'enter') {
      await page.locator('fluent-text-input[aria-label="First name"]').locator('input').fill('Typed');
      await page.locator('fluent-text-input[aria-label="First name"]').locator('input').press('Enter');
    } else {
      await page.locator('fluent-text-input[aria-label="First name"]').locator('input').fill('Typed');
      await page.getByRole('button', { name: 'Save changes' }).click({ force: true });
    }
    await page.waitForTimeout(1500);
    const value = await page.locator('fluent-text-input[aria-label="First name"]').locator('input').inputValue().catch(() => '<absent>');
    console.log(`PROBE ${action}: documents=${JSON.stringify(documents)} negotiations=${negotiations} firstName=${value} url=${new URL(page.url()).pathname}`);
  });
}
