@description('The location for the resource(s) to be deployed.')
param location string = resourceGroup().location

param aca_outputs_azure_container_apps_environment_default_domain string

param aca_outputs_azure_container_apps_environment_id string

param memories_containerimage string

param memories_containerport string

@secure()
param memories_app_api_token_value string

@secure()
param memories_dapr_api_token_value string

param aca_outputs_azure_container_registry_endpoint string

param aca_outputs_azure_container_registry_managed_identity_id string

resource memories 'Microsoft.App/containerApps@2025-10-02-preview' = {
  name: 'memories'
  location: location
  properties: {
    configuration: {
      secrets: [
        {
          name: 'app-api-token'
          value: memories_app_api_token_value
        }
        {
          name: 'dapr-api-token'
          value: memories_dapr_api_token_value
        }
      ]
      activeRevisionsMode: 'Single'
      ingress: {
        external: false
        targetPort: int(memories_containerport)
        transport: 'http'
      }
      registries: [
        {
          server: aca_outputs_azure_container_registry_endpoint
          identity: aca_outputs_azure_container_registry_managed_identity_id
        }
      ]
      runtime: {
        dotnet: {
          autoConfigureDataProtection: true
        }
      }
    }
    environmentId: aca_outputs_azure_container_apps_environment_id
    template: {
      containers: [
        {
          image: memories_containerimage
          name: 'memories'
          env: [
            {
              name: 'OTEL_DOTNET_EXPERIMENTAL_OTLP_RETRY'
              value: 'in_memory'
            }
            {
              name: 'ASPNETCORE_FORWARDEDHEADERS_ENABLED'
              value: 'true'
            }
            {
              name: 'HTTP_PORTS'
              value: memories_containerport
            }
            {
              name: 'Authentication__JwtBearer__Authority'
              value: 'https://auth.tache.ai/realms/tache'
            }
            {
              name: 'Authentication__JwtBearer__Issuer'
              value: 'https://auth.tache.ai/realms/tache'
            }
            {
              name: 'Authentication__JwtBearer__Audience'
              value: 'hexalith-memories'
            }
            {
              name: 'Authentication__JwtBearer__RequireHttpsMetadata'
              value: 'true'
            }
            {
              name: 'Authentication__JwtBearer__SigningKey'
              value: ''
            }
            {
              name: 'Authentication__JwtBearer__ValidAlgorithms__0'
              value: 'RS256'
            }
            {
              name: 'Authentication__JwtBearer__ValidAlgorithms__1'
              value: 'ES256'
            }
            {
              name: 'Authentication__JwtBearer__TenantClaimName'
              value: 'tenant_id'
            }
            {
              name: 'APP_API_TOKEN'
              secretRef: 'app-api-token'
            }
            {
              name: 'DAPR_API_TOKEN'
              secretRef: 'dapr-api-token'
            }
            {
              name: 'ConnectionStrings__redis'
              value: 'redis:6379'
            }
            {
              name: 'ConnectionStrings__falkordb'
              value: 'falkordb:6379'
            }
            {
              name: 'ASPNETCORE_ENVIRONMENT'
              value: 'Production'
            }
            {
              name: 'DOTNET_ENVIRONMENT'
              value: 'Production'
            }
          ]
        }
      ]
      scale: {
        minReplicas: 1
      }
    }
  }
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${aca_outputs_azure_container_registry_managed_identity_id}': { }
    }
  }
}