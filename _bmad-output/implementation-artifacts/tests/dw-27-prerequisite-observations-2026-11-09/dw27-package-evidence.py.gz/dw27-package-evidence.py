from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,xml.etree.ElementTree as E
root=Path('/home/administrator/projects/hexalith/parties')
w=Path(Path('/tmp/dw27-prerequisites-work').read_text())
out=root/'_bmad-output/implementation-artifacts/tests/dw-27-prerequisite-observations-2026-11-09'
checks=json.loads((w/'checks.json').read_text())
required=[f'final-{m}-{c}' for m in ['source','package'] for c in ['build','selection','prerequisites','full']]+['final-warning-guard','final-whitespace-crlf']
byname={c['name']:c for c in checks}
assert all(n in byname and byname[n]['exit_code']==0 for n in required), 'Required checks incomplete or failing'
for c in checks:
 xml=w/(c['name']+'.xml')
 if xml.exists():
  tree=E.parse(xml)
  c['skips']=[dict(name=t.get('name'),reason=t.findtext('reason/message') or t.findtext('reason')) for t in tree.findall('.//test') if t.get('result')=='Skip']
  if c['name'].startswith('final-'):
   assert all(int(a['failed'])==0 and int(a['errors'])==0 for a in c['assemblies'])
allowed=['Directory.Build.targets','tests/Hexalith.Parties.Tests/FitnessTests/PlatformApiPrerequisitesTests.cs','_bmad-output/implementation-artifacts/story-8-3-platform-api-prerequisite-matrix.md','_bmad-output/implementation-artifacts/spec-dw-27-invalid-page-failure.md']
initial=json.loads((w/'initial-tracked-hashes.json').read_text())
changed=[p for p,h in initial.items() if not (root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
assert not set(changed)-set(allowed), changed
preserved_receipts=[p for p in initial if p.startswith('_bmad-output/implementation-artifacts/tests/')]
assert not set(changed)&set(preserved_receipts)
mp='_bmad-output/implementation-artifacts/story-8-3-platform-api-prerequisite-matrix.md'
before=subprocess.check_output(['git','show','HEAD:'+mp],cwd=root)
after=(root/mp).read_bytes()
a=before.index('### Current source observation — 2026-11-08'.encode()); b=before.index(b'### Historical source observation',a)
body=before[a:b].split(b'\n',1)[1]
assert body in after
oldrows=[l for l in before.splitlines() if l.startswith(b'|') and (b'selection (2026-11-' in l or b'source selection (2026-11-' in l)]
assert all(l in after for l in oldrows)
p='_bmad-output/implementation-artifacts/spec-dw-27-invalid-page-failure.md'
before_spec=subprocess.check_output(['git','show','HEAD:'+p],cwd=root)
extract=lambda s:s[s.index(b'<frozen-after-approval'):s.index(b'</frozen-after-approval>')+len(b'</frozen-after-approval>')]
assert extract(before_spec)==extract((root/p).read_bytes())
refs={}
for l in subprocess.check_output(['git','ls-tree','HEAD','references/'],cwd=root,text=True).splitlines():
 meta,path=l.split('\t'); mode,kind,sha=meta.split()
 if mode!='160000': continue
 actual=subprocess.check_output(['git','-C',str(root/path),'rev-parse','HEAD'],text=True).strip()
 status=subprocess.check_output(['git','-C',str(root/path),'status','--porcelain','--ignore-submodules=all'],text=True)
 assert sha==actual and not status,(path,sha,actual,status)
 refs[path]=dict(committed=sha,checkout=actual,clean=True)
strict_before=before_spec # actual helper compared independently below
p='tests/Hexalith.Parties.Tests/FitnessTests/PlatformApiPrerequisitesTests.cs'
bt=subprocess.check_output(['git','show','HEAD:'+p],cwd=root).decode().replace('\r\n','\n')
at=(root/p).read_text()
strict=lambda s:s[s.index('    private static void AssertGitlinkAndCheckout('):s.index('    private static string DescribeIdentityGap(')]
assert strict(bt)==strict(at)
(w/'preservation.json').write_text(json.dumps(dict(initial_tracked_count=len(initial),changed_tracked_files=changed,unexpected_changes=[],preserved_historical_receipt_files=len(preserved_receipts),previous_observation_body_sha256=hashlib.sha256(body).hexdigest(),previous_observation_body_preserved=True,dated_selection_rows_preserved=len(oldrows),original_frozen_intent_preserved=True,strict_immutable_helper_preserved=True,dependencies=refs),indent=2)+'\n')
if out.exists(): raise RuntimeError('Refusing to overwrite evidence directory')
out.mkdir()
archives=[]
paths=sorted(p for p in w.iterdir() if p.is_file() and p.suffix in ['.log','.xml','.json'])
paths += [Path('/tmp/dw27-prerequisites-run.py'),Path('/tmp/dw27-package-evidence.py')]
for p in paths:
 raw=p.read_bytes(); compressed=gzip.compress(raw,mtime=0); name=p.name+'.gz'
 (out/name).write_bytes(compressed)
 assert gzip.decompress((out/name).read_bytes())==raw
 archives.append(dict(file=name,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),compressed_sha256=hashlib.sha256(compressed).hexdigest()))
prepare=json.loads((w/'prepare-source.stdout.json').read_text())
receipt=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cwd=str(root),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),spec='_bmad-output/implementation-artifacts/spec-dw-27-prerequisite-observations.md',context_receipt='_bmad-output/implementation-artifacts/tests/dw-27-invalid-page-failure-2026-11-09/continued-review/validation.json',prepare_command=json.loads((w/'prepare-command.json').read_text()),source_preparation=prepare,checks=checks,required_checks=required,required_checks_passed=True,preservation=json.loads((w/'preservation.json').read_text()),archives=archives,approval_scope='Existing 2026-11-08 explicit delegated source-selection signoff at 42b76cd6d79a676ff65c75c724b4d88af8f7f112; observational reconciliation only, no new human signoff or parity approval.',limits=['HXW010 and HXW011 remain disclosed; passing mapped builds do not qualify a supported Platform/tool pair.','Each full service suite has 13 explicitly opted-out live-runtime cases; exact names/reasons remain in XML and checks. No full topology or deployed transport qualification is claimed.','Earlier failing and intermediate results are preserved separately from final passing checks.','Default git diff --check reports CRLF as trailing whitespace; explicit CRLF-aware whitespace and existing warning guard pass.','No historical receipt or original frozen intent is rewritten; no dependency, runtime paging, Git index/history, publication or deployment mutation.','The archived runner uses fresh result paths and exits nonzero on required build/test failures; prepare a fresh mapping/workspace before replay and inspect individual check exits/XML.','The observed source test-assembly hash is retained, but per-mode binaries and complete transitive binary provenance are not retained.'])
(out/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(out)
print('Required checks:',len(required),'pass; archives:',len(archives),'preserved receipts:',len(preserved_receipts))
