from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
work=Path('/tmp/dw27-prerequisites-work').read_text().strip(); work=Path(work)
root=Path('/home/administrator/projects/hexalith/parties')
source=json.loads((work/'prepare-source.stdout.json').read_text())['buildPreparation']['environment']
cleared=json.loads((work/'prepare-command.json').read_text())['cleared']
base=os.environ.copy()
for k in cleared: base.pop(k,None)
build=['dotnet','build','tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj','--configuration','Debug','--disable-build-servers','-m:1']
assembly=['dotnet','tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll']
def run(name,cmd,env):
    log=work/(name+'.log'); xml=work/(name+'.xml')
    if log.exists() or xml.exists(): raise RuntimeError('Refusing to reuse result path '+name)
    start=time.monotonic(); started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with log.open('wb') as output: p=subprocess.run(cmd,cwd=root,env=base|env,stdout=output,stderr=subprocess.STDOUT)
    c=dict(name=name,command=cmd,cwd=str(root),environment_overrides=env,cleared_environment_keys=cleared,started_utc=started,exit_code=p.returncode,seconds=round(time.monotonic()-start,3),log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    if xml.exists():
        t=ET.parse(xml); c['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest(); c['assemblies']=[a.attrib for a in t.findall('.//assembly')]
        c['failures']=[dict(name=x.get('name'),message=x.findtext('failure/message'),stack=x.findtext('failure/stack-trace')) for x in t.findall('.//test') if x.get('result')=='Fail']
        c['skips']=[dict(name=x.get('name'),reason=x.findtext('reason/message')) for x in t.findall('.//test') if x.get('result')=='Skip']
    checks=json.loads((work/'checks.json').read_text()) if (work/'checks.json').exists() else []
    checks.append(c); (work/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(name,p.returncode,[(a.get('passed'),a.get('failed'),a.get('skipped')) for a in c.get('assemblies',[])],flush=True)
    if p.returncode:
        if xml.exists(): print('\n'.join(x['name']+': '+(x['message'] or '')[:280] for x in c['failures']),flush=True)
        else: print(log.read_text(errors='replace')[-5000:],flush=True)
    return p.returncode
if __name__=='__main__':
    stage=sys.argv[1]
    modes=['source'] if stage=='baseline' else ['source','package']
    for mode in modes:
        env=source if mode=='source' else {}
        name=stage+'-'+mode
        if run(name+'-build',build,env): sys.exit(1)
        query=['dotnet','msbuild','tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj','-nologo','-getProperty:HexalithEventStoreVersion,HexalithEventStoreFromSource,HexalithSourceMappingMode,HexalithSourceMappingHash,Configuration,TargetPath,TreatWarningsAsErrors']
        if run(name+'-selection',query,env): sys.exit(1)
        test=name+'-prerequisites'
        result=run(test,assembly+['-class','Hexalith.Parties.Tests.FitnessTests.PlatformApiPrerequisitesTests','-result-xml',str(work/(test+'.xml'))],env)
        if stage=='baseline': sys.exit(result)
        if result: sys.exit(result)
        test=name+'-full'
        if run(test,assembly+['-result-xml',str(work/(test+'.xml'))],env): sys.exit(1)
