"""Show what the HEAD read() returns after each post-check swap (red-proof observation only)."""
import importlib.util, os, sys, tempfile
from pathlib import Path
from unittest.mock import patch
spec = importlib.util.spec_from_file_location('qualification', sys.argv[1])
Q = importlib.util.module_from_spec(spec); spec.loader.exec_module(Q)
for swap in ('parent-symlink', 'file-symlink', 'file-hardlink'):
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary); (root / 'meta').mkdir(); target = root / 'meta' / 'x.json'
        target.write_text('{"genuine": true}'); (root / 'outside').mkdir(); (root / 'outside' / 'x.json').write_text('{"foreign": true}')
        trigger = 'meta' if swap == 'parent-symlink' else 'x.json'; swapped = []
        def replace():
            if swapped: return
            swapped.append(swap)
            if swap == 'parent-symlink':
                (root / 'meta').rename(root / 'meta-held'); (root / 'meta').symlink_to(root / 'outside', target_is_directory=True)
            else:
                target.rename(root / 'x.json.held')
                target.symlink_to(root / 'outside' / 'x.json') if swap == 'file-symlink' else os.link(root / 'outside' / 'x.json', target)
        real_open, real_stat = os.open, os.stat
        def opening(name, *a, **k):
            if os.fspath(name) == trigger: replace()
            return real_open(name, *a, **k)
        def checking(name, *a, **k):
            r = real_stat(name, *a, **k)
            if os.fspath(name) == os.fspath(target): replace()
            return r
        with patch.object(Q.os, 'open', side_effect=opening), patch.object(Q.os, 'stat', side_effect=checking):
            try: print(swap, 'swapped' if swapped or True else '', '->', Q.read(target), 'swapped=', swapped)
            except ValueError as e: print(swap, '-> refused', e, 'swapped=', swapped)
