"""Count released-schema errors in the shared reader fixture's sealed test-result.json (evidence probe only)."""
import importlib.util, json, sys
from pathlib import Path
import jsonschema
scripts, schema_path = Path(sys.argv[1]), Path(sys.argv[2])
spec = importlib.util.spec_from_file_location("fixture", scripts / "test_current_owner_integration.py")
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
fixture = module.CurrentOwnerEvidenceTests("test_current_same_run_evidence_passes_without_qualification_credit")
fixture.setUp()
try:
    validator = jsonschema.Draft202012Validator(json.loads(schema_path.read_text()), format_checker=jsonschema.FormatChecker())
    errors = list(validator.iter_errors(json.loads((fixture.root / "test-result.json").read_text())))
    print(json.dumps({"scripts": str(scripts), "schemaErrors": len(errors),
                      "errors": [{"path": list(map(str, e.absolute_path)), "message": e.message[:120]} for e in errors]}, indent=1))
finally:
    fixture.doCleanups()
