# Original ten findings

- Finding floor: 174,532 bytes ÷ 1,000 = 174.532 kB; N = min(⌊√174.532 + 1⌋, 10) = 10.

- `verify-receipt.py:215`: The mandatory input inventory omits changed `PlatformApiPrerequisitesTests.cs`, the prerequisite matrix, and owner `PackageGovernanceTests.cs`. Their contents can drift while verification succeeds. Bind these inputs to the tested revisions.

- `verify-receipt.py:156`: The assembly binding checks paths but ignores `final-parent-package-assembly.json`. I changed that archive’s path to `different.dll` and digest to all zeros, refreshed its archive hashes, and verification still succeeded. Validate the assembly snapshot against the selection and execution records.

- `verify-receipt.py:146`: Successful build records are accepted without validating their project, working directory, or dependency mode. I changed the final build to `different.csproj`, an unrelated directory, and source-mode environment overrides; verification succeeded. Require the expected invocation and matching mode.

- `verify-receipt.py:152`: The package-selection command’s exit code is unchecked. Setting `final-parent-package-selection.exit_code` to `1` still succeeds. Require successful evaluation before consuming its properties.

- `verify-receipt.py:118`: Converting floor cases to a set hides duplicate executions. I replaced an older floor control with a duplicate entry-target case, retained unique IDs and 48 total tests, and verification succeeded. Require exactly one execution of each expected argument tuple and preserve the remaining control inventory.

- `verify-receipt.py:105`: Comparing the two parent reports cannot establish that their shared skips were already permitted. I moved the same skip from an optional runtime test to a passing test in both reports; verification succeeded. Check both against an explicit permitted skip inventory.

- `verify-receipt.py:108`: The projection skip check validates its name without requiring a reason. Removing its `<reason>` element still succeeds. Require the documented compatibility reason as well as the identity.

- `verify-receipt.py:140`: Owner baseline comparison checks failing names without checking failure causes. I replaced a patched failure’s exception and message with an unrelated application regression; verification succeeded. Compare normalized failure diagnostics before classifying failures as unchanged environmental blockers.

- `verify-receipt.py:162`: Review reports need only exist. Replacing `blind-hunter-followup.md` with an empty payload and refreshing its hashes still succeeds. Require substantive retained review content and its corresponding disposition evidence.

- `verify-receipt.py:182`: Recorded revision metadata is not reconciled with the archived scope. I changed the embedded owner-selected commit, observed head, and resume revision to all-zero SHAs; verification succeeded. Cross-check these fields against `scope.json`, the fixed preservation anchors, and the recorded tested revisions.

# First corrective clearance

No remaining actual defects found against the ten findings.

Independently reran all 35 receipt fixtures in normal and optimized Python: both exited 0, totaling 70 passing cases. The unavailable final-binary provenance is accurately disclosed. No repository files were edited.

# Final narrow-delta report

Clearance: no remaining actual issues found in the final narrow delta (`dd46021023d71c60f07fb0156988b212a5397feab2d226261045b84690186e00`). Both anchors match the retained payloads, and the floor inventory contains 48 distinct cases. Independently reran all 38 fixtures in normal and optimized Python: both exited 0, totaling 76 passing cases, including all three new corruptions. No repository files were edited.

Saved all three reports to [the review record](${SECOND_REVIEW}/second-review-blind-hunter.md).
