import json
from collect import ROOT, WORK, run
env = json.loads((WORK / 'source-environment.json').read_text())
owner = ROOT / 'references/Hexalith.Tenants'
for name in ['Contracts', 'Server']:
    slug = 'owner-' + name.lower() + '-socket-enabled'
    result = run(slug, ['dotnet', str(owner / f'tests/Hexalith.Tenants.{name}.Tests/bin/Debug/net10.0/Hexalith.Tenants.{name}.Tests.dll'),
        '-noColor', '-result-xml', str(WORK / (slug + '.xml'))], cwd=owner, extra=env)
