from pathlib import Path
import copy,gzip,json,importlib.util,hashlib,tempfile,shutil,xml.etree.ElementTree as ET
root=Path.cwd();folder=root/'_bmad-output/implementation-artifacts/tests/six-fitness-failures-resumed-2026-11-09'
s=importlib.util.spec_from_file_location('gate',folder/'verify-receipt.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
base=json.loads((folder/'validation.json').read_text())
def run(d,n): return next(r for r in d['runs'] if r['name']==n)
def xml_error(d,w):
 r=run(d,'final-parent-package-full-corrected');item=d['archives'][r['xml']]
 tree=ET.fromstring(gzip.decompress((w/item['archive']).read_bytes()))
 ET.SubElement(ET.SubElement(tree,'errors'),'error',{'type':'assembly-cleanup'}).text='runner failed'
 plain=ET.tostring(tree);blob=gzip.compress(plain,mtime=0);(w/item['archive']).write_bytes(blob)
 item.update(compressed_sha256=hashlib.sha256(blob).hexdigest(),sanitized_sha256=hashlib.sha256(plain).hexdigest(),original_sha256=hashlib.sha256(plain).hexdigest());r['xml_sha256']=item['original_sha256']
def missing_review(d,w):
 d.pop('followup_review')
 for n in list(d['archives']):
  if n.startswith('second-review-'):d['archives'].pop(n)
mutations=[
 ('BH-T01-filtered-full',lambda d,w:run(d,'final-parent-package-full-corrected')['command'].extend(['-class','NoSuchClass'])),
 ('BH-T02-unmapped-tests',lambda d,w:[run(d,n).update(environment_overrides={}) for n in ['parent-source-fitness-tests','parent-source-full-socket-enabled','projections-source-tests','owner-server-socket-enabled']]),
 ('BH-T03-missing-selections',lambda d,w:d.update(runs=[r for r in d['runs'] if r['name'] not in ['parent-source-fitness-selection','projections-source-selection','owner-contracts-selection','owner-server-selection']])),
 ('BH-T04-missing-owner-builds',lambda d,w:d.update(runs=[r for r in d['runs'] if r['name'] not in ['owner-contracts-build','owner-server-build']])),
 ('BH-T05-unrelated-blocker',lambda d,w:run(d,'final-parent-source-build').update(command=['unrelated'],cwd='unrelated',environment_overrides={})),
 ('BH-T06-hook-commands',lambda d,w:[r.update(command=['dotnet','msbuild','unrelated.proj','-t:ValidateEventStorePackageFloor']) for r in d['runs'] if r['name'].startswith('hook-qualified-')]),
 ('BH-T07-failed-commitlint',lambda d,w:[run(d,n).update(exit_code=1) for n in ['root-commitlint','owner-commitlint']]),
 ('BH-T08-missing-safeguards',lambda d,w:d.update(runs=[r for r in d['runs'] if r['name'] not in ['warning-guard','gitlink-worktree','scope-whitespace']])),
 ('BH-T09-missing-second-review',missing_review),
 ('BH-T10-missing-fixture-input',lambda d,w:None),
 ('EC-T01-runner-error',xml_error),
]
results=[]
for name,change in mutations:
 with tempfile.TemporaryDirectory() as td:
  w=Path(td)
  for item in base['archives'].values():shutil.copy2(folder/item['archive'],w/item['archive'])
  d=copy.deepcopy(base);change(d,w)
  try:g.verify(w,root,d)
  except Exception as e: result=str(e)
  else:result='accepted'
  results.append({'name':name,'before':result})
print(json.dumps(results,indent=2));Path('${THIRD_REVIEW}/probes-before.json').write_text(json.dumps(results,indent=2)+'\n')
