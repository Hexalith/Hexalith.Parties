import json
import hashlib
from collect import ROOT, WORK, run

command = ['dotnet', 'tool', 'run', 'hexalith-module', '--', 'prepare-build',
    '--manifest', 'module/hexalith.module-manifest.v2.json',
    '--workspace', str(WORK / 'mapping-final'), '--mode', 'source', '--output', 'json']
result = run('final-prepare-source', command)
if result['exit_code']:
    print((WORK / result['log']).read_text()[-4000:])
    raise SystemExit(result['exit_code'])
data = json.loads((WORK / result['log']).read_text())
(WORK / 'final-preparation.json').write_text(json.dumps(data, indent=2) + '\n')
env = data['buildPreparation']['environment']
(WORK / 'final-source-environment.json').write_text(json.dumps(env, indent=2) + '\n')
project = 'tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj'
result = run('final-parent-source-build', ['dotnet', 'build', project,
    '--configuration', 'Debug', '--disable-build-servers', '-m:1'], extra=env)
if result['exit_code']:
    print((WORK / result['log']).read_text()[-4000:])
    raise SystemExit(result['exit_code'])
result = run('final-parent-selection', ['dotnet', 'msbuild', project, '-nologo',
    '-getProperty:TargetPath,Configuration,TreatWarningsAsErrors,HexalithEventStoreVersion,HexalithEventStoreFromSource,HexalithSourceMappingMode,HexalithSourceMappingHash'], extra=env)
props = json.loads((WORK / result['log']).read_text())['Properties']
target = ROOT / 'tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll'
if props['TargetPath'] != str(target) or props['Configuration'] != 'Debug' or props['HexalithEventStoreFromSource'] != 'true':
    raise RuntimeError('Incorrect source selection')
(WORK / 'final-parent-assembly.json').write_text(json.dumps({'path': str(target),
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'properties': props}, indent=2) + '\n')
result = run('final-documentation', ['dotnet', str(target), '-noColor', '-class',
    'Hexalith.Parties.Tests.FitnessTests.DocumentationFitnessTests',
    '-result-xml', str(WORK / 'final-documentation.xml')], extra=env)
raise SystemExit(result['exit_code'])
