import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('${PARTIES_ROOT}')
WORK = Path(__file__).resolve().parent
MAPPING_KEYS = {'CustomBeforeDirectoryBuildProps', 'CustomAfterMicrosoftCommonProps',
                'CustomBeforeDirectoryBuildTargets', 'CustomAfterDirectoryBuildTargets',
                'AfterMicrosoftNETSdkTargets', 'HEXALITH_SOURCE_MAPPING_HASH',
                'Configuration', 'UseHexalithProjectReferences', 'UseNuGetDeps'}
CLEAR_KEYS = sorted(k for k in os.environ if k in MAPPING_KEYS or
                    (k.startswith('Hexalith') and
                     (k.endswith(('FromSource', 'Root')) or 'Mapping' in k)))
BASE_ENV = {k: v for k, v in os.environ.items() if k not in CLEAR_KEYS}

def run(name, command, cwd=ROOT, extra=None, timeout=600):
    env = BASE_ENV | (extra or {})
    started = time.monotonic()
    record = {'name': name, 'command': command, 'cwd': str(cwd),
              'environment_overrides': extra or {}, 'cleared_environment_keys': CLEAR_KEYS,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    log = WORK / (name + '.log')
    with log.open('wb') as out:
        proc = subprocess.Popen(command, cwd=cwd, env=env, stdout=out,
                                stderr=subprocess.STDOUT, start_new_session=True)
        try:
            record['exit_code'] = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait(timeout=10)
            record['exit_code'] = 124
            record['timeout_seconds'] = timeout
    record['seconds'] = round(time.monotonic() - started, 3)
    record['log'] = log.name
    record['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
    if '-result-xml' in command:
        xml = Path(command[command.index('-result-xml') + 1])
        if xml.exists():
            tree = ET.parse(xml)
            record['xml'] = xml.name
            record['xml_sha256'] = hashlib.sha256(xml.read_bytes()).hexdigest()
            record['assemblies'] = [e.attrib for e in tree.findall('.//assembly')]
            record['failures'] = [{'name': t.get('name'), 'message': t.findtext('failure/message')}
                                  for t in tree.findall('.//test') if t.get('result') == 'Fail']
            record['skips'] = [{'name': t.get('name'), 'reason': t.findtext('reason/message')}
                               for t in tree.findall('.//test') if t.get('result') == 'Skip']
    with (WORK / 'checks.jsonl').open('a') as out:
        out.write(json.dumps(record) + '\n')
    print(json.dumps({'name': name, 'exit_code': record['exit_code'],
                      'seconds': record['seconds'], 'assemblies': record.get('assemblies')}), flush=True)
    return record

def prepare():
    cmd = ['dotnet', 'tool', 'run', 'hexalith-module', '--', 'prepare-build',
           '--manifest', 'module/hexalith.module-manifest.v2.json',
           '--workspace', str(WORK / 'mapping'), '--mode', 'source', '--output', 'json']
    r = run('prepare-source', cmd)
    if r['exit_code']:
        print((WORK / r['log']).read_text()[-5000:]); sys.exit(1)
    data = json.loads((WORK / r['log']).read_text())
    (WORK / 'preparation.json').write_text(json.dumps(data, indent=2) + '\n')
    return data['buildPreparation']['environment']

def build_and_test(name, project, assembly, env, filters=None):
    r = run(name + '-build', ['dotnet', 'build', project, '--configuration', 'Debug',
                              '--disable-build-servers', '-m:1'], extra=env)
    if r['exit_code']:
        print((WORK / r['log']).read_text()[-5000:]); return False
    props = run(name + '-selection', ['dotnet', 'msbuild', project, '-nologo',
          '-getProperty:TargetPath,Configuration,TreatWarningsAsErrors,HexalithEventStoreVersion,HexalithEventStoreFromSource,HexalithSourceMappingMode,HexalithSourceMappingHash'], extra=env)
    data = json.loads((WORK / props['log']).read_text())['Properties']
    target = Path(data['TargetPath'])
    if not target.is_absolute(): target = ROOT / target
    if target != ROOT / assembly:
        raise RuntimeError('Evaluated TargetPath differs: ' + str(target))
    if data['Configuration'] != 'Debug' or data['TreatWarningsAsErrors'].lower() != 'true':
        raise RuntimeError('Unexpected build properties: ' + str(data))
    (WORK / (name + '-assembly.json')).write_text(json.dumps({'path':str(target),
          'sha256':hashlib.sha256(target.read_bytes()).hexdigest(), 'properties':data}, indent=2)+'\n')
    args = ['dotnet', str(target), '-noColor'] + (filters or [])
    r = run(name + '-tests', args + ['-result-xml', str(WORK / (name + '-tests.xml'))], extra=env)
    return r['exit_code'] == 0

if __name__ == '__main__':
    env = prepare()
    (WORK / 'source-environment.json').write_text(json.dumps(env, indent=2)+'\n')
    build_and_test('parent-source-fitness',
        'tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj',
        'tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll', env,
        ['-class', 'Hexalith.Parties.Tests.FitnessTests.*'])
