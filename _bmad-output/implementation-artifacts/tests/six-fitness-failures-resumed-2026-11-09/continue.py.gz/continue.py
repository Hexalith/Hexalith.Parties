import json
import sys
from collect import ROOT, WORK, run, build_and_test

env = json.loads((WORK / 'source-environment.json').read_text())
run('parent-source-full', ['dotnet', str(ROOT / 'tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll'),
    '-noColor', '-result-xml', str(WORK / 'parent-source-full.xml')], extra=env)
build_and_test('projections-source',
    'tests/Hexalith.Parties.Projections.Tests/Hexalith.Parties.Projections.Tests.csproj',
    'tests/Hexalith.Parties.Projections.Tests/bin/Debug/net10.0/Hexalith.Parties.Projections.Tests.dll', env)
owner = ROOT / 'references/Hexalith.Tenants'
for name in ['Contracts', 'Server']:
    project = f'tests/Hexalith.Tenants.{name}.Tests/Hexalith.Tenants.{name}.Tests.csproj'
    slug = 'owner-' + name.lower()
    result = run(slug + '-build', ['dotnet','build',project,'--configuration','Debug',
             '--disable-build-servers','-m:1'], cwd=owner, extra=env)
    if result['exit_code']:
        print((WORK / result['log']).read_text()[-5000:],flush=True)
        continue
    query = run(slug + '-selection', ['dotnet', 'msbuild', project, '-nologo',
             '-getProperty:TargetPath,Configuration,TreatWarningsAsErrors,HexalithEventStoreFromSource,HexalithSourceMappingMode'],
             cwd=owner, extra=env)
    props = json.loads((WORK / query['log']).read_text())['Properties']
    if props['Configuration'] != 'Debug' or props['TreatWarningsAsErrors'].lower() != 'true':
        raise RuntimeError('Wrong owner build properties')
    run(slug + '-full', ['dotnet', props['TargetPath'], '-noColor', '-result-xml',
        str(WORK / (slug + '-full.xml'))], cwd=owner, extra=env)
