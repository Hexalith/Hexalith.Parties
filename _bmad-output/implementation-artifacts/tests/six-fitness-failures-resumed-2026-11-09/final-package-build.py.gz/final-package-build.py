import json
import hashlib
from collect import ROOT, WORK, run

project = 'tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj'
result = run('final-parent-package-build', ['dotnet', 'build', project,
    '--configuration', 'Debug', '--disable-build-servers', '-m:1'])
if result['exit_code']:
    print((WORK / result['log']).read_text()[-4000:])
    raise SystemExit(result['exit_code'])
result = run('final-parent-package-selection', ['dotnet', 'msbuild', project, '-nologo',
    '-getProperty:TargetPath,Configuration,TreatWarningsAsErrors,HexalithEventStoreVersion,HexalithEventStoreFromSource,HexalithSourceMappingMode,HexalithSourceMappingHash'])
props = json.loads((WORK / result['log']).read_text())['Properties']
target = ROOT / 'tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll'
if props['TargetPath'] != str(target) or props['Configuration'] != 'Debug' or props['HexalithEventStoreFromSource'] not in ['', 'false'] or props['HexalithSourceMappingMode']:
    raise RuntimeError('Incorrect package selection')
(WORK / 'final-parent-package-assembly.json').write_text(json.dumps({'path': str(target),
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'properties': props}, indent=2) + '\n')
result = run('final-documentation-package', ['dotnet', str(target), '-noColor', '-class',
    'Hexalith.Parties.Tests.FitnessTests.DocumentationFitnessTests',
    '-result-xml', str(WORK / 'final-documentation-package.xml')])
raise SystemExit(result['exit_code'])
