from collect import ROOT, WORK, run
result = run('final-parent-package-full-corrected', ['dotnet',
    str(ROOT / 'tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll'),
    '-noColor', '-result-xml', str(WORK / 'final-parent-package-full-corrected.xml')])
raise SystemExit(result['exit_code'])
