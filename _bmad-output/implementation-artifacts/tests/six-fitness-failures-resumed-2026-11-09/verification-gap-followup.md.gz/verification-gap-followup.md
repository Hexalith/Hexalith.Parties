The original scheduling gap is covered by the corrective owner patch.

`EventStorePackageFloorRunsThroughRestoreAndBuildAsync` supplies both `CollectPackageReferences` and `PrepareForBuild` to the subprocess helper. The helper defines these entry targets, imports the real owner targets, and invokes the selected entry target rather than invoking the floor directly. Its rejected cases require a nonzero exit and the specific floor diagnostic; accepted cases check the exact selected property and all three package versions. Removing the floor's `BeforeTargets` scheduling would therefore make the four below-floor/prerelease cases fail their rejection assertions. Stable metadata, the current 4.1.0 selection, and exact source authority are checked through both entries.

I read both corrective diffs and the complete affected helper/assertion paths. The parent reports all 48 existing and new floor cases passing; I did not independently rerun that suite. The root documentation corrections match the selected Memories 3.0.25 catalog and retain the separate Dapr runtime expectation.

No remaining verification gaps or other patch issues found.
