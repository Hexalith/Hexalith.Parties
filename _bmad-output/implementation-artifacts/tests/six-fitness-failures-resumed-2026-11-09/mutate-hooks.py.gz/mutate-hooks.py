import json
from pathlib import Path
import xml.etree.ElementTree as ET
from collect import ROOT, WORK, run

owner = ROOT / 'references/Hexalith.Tenants'
folder = WORK / 'hook-mutation'
folder.mkdir(exist_ok=True)
targets = ET.parse(owner / 'Directory.Build.targets')
floor = next(t for t in targets.getroot().findall('Target') if t.get('Name') == 'ValidateEventStorePackageFloor')
if floor.get('BeforeTargets') != 'CollectPackageReferences;PrepareForBuild':
    raise RuntimeError('Unexpected floor scheduling')
del floor.attrib['BeforeTargets']
detached = folder / 'detached.targets'
targets.write(detached, encoding='utf-8', xml_declaration=True)
controls = []
for variant, target_file in [('connected', owner / 'Directory.Build.targets'), ('detached', detached)]:
    project = ET.Element('Project')
    props = ET.SubElement(project, 'PropertyGroup')
    for k, v in {'HexalithVersionsLoaded': 'true', 'HexalithEventStoreVersion': '3.128.3',
                 'UseHexalithProjectReferences': 'false',
                 'HexalithContainerProvenanceTargets': str(ROOT / 'references/Hexalith.Builds/Props/ContainerProvenance.targets')}.items():
        ET.SubElement(props, k).text = v
    ET.SubElement(project, 'Import', {'Project': str(owner / 'Directory.Build.props')})
    ET.SubElement(project, 'Import', {'Project': str(target_file)})
    for target in ['CollectPackageReferences', 'PrepareForBuild']:
        ET.SubElement(project, 'Target', {'Name': target})
    fixture = folder / (variant + '.proj')
    ET.ElementTree(project).write(fixture, encoding='utf-8', xml_declaration=True)
    for target in ['CollectPackageReferences', 'PrepareForBuild', 'ValidateEventStorePackageFloor']:
        name = 'hook-qualified-' + variant + '-' + target
        result = run(name, ['dotnet', 'msbuild', str(fixture), '-nologo', '-target:' + target,
                           '-property:HexalithEventStoreVersion=3.128.3',
                           '-property:HexalithContainerProvenanceTargets=' + str(ROOT / 'references/Hexalith.Builds/Props/ContainerProvenance.targets')], cwd=owner)
        rejects = variant == 'connected' or target == 'ValidateEventStorePackageFloor'
        diagnostic = 'must be at least 3.128.4 for completion recovery' in (WORK / result['log']).read_text()
        valid = result['exit_code'] != 0 and diagnostic if rejects else result['exit_code'] == 0
        controls.append({'name': name, 'expected_rejection': rejects, 'diagnostic': diagnostic, 'valid': valid})
        if not valid:
            raise RuntimeError('Mutation control failed: ' + name)
(WORK / 'hook-mutation.json').write_text(json.dumps({'controls': controls,
    'conclusion': 'Detaching only the hook is detected by both entry targets; direct validation alone still rejects.'}, indent=2) + '\n')
