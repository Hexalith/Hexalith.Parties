Cleared. Both exact message payloads match their pinned hashes and retained commitlint logs. No remaining defects found in the incremental fix.

Independent normal and optimized fixture runs each passed all 53 cases, exit 0, including both message-replacement mutations.
