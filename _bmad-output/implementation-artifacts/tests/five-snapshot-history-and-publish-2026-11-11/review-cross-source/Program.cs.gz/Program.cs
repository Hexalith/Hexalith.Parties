using System.Security.Cryptography;
using System.Text.Json;
using Dapr.Workflow;
using Hexalith.EventStore.Client.Queries;
using Hexalith.Memories.Contracts.V1;
using Hexalith.Memories.IntegrationTests.Fixtures;
using Hexalith.Memories.IntegrationTests.Ingestion;
using Hexalith.Memories.Server.Activities.Cases;
using Hexalith.Memories.Server.Activities.Indexing;
using Hexalith.Memories.Server.Activities.Ingestion;
using Hexalith.Memories.Server.Graph;
using Hexalith.Memories.Server.Infrastructure;
using Hexalith.Memories.Server.Ingestion;
using Hexalith.Memories.Server.NaturalLanguage;
using Hexalith.Memories.Server.Workflows;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using NRedisStack.RedisStackCommands;
using NSubstitute;
using StackExchange.Redis;

public static class Program
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    private static async Task<string> HashAsync(IDatabase db, string key)
    {
        HashEntry[] entries = await db.HashGetAllAsync(key);
        var ordered = entries.OrderBy(entry => entry.Name.ToString(), StringComparer.Ordinal)
            .Select(entry => new { name = entry.Name.ToString(), bytes = Convert.ToBase64String((byte[])entry.Value!) }).ToArray();
        return Convert.ToHexStringLower(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(ordered, Json)));
    }

    public static async Task<int> Main(string[] args)
    {
        string output = args[0];
        var receipt = new Dictionary<string, object?>();
        string? priorEndpoint = Environment.GetEnvironmentVariable("DAPR_GRPC_ENDPOINT");
        string? priorToken = Environment.GetEnvironmentVariable("DAPR_API_TOKEN");
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(120));
        CancellationToken token = deadline.Token;
        var redis = new RedisStackFixture();
        var graph = new FalkorDbFixture();
        DaprStateSidecarFixture? sidecar = null;
        IHost? historical = null;
        IHost? modern = null;
        var pause = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        bool passed = false;
        try
        {
            await redis.InitializeAsync();
            await graph.InitializeAsync();
            receipt["ownedRedisContainerId"] = ((DotNet.Testcontainers.Containers.IContainer?)typeof(RedisStackFixture).GetField("_container", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)!.GetValue(redis))?.Id;
            receipt["ownedGraphContainerId"] = ((DotNet.Testcontainers.Containers.IContainer?)typeof(FalkorDbFixture).GetField("_container", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)!.GetValue(graph))?.Id;
            sidecar = DaprStateSidecarFixture.CreateWorkflow(redis.ConnectionString, authenticate: true);
            await sidecar.InitializeAsync();
            var ownedDaprd = (System.Diagnostics.Process)typeof(DaprStateSidecarFixture).GetField("_daprd", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)!.GetValue(sidecar)!;
            receipt["ownedDaprdPid"] = ownedDaprd.Id;
            receipt["ownedDaprdStartTimeUtc"] = ownedDaprd.StartTime.ToUniversalTime().ToString("O");
            Environment.SetEnvironmentVariable("DAPR_API_TOKEN", sidecar.ApiToken);
            Environment.SetEnvironmentVariable("DAPR_GRPC_ENDPOINT", sidecar.DaprGrpcEndpoint);
            string tenant = "cross-source-" + Guid.NewGuid().ToString("N");
            string id = "producer-" + Guid.NewGuid().ToString("N");
            string survivor = "survivor-" + Guid.NewGuid().ToString("N");
            string sourceA = "https://synthetic.invalid/source-a";
            string sourceB = "https://synthetic.invalid/virgin-source-b";
            IngestionInput inputA = new() { TenantId = tenant, CaseId = "case", SourceUri = sourceA,
                SourceType = SourceType.Url, ContentType = "text/plain", IngestedBy = "owned-cross-source-probe" };
            IngestionInput inputB = inputA with { SourceUri = sourceB };
            IDatabase db = redis.Connection.GetDatabase();
            string chunk = IndexSchemaDefinitions.BuildSemanticChunkKey(tenant, id, 7);
            string survivorChunk = IndexSchemaDefinitions.BuildSemanticChunkKey(tenant, survivor, 7);
            receipt["tenant"] = tenant;
            receipt["unitAndWorkflowIdentity"] = id;
            receipt["historicalSource"] = sourceA;
            receipt["modernSource"] = sourceB;
            receipt["ownedRedisEndpoint"] = redis.ConnectionString;
            receipt["ownedGraphEndpoint"] = graph.ConnectionString;
            receipt["ownedDaprApp"] = sidecar.AppId;
            db.FT().Create(IndexSchemaDefinitions.GetSemanticIndexName(tenant), IndexSchemaDefinitions.CreateSemanticParams(tenant), IndexSchemaDefinitions.CreateSemanticSchema(3));
            historical = Host.CreateDefaultBuilder().ConfigureServices(services =>
            {
                services.AddKeyedSingleton<IConnectionMultiplexer>("redis", redis.Connection);
                services.AddDaprWorkflow(options =>
                {
                    options.RegisterWorkflow<HistoricalCandidateArtifactWorkflow>(nameof(IngestionWorkflow));
                    options.RegisterActivity<IndexSemanticChunksActivity>();
                });
            }).Build();
            await historical.StartAsync(token);
            var oldClient = historical.Services.GetRequiredService<DaprWorkflowClient>();
            await oldClient.ScheduleNewWorkflowAsync(nameof(IngestionWorkflow), id, inputA, null, token);
            var oldState = await oldClient.WaitForWorkflowCompletionAsync(id, true, token);
            Require(oldState.RuntimeStatus == WorkflowRuntimeStatus.Completed, "Historical source A did not complete.");
            Require(oldState.ReadInputAs<IngestionInput>()!.SourceUri == sourceA, "Wrong retained historical source input.");
            await oldClient.ScheduleNewWorkflowAsync(nameof(IngestionWorkflow), survivor, inputA with { SourceUri = sourceA + "/survivor" }, null, token);
            Require((await oldClient.WaitForWorkflowCompletionAsync(survivor, true, token)).RuntimeStatus == WorkflowRuntimeStatus.Completed, "Survivor did not complete.");
            Require((await db.HashGetAsync(chunk, "chunkText")).ToString() == "owned historical chunk", "Historical chunk bytes absent.");
            string oldHash = await HashAsync(db, chunk);
            string survivorHash = await HashAsync(db, survivorChunk);
            receipt["historicalChunkKey"] = chunk;
            receipt["historicalChunkBeforeSha256"] = oldHash;
            receipt["survivorBeforeSha256"] = survivorHash;
            receipt["historicalCompleted"] = true;
            Require(!await db.KeyExistsAsync(SourcePublicationVisibility.Keys(tenant, id)), "Historical workflow unexpectedly tracked exact keys.");
            Require(!await db.KeyExistsAsync(SourcePublicationVisibility.KeyProvenance(tenant, id)), "Historical workflow unexpectedly had provenance.");
            Require(await oldClient.PurgeInstanceAsync(id, token), "Actual Dapr purge was refused.");
            Require(!(await oldClient.GetWorkflowStateAsync(id, true, token)).Exists, "Workflow state survived actual purge.");
            receipt["actualHistoricalPurgeSucceeded"] = true;
            receipt["historicalMetadataAbsent"] = true;
            receipt["historicalChunkAfterPurgeSha256"] = await HashAsync(db, chunk);
            await historical.StopAsync(token);
            historical.Dispose(); historical = null;

            var inventory = new SourceInventoryStore(redis.Connection, new QueryCursorCodec(new EphemeralDataProtectionProvider(), "CrossSourceProbe"));
            var virginB = await inventory.ReadAsync(tenant, sourceB, null, 100, token);
            Require(virginB.Entries.Count == 0 && !virginB.CoverageComplete, "Source B was not virgin.");
            await inventory.FenceAsync(tenant, sourceB, false, token);
            var fenced = await inventory.ReadAsync(tenant, sourceB, null, 100, token);
            await inventory.ReconcileAsync(tenant, sourceB, fenced.Version, [], "independently-owned-empty-source-B-before-any-producer", token);
            var reconciled = await inventory.ReadAsync(tenant, sourceB, null, 100, token);
            await inventory.ReopenAsync(tenant, sourceB, reconciled.Version, token);
            var bBeforeAdmission = await inventory.ReadAsync(tenant, sourceB, null, 100, token);
            receipt["sourceBBeforeAdmission"] = bBeforeAdmission;
            Require(bBeforeAdmission.CoverageComplete && bBeforeAdmission.Entries.Count == 0, "Independent source B reconciliation failed.");
            var candidate = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            modern = Host.CreateDefaultBuilder().ConfigureServices(services => services.AddDaprWorkflow(options =>
            {
                options.RegisterWorkflow<IngestionWorkflow>();
                options.RegisterActivity<SourceInventoryOutputInput, bool>(nameof(RecordSourceInventoryCandidateActivity), async (_, data) =>
                {
                    bool result = await new RecordSourceInventoryCandidateActivity(inventory).RunAsync(null!, data);
                    candidate.TrySetResult();
                    return result;
                });
                // Pause the actual production workflow immediately after candidate initialization;
                // no later activity can alter the historical artifact during this observation.
                options.RegisterActivity<CounterTransitionInput, bool>(nameof(UpdateCaseIngestionCounterActivity), async (_, _) =>
                {
                    await pause.Task.WaitAsync(token);
                    return true;
                });
            })).Build();
            await modern.StartAsync(token);
            var client = modern.Services.GetRequiredService<DaprWorkflowClient>();
            var scheduler = new DaprIngestionWorkflowScheduler(client, Substitute.For<IWorkflowPayloadStore>(),
                new IngestionWorkflowConfigurationCapture(Options.Create(new IngestionSettings()), Options.Create(new NaturalLanguageDescriptionOptions())),
                new WorkflowTraceContextCapture(), Substitute.For<IIngestionWorkflowInFlightRegistry>(), TimeProvider.System,
                NullLogger<DaprIngestionWorkflowScheduler>.Instance, inventory);
            Require(await scheduler.ScheduleAsync(id, inputB, token) == id, "Proposed scheduler rejected source B identity reuse.");
            await candidate.Task.WaitAsync(token);
            WorkflowState newState = await client.GetWorkflowStateAsync(id, true, token);
            Require(newState.Exists && newState.ReadInputAs<IngestionInput>()!.SourceUri == sourceB, "Reused real workflow has wrong source.");
            receipt["modernStoredSourceUri"] = newState.ReadInputAs<IngestionInput>()!.SourceUri;
            receipt["modernStoredSourceInventoryTracked"] = newState.ReadInputAs<IngestionInput>()!.SourceInventoryTracked;
            string provenance = (await db.StringGetAsync(SourcePublicationVisibility.KeyProvenance(tenant, id))).ToString();
            receipt["provenanceAfterReuse"] = provenance;
            Require(provenance == "modern", "Source B did not grant modern completeness.");
            RedisValue[] tracked = await db.SetMembersAsync(SourcePublicationVisibility.Keys(tenant, id));
            receipt["trackedKeysBeforeDeletion"] = tracked.Select(value => value.ToString()).ToArray();
            Require(tracked.Length == 0, "Unexpected pre-existing tracked exact keys.");
            var discovered = await SemanticKeyDiscovery.FindAsync(db, tenant, id, token);
            receipt["deletionDiscovery"] = discovered.Select(value => value.ToString()).ToArray();
            Require(!discovered.Contains((RedisKey)chunk), "Historical chunk unexpectedly joined deletion discovery.");
            var deletion = new DeleteMemoryUnitProjectionActivity(redis.Connection, graph.Connection, new GraphQueryBuilder(), inventory,
                workflowClient: client, retryOptions: Options.Create(new NaturalLanguageDescriptionOptions { LegacyRetrySchedulersDrainedForErasure = true }));
            bool deleted = await deletion.RunAsync(null!, new(tenant, inputB.CaseId, id, []));
            receipt["actualDeletionReturned"] = deleted;
            receipt["historicalChunkExistsAfterDeletion"] = await db.KeyExistsAsync(chunk);
            receipt["historicalChunkAfterDeletionSha256"] = await HashAsync(db, chunk);
            receipt["historicalChunkTextAfterDeletion"] = (await db.HashGetAsync(chunk, "chunkText")).ToString();
            receipt["survivorAfterSha256"] = await HashAsync(db, survivorChunk);
            receipt["tombstoneAfterDeletion"] = (await db.StringGetAsync(SourcePublicationVisibility.Tombstone(tenant, id))).ToString();
            receipt["sourceBAfterDeletion"] = await inventory.ReadAsync(tenant, sourceB, null, 100, token);
            Require(deleted && await db.KeyExistsAsync(chunk) && await HashAsync(db, chunk) == oldHash, "Counterexample not reproduced.");
            Require(await HashAsync(db, survivorChunk) == survivorHash, "Independent survivor bytes changed.");
            passed = true;
            receipt["counterexampleReproduced"] = true;
            Console.WriteLine("COUNTEREXAMPLE: actual purge; independently reconciled source B; actual proposed scheduler/candidate grants modern; actual deletion returns true; historical chunk and survivor bytes unchanged.");
        }
        catch (Exception exception)
        {
            receipt["failure"] = exception.ToString();
            Console.WriteLine(exception);
        }
        finally
        {
            pause.TrySetResult();
            using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            if (modern is not null) { try { await modern.StopAsync(cleanup.Token); } catch (Exception e) { receipt["modernStopFailure"] = e.ToString(); } modern.Dispose(); }
            if (historical is not null) { try { await historical.StopAsync(cleanup.Token); } catch (Exception e) { receipt["historicalStopFailure"] = e.ToString(); } historical.Dispose(); }
            if (sidecar is not null) await sidecar.DisposeAsync();
            await graph.DisposeAsync();
            await redis.DisposeAsync();
            Environment.SetEnvironmentVariable("DAPR_GRPC_ENDPOINT", priorEndpoint);
            Environment.SetEnvironmentVariable("DAPR_API_TOKEN", priorToken);
            receipt["fixtureDisposalCompleted"] = true;
            await File.WriteAllTextAsync(Path.Combine(output, "result.json"), JsonSerializer.Serialize(receipt, Json));
        }
        return passed ? 0 : 1;
    }
}
