#!/usr/bin/env python3
"""Retain normalized receipts; raw logs and owner checkouts remain private for parent review."""

import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET


def sha(data):
    return hashlib.sha256(data).hexdigest()


_PLATFORM = "Hexalith.Platform.Composition.Tests.PlatformCurrentOwnerSourceDeadlineTests."
_HISTORY = "Hexalith.Memories.IntegrationTests.Ingestion.RetryWorkflowErasureIntegrationTests."
REVERSAL_FAILURES = {
    "platformReversed": {_PLATFORM + "RegularFileLeaseBoundsCallerAndReapsWorkerAsync(recheck: False)",
                         _PLATFORM + "RegularFileLeaseBoundsCallerAndReapsWorkerAsync(recheck: True)"},
    "memoriesReversed": {_HISTORY + "PurgedAndConcurrentHistoricalArtifactsCannotGainFreshCompleteness(concurrent: " + concurrent + ", legacyNl: " + nl + ")"
                         for concurrent in ("False", "True") for nl in ("False", "True")},
}


def validate_test_evidence(raw, expected_cases, expected_failures=()):
    expected = set(expected_cases)
    failures = set(expected_failures)
    if not expected or len(expected) != len(expected_cases) or not failures <= expected:
        raise ValueError("Invalid admitted test-case inventory")
    document = ET.fromstring(raw)
    assemblies = document.findall("assembly")
    if len(assemblies) != 1:
        raise ValueError("Exactly one executed assembly is required")
    assembly = assemblies[0]
    cases = assembly.findall(".//test")
    names = [case.attrib["name"] for case in cases]
    if len(names) != len(expected) or len(set(names)) != len(names) or set(names) != expected:
        raise ValueError("Executed case identities/counts differ from admitted selection")
    if any(case.attrib.get("result") not in ("Pass", "Fail") for case in cases):
        raise ValueError("Skipped or unexecuted targeted case")
    for case in cases:
        identity = case.attrib.get("type", "") + "." + case.attrib.get("method", "")
        if case.attrib["name"] != identity and not case.attrib["name"].startswith(identity + "("):
            raise ValueError("Case identity does not match executed type/method")
    actual_failures = {case.attrib["name"] for case in cases if case.attrib["result"] == "Fail"}
    if actual_failures != failures:
        raise ValueError("Unexpected failing or missing regression cases")
    counts = {"total": len(cases), "passed": len(cases) - len(failures), "failed": len(failures), "skipped": 0}
    if any(int(assembly.attrib.get(key, "-1")) != value for key, value in counts.items()):
        raise ValueError("Assembly totals do not match executed cases")
    if int(assembly.attrib.get("errors", "0")) or int(assembly.attrib.get("not-run", "0")) or assembly.findall(".//error"):
        raise ValueError("Assembly reports errors or unexecuted tests")
    return {**{key: str(value) for key, value in counts.items()}, "time": assembly.attrib["time"], "failures": sorted(actual_failures)}


def validate_sidecar_receipt(receipt):
    if type(receipt.get("executed")) is not int or receipt["executed"] != 3 or receipt.get("passed") is not True:
        raise ValueError("Three successful publisher conformance executions are required")
    records = receipt.get("records", [])
    if len(records) != 3 or {row.get("target") for row in records} != {"docker", "k8s", "aca"}:
        raise ValueError("Three distinct target records are required")
    if not re.fullmatch(r"[0-9a-f]{64}", receipt.get("apphostSha256", "")):
        raise ValueError("Selected publisher hash is required")
    if set(receipt.get("effectivePackages", [])) != {"Aspire.Hosting/13.6.4", "CommunityToolkit.Aspire.Hosting.Dapr/13.6.2-beta.959", "Hexalith.EventStore.Aspire/4.2.0"}:
        raise ValueError("Publisher cohort differs from selected packages")
    expected = {"APP_API_TOKEN": "{memories-app-api-token.value}", "DAPR_API_TOKEN": "{memories-dapr-api-token.value}"}
    for row in records:
        if type(row.get("publisherExitCode")) is not int or row["publisherExitCode"] != 0 or row.get("conformance") != "passed":
            raise ValueError("Publisher execution/conformance failed")
        if not re.fullmatch(r"[0-9a-f]{64}", row.get("actualManifestSha256", "")) or row.get("privateRawArtifactsRemoved") is not True:
            raise ValueError("Actual artifact hash and cleanup evidence are required")
        if row.get("appSecretReferences") != expected:
            raise ValueError("App secret references are invalid")
        if row.get("pairedSecretEmissionQualified") is False:
            if row.get("blocker") != "sidecar-environment-not-emitted" or row.get("sidecarType") != "dapr.v0" or sorted(row.get("sidecarKeys", [])) != ["dapr", "type"] or row.get("sidecarSecretReferences") not in (None, dict.fromkeys(expected)):
                raise ValueError("Unsupported output does not match the observed refusal")
        elif row.get("pairedSecretEmissionQualified") is True:
            if row.get("blocker") is not None or row.get("sidecarSecretReferences") != expected or "env" not in row.get("sidecarKeys", []):
                raise ValueError("Positive paired sidecar emission lacks evidence")
        else:
            raise ValueError("Missing sidecar qualification disposition")
    return all(row["pairedSecretEmissionQualified"] for row in records)


def load_cleanup():
    specification = importlib.util.spec_from_file_location("snapshot_owned_cleanup", Path(__file__).with_name("run-owned-backfill.py"))
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--private-root", type=Path, required=True)
    options = parser.parse_args()
    batch = Path(__file__).resolve().parent
    root = batch.parents[3]
    private = options.private_root.resolve()
    # A failed refresh cannot leave a previous successful report claiming current qualification.
    (batch / "verification.json").write_text(json.dumps({"status": "verification incomplete or refused"}) + "\n")
    admitted = json.loads((batch / "expected-cases.json").read_text())
    cleanup = load_cleanup()
    sidecar = json.loads((private / "sdk-sidecar-emission.json").read_text())
    paired_emission = validate_sidecar_receipt(sidecar)

    def normalize(data):
        return data.replace(str(private).encode(), b"${PRIVATE_ROOT}").replace(str(root).encode(), b"${PARTIES_ROOT}")

    selections = {"Parties": root, "Platform": root / "references/Hexalith.Platform", "Memories": root / "references/Hexalith.Memories",
                  "EventStore": root / "references/Hexalith.EventStore", "Builds": root / "references/Hexalith.Builds"}
    revisions = {name: subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=path, text=True).strip() for name, path in selections.items()}
    tests = {}
    for name, relative in {
        "platform": "platform-final.xml", "platformReversed": "platform-reversed.xml",
        "memories": "memories-qualified-final.xml", "memoriesReversed": "memories-rollback.xml",
        "determinism": "memories-determinism.xml", "backfill": "backfill-final/backfill.xml", "publishModels": "publish-models.xml",
        "historicalIntermittent": "memories-qualified.xml",
    }.items():
        raw = (private / relative).read_bytes()
        normalized = normalize(raw)
        filename = name + ".xml.gz"
        (batch / filename).write_bytes(gzip.compress(normalized, mtime=0))
        selection = {"platformReversed": "platform", "memoriesReversed": "memories", "historicalIntermittent": "memories"}.get(name, name)
        expected_failures = REVERSAL_FAILURES.get(name, set())
        if name == "historicalIntermittent":
            expected_failures = {_HISTORY + "OriginalSameNameRawRetrySuspendedInEachContentActivityTerminatesAfterWorkerUpgradeAndPurgesHistory(embeddingPhase: False)"}
        tests[name] = validate_test_evidence(raw, admitted[selection], expected_failures)
        tests[name].update({"xml": filename, "rawXmlSha256": sha(raw), "normalizedXmlSha256": sha(normalized)})
    source_files = [
        ".gitattributes", "tests/Hexalith.Parties.Tests/Projections/PartyLegacyBackfillRuntimeFixture.cs",
        "tests/Hexalith.Parties.Tests/Projections/PartyLegacyBackfillProcessRuntimeTests.cs",
        "tests/Hexalith.Parties.Tests/Projections/PartyLegacyBackfillWorkloadManifest.cs",
        "references/Hexalith.Platform/.gitattributes", "references/Hexalith.Platform/src/Hexalith.Platform.Composition/Hexalith.Platform.Composition.csproj",
        "references/Hexalith.Platform/src/Hexalith.Platform.Composition/PlatformCurrentOwnerSourceState.cs",
        "references/Hexalith.Platform/src/Hexalith.Platform.Composition/PlatformSourceStateWorker.cs",
        "references/Hexalith.Platform/tests/Hexalith.Platform.Composition.Tests/PlatformCurrentOwnerSourceDeadlineTests.cs",
        "references/Hexalith.Memories/src/Hexalith.Memories.Server/Ingestion/SourceInventoryStore.cs",
        "references/Hexalith.Memories/tests/Hexalith.Memories.IntegrationTests/Ingestion/OwnedFreshSourceInventory.cs",
        "references/Hexalith.Memories/tests/Hexalith.Memories.IntegrationTests/Ingestion/HistoricalPurgedArtifactWorkflow.cs",
        "references/Hexalith.Memories/tests/Hexalith.Memories.IntegrationTests/Ingestion/RetryWorkflowErasureIntegrationTests.cs",
        "references/Hexalith.Memories/tests/Hexalith.Memories.IntegrationTests/Ingestion/SourceInventoryProducerIntegrationTests.cs",
        "references/Hexalith.Memories/tests/Hexalith.Memories.IntegrationTests/Ingestion/RefreshPublicationIntegrationTests.cs",
    ]
    sources = {name: sha((root / name).read_bytes()) for name in source_files}
    binaries = {}
    for label, path in {
        "platformDebug": private / "platform/tests/Hexalith.Platform.Composition.Tests/bin/Debug/net10.0/Hexalith.Platform.Composition.Tests.dll",
        "platformComposition": private / "platform/tests/Hexalith.Platform.Composition.Tests/bin/Debug/net10.0/Hexalith.Platform.Composition.dll",
        "memoriesDebug": root / "references/Hexalith.Memories/tests/Hexalith.Memories.IntegrationTests/bin/Debug/net10.0/Hexalith.Memories.IntegrationTests.dll",
        "memoriesServerDebug": root / "references/Hexalith.Memories/tests/Hexalith.Memories.IntegrationTests/bin/Debug/net10.0/Hexalith.Memories.Server.dll",
        "partiesPackageRelease": root / "tests/Hexalith.Parties.Tests/bin/Release/net10.0/Hexalith.Parties.Tests.dll",
        "publishPackageRelease": root / "tests/Hexalith.Parties.IntegrationTests/bin/Release/net10.0/Hexalith.Parties.IntegrationTests.dll",
        "apphostPackageRelease": root / "src/Hexalith.Parties.AppHost/bin/Release/net10.0/Hexalith.Parties.AppHost.dll",
    }.items():
        binaries[label] = {"path": normalize(str(path).encode()).decode(), "sha256": sha(path.read_bytes())}
    if sidecar["apphostSha256"] != binaries["apphostPackageRelease"]["sha256"]:
        raise ValueError("Sidecar receipt does not bind the selected executed AppHost")
    provider = json.loads((private / "backfill-final/receipt.json").read_text())
    if provider.get("testExitCode") != 0 or provider.get("cleanupSucceeded") is not True or provider.get("cleanupErrors") != [] or provider.get("ownedProcessesExited") is not True or provider.get("ownedContainerAbsent") is not True:
        raise ValueError("Owned provider cleanup or execution is unqualified")
    if not cleanup.confirmed_container_absent(provider["ownedContainerId"]):
        raise ValueError("Owned provider container still exists")
    for filename in ("sdk-sidecar-emission.json",):
        (batch / filename).write_bytes(normalize((private / filename).read_bytes()))
    (batch / "provider-cleanup.json").write_bytes((private / "backfill-final/receipt.json").read_bytes())
    logs = [
        "platform-build", "platform-build-2", "platform-final-build", "platform-final",
        "memories-complete-build", "memories-qualified-final-build", "memories-rollback-build",
        "memories-server-build", "memories-determinism", "parties-debug-build-2", "parties-final-build",
        "publish-build", "sidecar-conformance",
    ]
    retained_logs = []
    for suffix in logs:
        source = private.parent / ("parties-snapshot-" + suffix + ".log")
        if source.exists():
            destination = suffix + ".log.gz"
            (batch / destination).write_bytes(gzip.compress(normalize(source.read_bytes()), mtime=0))
            retained_logs.append(destination)
    # Runtime stdout can contain synthetic payloads. Retain only ownership removals
    # and explicit bounded diagnostics; the full original stays outside the repository.
    diagnostics = []
    container_ids = set()
    for source in private.parent.glob("parties-snapshot-memories-*.log"):
        text = source.read_text(errors="replace")
        container_ids.update(re.findall(r"Docker container ([0-9a-f]{12}) created", text))
    for identifier in sorted(container_ids):
        absent = cleanup.confirmed_container_absent(identifier)
        diagnostics.append({"ownedContainer": identifier, "absent": absent, "querySucceeded": True})
        if not absent:
            raise ValueError("Owned Memories container remains present")
    if not diagnostics:
        raise ValueError("No recorded owned Memories resources were verified")
    (batch / "memories-cleanup.json").write_text(json.dumps(diagnostics, indent=2) + "\n")
    for source in [private / "backfill-final/backfill.log", private.parent / "parties-snapshot-platform-final.log", private.parent / "parties-snapshot-memories-qualified-final.log"]:
        lines = [line for line in source.read_text().splitlines() if "[D::" in line or "Total:" in line]
        (batch / ("backfill-diagnostics.txt" if "backfill" in str(source) else "memories-diagnostics.txt" if "memories" in str(source) else "platform-deadline-diagnostics.txt")).write_bytes(normalize(("\n".join(lines) + "\n").encode()))
    report = {
        "status": "implementation verified; independent review, commitlint, final source selection and publication are parent-owned",
        "date": "2026-11-11", "baselineRevisions": revisions, "finalOwnerCommitIdentities": "pending parent commits; source hashes bind this working implementation",
        "sdk": subprocess.check_output(["dotnet", "--version"], text=True).strip(), "tests": tests,
        "sourceSha256": sources, "binarySha256": binaries, "retainedLogs": retained_logs,
        "matrix": {
            "snapshotDeadline": {"executed": True, "passed": tests["platform"]["failed"] == "0", "evidence": ["platform", "platformReversed"]},
            "purgedHistory": {"executed": True, "passed": tests["memories"]["failed"] == "0", "evidence": ["memories", "memoriesReversed"], "scope": "unknown-source erasure refusal"},
            "concurrentHistoricalProducer": {"executed": True, "passed": tests["memories"]["failed"] == "0", "evidence": ["memories", "memoriesReversed"], "scope": "real absent-read/older-completion/admission order; no writer drain"},
            "backfillWorkloadRestart": {"executed": True, "passed": tests["backfill"]["failed"] == "0", "evidence": ["backfill"], "children": 10, "deploymentGate": "open"},
            "sidecarPublication": {"executed": True, "conformancePassed": True, "pairedEmissionQualified": paired_emission, "evidence": "sdk-sidecar-emission.json", "upstreamGate": "open" if not paired_emission else "paired artifact delivery qualified"},
        },
        "intermittentObservation": "Unchanged historical worker-upgrade control observed one unexpected content call during an overlapping green/reversal run. No cause is established. The prior core and final serialized controls remain separate receipts.",
        "externalGates": ["supported upstream sidecar token target emission", "deployed DW-58 provider/history completeness, writer drain, authorization and cutover", "older writers after a source attestation", "production reconciliation of existing provenance/history"],
        "ownership": "No nested submodules, dependency versions, packages, deployment, staging, commits or remote Git operations changed by implementation.",
    }
    (batch / "verification.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
