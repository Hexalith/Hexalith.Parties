import copy,gzip,hashlib,importlib.util,json,shutil,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
folder=Path('${PARTIES_ROOT}/_bmad-output/implementation-artifacts/tests/six-fitness-failures-resumed-2026-11-09')
root=Path('${EXECUTION_RECEIPTS}/historical-root')
s=importlib.util.spec_from_file_location('gate',folder/'verify-receipt.py');gate=importlib.util.module_from_spec(s);s.loader.exec_module(gate)
original=json.loads((folder/'validation.json').read_text())
def h(b): return hashlib.sha256(b).hexdigest()
def run(d,n): return next(r for r in d['runs'] if r['name']==n)
def plain(d,w,n): return gzip.decompress((w/d['archives'][n]['archive']).read_bytes())
def replace(d,w,n,v):
 b=gzip.compress(v,mtime=0);item=d['archives'][n];(w/item['archive']).write_bytes(b);item.update(sanitized_sha256=h(v),compressed_sha256=h(b))
def xml(d,w,n,change):
 record=run(d,n);tree=ET.fromstring(plain(d,w,record['xml']));change(tree);replace(d,w,record['xml'],ET.tostring(tree));record['assemblies']=[a.attrib for a in tree.findall('assembly')]
def coordinated_parent(d,w):
 for n in ['parent-source-full-socket-enabled','final-parent-package-full-corrected']:
  def change(t):
   x=next(x for x in t.findall('.//test') if x.get('result')=='Pass' and 'FitnessTests' not in x.get('name',''));x.set('name','Synthetic.NoRealTest');x.set('method','NoRealTest')
  xml(d,w,n,change)
def coordinated_owner(d,w):
 for n in ['owner-contracts-clean-environment-baseline','owner-patched-contracts-full']:
  def change(t):
   x=t.find(".//test[@result='Fail']");x.set('name','Synthetic.UnrelatedRegression');x.find('failure').set('exception-type','UnexpectedApplicationRegression');x.find('failure/message').text='Unrelated application regression'
  xml(d,w,n,change)
def unrelated_tests(d,w):
 def change(t):
  for x in t.findall('.//test'): x.set('name','Synthetic.'+x.get('id'));x.set('method','NoRealTest')
 xml(d,w,'owner-server-socket-enabled',change)
def junk_review(d,w): replace(d,w,'blind-hunter-followup.md',b'Unrelated text\n')
def junk_patch(d,w):
 replace(d,w,'owner-patch.diff',b'not a patch\n');d['reviewed_diff_sha256']['owner-patch.diff']=h(b'not a patch\n')
def junk_delivery(d,w):
 replace(d,w,'delivery.diff',b'not a patch\n');d['reviewed_diff_sha256']['delivery.diff']=h(b'not a patch\n')
def inconsistent_derived(d,w):
 for r in d['runs']:r['failures']=[];r['skips']=[]
def unrelated_assembly(d,w):
 def change(t):
  for a in t.findall('assembly'):a.set('name','Unrelated.Tests.dll')
 xml(d,w,'owner-server-socket-enabled',change)
def impossible_time(d,w):
 for r in d['runs']:r['started_utc']='2099-01-01T00:00:00+00:00';r['seconds']=-1
cases=[('paired-parent-inventory-replacement',coordinated_parent),('paired-owner-failure-replacement',coordinated_owner),('replace-all-server-test-identities',unrelated_tests),('non-substantive-original-review',junk_review),('non-patch-owner-diff',junk_patch),('non-patch-delivery-diff',junk_delivery),('contradictory-derived-failure-skip-lists',inconsistent_derived),('unrelated-server-assembly',unrelated_assembly),('impossible-execution-times',impossible_time),('unsupported-schema',lambda d,w:d.update(schema=999)),('remove-limits',lambda d,w:d.update(limits=[])),('remove-transformations',lambda d,w:d.pop('transformations'))]
results=[]
for name,mutation in cases:
 with tempfile.TemporaryDirectory(prefix='blind-review-') as temp:
  w=Path(temp)
  for v in original['archives'].values():shutil.copy2(folder/v['archive'],w/v['archive'])
  d=copy.deepcopy(original);mutation(d,w)
  try: result=gate.verify(w,root,d);status='ACCEPTED'
  except Exception as e:result=str(e);status='rejected'
  results.append({'case':name,'status':status,'result':result})
print(json.dumps(results,indent=2))
