import os,subprocess,json,time,hashlib,signal
from pathlib import Path
root=Path('${PARTIES_ROOT}')
work=Path('${EXECUTION_RECEIPTS}')
selection=json.loads((work/'source-preparation.json').read_text())['buildPreparation']
records=[]
selectors=['CustomBeforeDirectoryBuildProps','CustomAfterMicrosoftCommonProps','CustomBeforeDirectoryBuildTargets','CustomAfterDirectoryBuildTargets','AfterMicrosoftNETSdkTargets','HEXALITH_SOURCE_MAPPING_HASH','Configuration']
def run(name,args,cwd=root,mode='source'):
 env=os.environ.copy()
 for key in selectors:env.pop(key,None)
 overrides=selection['environment'] if mode=='source' else {}
 env.update(overrides)
 started=time.time()
 with (work/(name+'.log')).open('wb') as log:
  process=subprocess.Popen(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=1200)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait();code=124
 record={'name':name,'command':args,'cwd':str(cwd),'environment_overrides':overrides,'cleared_environment_keys':selectors,'exit_code':code,'elapsed_seconds':round(time.time()-started,3),'log':name+'.log'}
 records.append(record);(work/'fresh-runs.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,code,flush=True)
 return code
project='tests/Hexalith.Parties.Tests/Hexalith.Parties.Tests.csproj'
code=run('current-service-build',['dotnet','build',project,'--configuration','Debug','--disable-build-servers','-m:1'])
if code==0:
 assembly=root/'tests/Hexalith.Parties.Tests/bin/Debug/net10.0/Hexalith.Parties.Tests.dll'
 (work/'current-service-assembly.json').write_text(json.dumps({'path':str(assembly),'sha256':hashlib.sha256(assembly.read_bytes()).hexdigest(),'mapping_hash':selection['mappingHash']},indent=2)+'\n')
 run('current-service-fitness',['dotnet',str(assembly),'-noColor','-class','Hexalith.Parties.Tests.FitnessTests.*','-xml',str(work/'current-service-fitness.xml')])
 run('current-service-full',['dotnet',str(assembly),'-noColor','-xml',str(work/'current-service-full.xml')])
owner=root/'references/Hexalith.Tenants'
code=run('current-owner-contracts-build',['dotnet','build','tests/Hexalith.Tenants.Contracts.Tests/Hexalith.Tenants.Contracts.Tests.csproj','--configuration','Debug','--disable-build-servers','-m:1'],cwd=owner)
if code==0:
 assembly=owner/'tests/Hexalith.Tenants.Contracts.Tests/bin/Debug/net10.0/Hexalith.Tenants.Contracts.Tests.dll'
 run('current-owner-contracts-full',['dotnet',str(assembly),'-noColor','-xml',str(work/'current-owner-contracts-full.xml')],cwd=owner,mode='package')
