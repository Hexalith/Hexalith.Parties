import copy,gzip,hashlib,importlib.util,json,shutil,tempfile
from pathlib import Path
folder=Path('${PARTIES_ROOT}/_bmad-output/implementation-artifacts/tests/six-fitness-failures-resumed-2026-11-09')
root=Path('${EXECUTION_RECEIPTS}/historical-root')

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
original=load('original',folder/'verify-receipt.py')
mutant=load('mutant',Path('${EXECUTION_RECEIPTS}/verification-source-mutant/verify-receipt.py'))
data=json.loads((folder/'validation.json').read_text())
with tempfile.TemporaryDirectory(prefix='source-property-gap-') as td:
 work=Path(td)
 for archive in data['archives'].values():shutil.copy2(folder/archive['archive'],work/archive['archive'])
 name='parent-source-fitness-selection'
 record=next(r for r in data['runs'] if r['name']==name)
 item=data['archives'][record['log']]
 payload=json.loads(gzip.decompress((work/item['archive']).read_bytes()))
 payload['Properties']['HexalithEventStoreFromSource']='false'
 plain=json.dumps(payload).encode();blob=gzip.compress(plain,mtime=0)
 (work/item['archive']).write_bytes(blob)
 item['sanitized_sha256']=hashlib.sha256(plain).hexdigest();item['compressed_sha256']=hashlib.sha256(blob).hexdigest()
 for title,gate in [('original',original),('mutant',mutant)]:
  try:result=gate.verify(work,root,copy.deepcopy(data));print(title,json.dumps(result))
  except Exception as e:print(title,type(e).__name__,str(e))
results=json.loads(Path('${EXECUTION_RECEIPTS}/verification-source-mutant-results.json').read_text())
print('mutant fixture cases',results['cases'],'valid',results['results'][0], 'rejected',sum(r['result']=='rejected' for r in results['results']))
