import importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd()
spec=importlib.util.spec_from_file_location('cohort',root/'scripts/validate-aspire-runtime-cohort.py');cohort=importlib.util.module_from_spec(spec);spec.loader.exec_module(cohort)
manifest_path=root/'artifacts/runtime-profile/Debug/prepared.json'
manifest=cohort.load(manifest_path);families=manifest['familyVersions'];version=manifest['sdkVersion'];configuration=manifest['configuration']
owner=cohort.PRIVATE_ADMIN_UI_PROJECT;wrapper=cohort.MEMORY_QUALIFICATION_PROJECT
owner_path=Path(manifest['projects'][str(owner)]['receipt']);wrapper_path=Path(manifest['projects'][str(wrapper)]['receipt'])
def metadata(receipt):
 return {'Properties':{'TargetPath':receipt['targetPath'],'ProjectAssetsFile':receipt['assetsPath'],'Configuration':configuration,'HexalithEventStoreVersion':version}}
receipts=[Path(value['receipt']) for value in manifest['projects'].values()]
for receipt_path in receipts:
 old=cohort.load(receipt_path);project=Path(old['project'])
 started=int(Path('/tmp/parties-five-proof-20261111/wrapper-build-started-ns').read_text()) if project==wrapper else old['buildStartedNs']
 cohort.write(receipt_path,cohort.record(metadata(old),project,configuration,version,started,old['role'],families,
                                       owner_path if project==wrapper else None))
packages=[item['id']+'='+item['version'] for item in manifest['publicArchives']]
completed=cohort.complete(receipts,configuration,version,packages,manifest_path.parent/'public-archives',families)
cohort.write(manifest_path,completed)
cohort.write(Path('/tmp/parties-five-proof-20261111/prepared-package-debug-current.json'),completed)
print('Revalidated all '+str(len(receipts))+' project receipts and official archives after exact wrapper rebuild')
