using System.Reflection;
using System.Text.Json;
string root = args[0];
string path = Path.Combine(args[1], "owned");
using JsonDocument manifest = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(root, "artifacts/runtime-profile/Release/prepared.json")));
string Output(string relative)
{
    string project = Path.GetFullPath(Path.Combine(root, relative));
    using JsonDocument receipt = JsonDocument.Parse(File.ReadAllBytes(manifest.RootElement.GetProperty("projects").GetProperty(project).GetProperty("receipt").GetString()!));
    return receipt.RootElement.GetProperty("targetPath").GetString()!;
}
string parties = Output("src/Hexalith.Parties/Hexalith.Parties.csproj");
string tenants = Output("references/Hexalith.Tenants/src/Hexalith.Tenants/Hexalith.Tenants.csproj");
string sample = Output("tests/Hexalith.Parties.EventStoreSample.TestHost/Hexalith.Parties.EventStoreSample.TestHost.csproj");
var owners = new List<(string OwnerPath, string AdapterPath, string AppId)>
{
    (Path.Combine(Path.GetDirectoryName(parties)!, "Hexalith.Parties.Contracts.dll"), Output("src/Hexalith.Parties.EventStoreExtensions/Hexalith.Parties.EventStoreExtensions.csproj"), "parties-proof"),
    (Path.Combine(Path.GetDirectoryName(tenants)!, "Hexalith.Tenants.Contracts.dll"), Path.Combine(Path.GetDirectoryName(tenants)!, "Hexalith.Tenants.Server.dll"), "tenants-proof"),
    (sample, sample, "sample-proof"),
};
Assembly host = Assembly.LoadFrom(Path.Combine(root, "src/Hexalith.Parties.AppHost/bin/Release/net10.0/Hexalith.Parties.AppHost.dll"));
Type tool = host.GetType("Hexalith.Parties.AppHost.PartiesDevelopmentCatalogTool", true)!;
var flags = BindingFlags.Static | BindingFlags.NonPublic;
MethodInfo generate = tool.GetMethod("GenerateAsync", flags)!;
MethodInfo own = tool.GetMethod("RunOwnedPreparationAsync", flags)!;
try
{
    Func<Task> prepare = async () =>
    {
        using JsonDocument receipt = await (Task<JsonDocument>)generate.Invoke(null, [new DirectoryInfo(root), path, "sdk410-proof", "eventstore-proof", "4.1.0", owners, CancellationToken.None])!;
        File.WriteAllText(Path.Combine(args[1], "receipt.json"), receipt.RootElement.GetRawText());
        File.Copy(Path.Combine(path, "reader/preparation.json"), Path.Combine(args[1], "preparation.json"));
        Console.WriteLine(receipt.RootElement.GetRawText());
    };
    await (Task)own.Invoke(null, [path, "catalog-proof", prepare])!;
}
finally
{
    tool.GetMethod("DeleteOwnedDirectory", flags)!.Invoke(null, [path, "catalog-proof"]);
}
